---
mode: agent
description: Generate an Angular (standalone + signals) component from a Component Spec.
---

Generate an Angular component from the given `specs/<name>.spec.json` (run /analyze-design first if none exists).

Stack: standalone components, signals, `input()`/`output()`, OnPush, `@if`/`@for`/`@switch` templates. Tailwind utilities backed by `--ds-*` variables; SCSS only for what utilities can't express. No raw hex/px — missing token means run /extract-tokens first. No brand logic in TypeScript; multi-brand via `data-brand` CSS only.

Files (match existing repo conventions and `angular.json` prefix):
```
components/angular/<name>/
├── <name>.component.ts      # inline template if < ~40 lines
├── <name>.component.html
├── <name>.component.scss
├── <name>.component.spec.ts # TestBed: render, inputs, outputs, a11y
└── index.ts
```

Rules:
1. Spec `props[]` → `input<T>()` / `input.required<T>()`; `events[]` → `output<T>()`; prefer `host` bindings over wrapper divs.
2. Implement every spec state: hover/focus-visible, disabled (`[attr.aria-disabled]`, block emit), loading (`aria-busy` + spinner). Always-visible focus ring.
3. Content areas → `<ng-content select>` or `TemplateRef` inputs for repeated custom rows.
4. Semantic native elements; apply spec a11y block; `aria-label` on icon-only controls; Enter/Space on custom interactive elements.
5. Responsive per spec, mobile-first.
6. Form controls implement `ControlValueAccessor`.
7. No new dependencies without asking. Pre-v17 repos: follow the repo's existing idioms instead of signals.

Quality gate: build passes, specs pass, no raw hex/px, visual re-check against source. Then register the component in `design-system-app/src/data/components.json` and report files, tokens used, and deviations.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each its own standalone component in `components/angular/<name>/`. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: inputs in, outputs out, zero form state. Form controls implement `ControlValueAccessor` so they bind to reactive forms.
- **Layout** component arranges projected content only (`<ng-content select>` slots, grid/gap/responsive collapse).
- **Composite** builds a `FormGroup` (typed reactive forms) with validators + input masking, binds child controls via `formControlName`, wires label/error a11y (`for`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues` input, `submitted(values)` / `cancelled` outputs, `loading` input. It is the single usable entry point.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
