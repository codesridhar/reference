---
mode: agent
description: Extract/normalize design tokens and regenerate multi-brand CSS variables + Tailwind mapping.
---

Maintain the token pipeline: raw values → `tokens/design-tokens.json` → per-brand CSS variables → Tailwind mapping.

Token architecture (3 layers):
1. **Primitive** — raw palette (`blue-600: #2563eb`). Never referenced by components.
2. **Semantic** — meaning (`color.brand-primary`, `color.surface`, `radius.lg`). The whitelabel override surface.
3. **Component** — optional (`button.primary.bg → {color.brand-primary}`).

Multi-brand model: the default brand defines all semantic variables on `:root`; each partner brand redefines only differing semantic variables under `[data-brand="<brand>"]`. Switching brand = setting `data-brand` on `<html>` — no rebuild.

Steps:
1. Read existing `tokens/design-tokens.json`; merge, never clobber names already referenced by components.
2. Ingest new values (Figma variable export, dev-mode CSS, spec `needsToken` entries, brand guidelines).
3. Normalize: lowercase hex, 4px spacing scale, kebab-case semantic names (`color.text-muted`).
4. Update the canonical JSON (primitive / semantic / brands sections).
5. Regenerate:
   - `tokens/css/default.css` — `--ds-*` variables on `:root` (e.g. `--ds-color-brand-primary`)
   - `tokens/css/<brand>.css` — only actual differences, under `[data-brand]`
   - `tokens/tailwind.tokens.js` — `theme.extend` mapping utilities to `var(--ds-*)`
6. Validate WCAG AA contrast per brand (`text-primary` on `surface`); report failures.

Finish by reporting tokens added/changed, brands regenerated, conflicts.
