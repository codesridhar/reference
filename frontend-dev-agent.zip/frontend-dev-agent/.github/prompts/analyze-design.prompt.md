---
mode: agent
description: Analyze a design image/PDF/Figma export and produce a Component Spec JSON.
---

Analyze the attached design input (Figma screenshot, exported image, or PDF page) and produce a structured Component Spec. Do NOT generate framework code here.

Steps:
1. Identify the component boundary. If the input is a full screen, list candidate components and confirm scope.
2. Decompose the hierarchy: container → sections → elements (buttons, inputs, labels, icons, badges…).
3. Estimate values: colors (hex, flag as estimated), typography (size/weight/line-height), spacing snapped to a 4px scale, radii, shadows.
4. Infer interaction states even if not shown (hover, focus-visible, active, disabled, loading, error, empty) and mark them `"inferred": true`.
5. Infer the component API: configurable props, emitted events, slotted content.
6. Add an a11y block: role, aria attributes, keyboard interactions, contrast flags (WCAG AA 4.5:1).
7. Add responsive intent for sm/md/lg.

Output: write `specs/<ComponentName>.spec.json` containing: name, description, source, layout, elements[], tokensUsed[], props[], events[], a11y, responsive, confidence.

Rules:
- Reference design tokens (`color.brand-primary`) when `tokens/design-tokens.json` defines them; otherwise include raw value plus `"needsToken": true`.
- One spec per component; screens reference child specs.
- Finish by reporting the spec path and any low-confidence items needing human confirmation.

## Composite designs (complete forms, multi-element widgets)

When the input is a complete form or a widget built from repeated primitives — e.g. a payment form with a card preview, labeled fields, and action buttons — do NOT spec it as one flat component. Produce a **spec tree**:

1. **Atoms** — one spec per reusable primitive found in the design: `FormLabel`, `TextInput` (variants: prefix icon, masked value), `Button`, `CardPreview`. First check `design-system-app/src/data/components.json` and existing `components/` — reference existing components instead of re-speccing them.
2. **Molecules** — `FormField` = FormLabel + control + help/error text, wired via `htmlFor`/`aria-describedby`.
3. **Layout** — a separate layout component (`FormLayout`) that owns ONLY grid, column spans, gaps, and responsive collapse (e.g. 2-column `2fr/1fr` grid → single column on mobile). No business content, children via slots.
4. **Composite** — the whole usable component (`UpdatePaymentMethodForm`) with `"type": "composite"` and `"children": ["specs/CardPreview.spec.json", "specs/FormField.spec.json", …]`. Its spec defines the form model (fields, validation, input masks like `1234 1234 1234 1234`, `06 / 2028`, CVV masking), state handling, and events (`submit` with form values, `cancel`).

Worked example — "Update payment method" design decomposes to:
`CardPreview` (gradient panel, contactless icon, name/expiry/masked number) · `FormLabel` · `TextInput` (variants: plain, card-number with brand icon, expiry segmented, CVV masked) · `FormField` · `Button` (primary/secondary) · `FormLayout` (rows: full, 2fr/1fr, footer actions) · `UpdatePaymentMethodForm` (composite root).

One spec file per node in `specs/`. Generators build children first, composite last.
