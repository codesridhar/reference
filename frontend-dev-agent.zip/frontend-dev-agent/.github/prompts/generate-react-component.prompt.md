---
mode: agent
description: Generate a React (TypeScript + Tailwind) component from a Component Spec.
---

Generate a React component from the given `specs/<Name>.spec.json` (run /analyze-design first if none exists).

Stack: TypeScript function components + hooks; Tailwind utilities backed by `--ds-*` CSS variables. Never hard-code hex/px design values — missing token means run /extract-tokens first. Components must render correctly under any `data-brand` with zero JS brand logic.

Files (match existing repo conventions if they differ):
```
components/react/<Name>/
├── <Name>.tsx
├── <Name>.types.ts
├── <Name>.test.tsx        # RTL: render, props, events, a11y roles
├── <Name>.stories.tsx     # CSF3, skip if no Storybook
└── index.ts
```

Rules:
1. Spec `props[]` → typed props; `className` passthrough; `...rest` to root; `forwardRef` for interactive/form roots.
2. Implement every spec state: `hover:`/`focus-visible:` variants, disabled (`aria-disabled`), loading (`aria-busy` + spinner). Always-visible focus ring.
3. Spec `events[]` → `on<Event>` callbacks with typed payloads.
4. Semantic elements first; apply spec a11y block; label icon-only controls.
5. Responsive per spec, mobile-first Tailwind breakpoints.
6. Content areas → `children` / named slot props; no hard-coded copy the spec marks as content.
7. No new dependencies without asking.

Quality gate: `tsc --noEmit` passes, tests pass, no raw hex/px in output, visual re-check against source. Then register the component in `design-system-app/src/data/components.json` and report files, tokens used, and deviations.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each in its own `components/react/<Name>/` folder. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: props in, events out, zero form state.
- **Layout** component arranges named slots only (grid/gap/responsive collapse) — accepts children, no content of its own.
- **Composite** imports the children, owns form state + validation + input masking, wires label/error a11y (`htmlFor`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues`, `onSubmit(values)`, `onCancel`, `loading`. It is the single usable entry point — a consumer renders ONE component.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
