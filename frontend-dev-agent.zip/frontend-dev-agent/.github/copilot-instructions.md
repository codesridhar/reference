# Copilot instructions — design-to-code repo

This repo uses a spec-first design-to-code pipeline with a multi-brand (whitelabel) design system.

## Non-negotiables

- **Token-only styling.** Never write raw hex colors, px shadows, or radii in components. Use Tailwind utilities that map to CSS variables (`--ds-*`) defined in `tokens/css/`. If a value has no token, add it via the token pipeline (`.github/prompts/extract-tokens.prompt.md`) first.
- **Multi-brand.** Brands are switched with `data-brand` on `<html>`; overrides live in `tokens/css/<brand>.css`. Never branch on brand in JS/TS.
- **Spec-first.** Components are generated from `specs/*.spec.json` (see `.github/prompts/analyze-design.prompt.md`). Keep spec and implementation in sync.
- **React**: TypeScript function components, hooks, Tailwind, RTL tests, files under `components/react/<Name>/`.
- **Angular**: standalone components, signals, `input()`/`output()`, OnPush, `@if`/`@for` templates, files under `components/angular/<name>/`.
- **Accessibility**: semantic elements, keyboard support, visible `focus-visible` rings, WCAG AA contrast, `aria-*` per the component spec.
- After adding a component, register it in `design-system-app/src/data/components.json` (name, description, props, tokens used) so the design system documentation app stays current.

## Prompt files

- `/analyze-design` — design image/PDF → Component Spec JSON
- `/extract-tokens` — tokens → canonical JSON + brand CSS + Tailwind mapping
- `/generate-react-component` — spec → React component
- `/generate-angular-component` — spec → Angular component
