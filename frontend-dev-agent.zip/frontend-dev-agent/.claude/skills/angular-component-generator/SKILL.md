---
name: angular-component-generator
description: Generate a production-quality Angular component (standalone, signals, OnPush, token-driven SCSS with Tailwind utilities, accessible, multi-brand safe) from a Component Spec JSON produced by design-input-analyzer, or directly from a short description. Use when the user asks for an Angular component or to implement a spec in Angular.
---

# Angular Component Generator

Consume a Component Spec (`specs/*.spec.json`) and emit an Angular component matching the design and repo conventions. If no spec exists, first invoke `design-input-analyzer`.

## Stack contract

- **Standalone components** (no NgModules), **signals** for local state, `input()` / `output()` functions, `ChangeDetectionStrategy.OnPush`.
- **Modern template syntax**: `@if`, `@for` (with `track`), `@switch`.
- **Styling**: Tailwind utilities in templates where the project uses Tailwind; component SCSS only for what utilities can't express. All values via `var(--ds-*)` tokens from `tokens/` — never raw hex/px. Missing token → route to `design-token-extractor` first.
- Multi-brand via `data-brand` CSS variables only; no brand logic in TypeScript.

## Output files (per component)

```
components/angular/<component-name>/
├── <component-name>.component.ts     # standalone, inline template if < ~40 lines
├── <component-name>.component.html   # template (if not inline)
├── <component-name>.component.scss   # only token-driven styles Tailwind can't cover
├── <component-name>.component.spec.ts# TestBed tests: render, inputs, outputs, a11y
└── index.ts                          # barrel export
```

Inspect the existing app first (`src/app/`) and match its structure, prefix (from `angular.json`), and version idioms — if the repo is pre-v17, fall back to its patterns rather than forcing signals.

## Generation rules

1. **Inputs/outputs from spec** — `props[]` → `input<T>()` (use `input.required<T>()` when spec says required); `events[]` → `output<T>()`. Add `host` bindings for classes/aria rather than wrapper divs.
2. **States** — implement all spec states: hover/focus with Tailwind variants or `:hover`/`:focus-visible`; disabled binds `[attr.aria-disabled]` and blocks emit; loading sets `aria-busy` with spinner. Visible focus ring always.
3. **Content projection** — spec content areas → `<ng-content select="[slotName]">` or template inputs (`TemplateRef`) for repeated custom rows.
4. **Accessibility** — semantic native elements; apply the spec's `a11y` block; icon-only controls get `aria-label`; keyboard handling per spec (Enter/Space on custom interactive elements).
5. **Responsive** — spec's `responsive` block via Tailwind breakpoints or container queries, mobile-first.
6. **Forms** — if the component is an input control, implement `ControlValueAccessor` so it works with reactive forms.
7. **No new dependencies** without asking.

## Quality gate (before finishing)

- `ng build` (or `tsc`) passes; specs pass if karma/jest configured.
- Grep output for raw hex/px → replace with tokens.
- Re-compare with the source design: spacing, alignment, state coverage.
- Report: files created, tokens used, deviations from the design and why.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each its own standalone component in `components/angular/<name>/`. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: inputs in, outputs out, zero form state. Form controls implement `ControlValueAccessor` so they bind to reactive forms.
- **Layout** component arranges projected content only (`<ng-content select>` slots, grid/gap/responsive collapse).
- **Composite** builds a `FormGroup` (typed reactive forms) with validators + input masking, binds child controls via `formControlName`, wires label/error a11y (`for`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues` input, `submitted(values)` / `cancelled` outputs, `loading` input. It is the single usable entry point.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
