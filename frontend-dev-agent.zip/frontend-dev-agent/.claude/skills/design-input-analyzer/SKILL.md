---
name: design-input-analyzer
description: Analyze a design input — Figma screenshot/export image, PDF page, or Figma frame description — and produce a structured Component Spec (JSON) describing layout, elements, states, colors, typography, spacing, and responsive behavior. Use whenever the user provides a design image, PDF, or Figma export and wants a component built from it. This skill produces the spec only; component generators consume it.
---

# Design Input Analyzer

Turn a visual design (image / PDF / Figma export) into a machine-readable **Component Spec** that downstream generator skills consume. Never generate framework code from this skill — output the spec only.

## Inputs accepted

1. **Image** (png/jpg of a Figma frame or mockup) — read it visually.
2. **PDF** — render pages to images first (`pdftoppm -png design.pdf page`), then analyze each page.
3. **Figma text export / dev-mode CSS** — parse values directly; prefer exact values over visual estimation.

## Analysis procedure

1. **Identify the component boundary.** Decide if the input is one component or a screen composed of several. If a screen, list each candidate component and ask the user which to generate (or spec all of them).
2. **Decompose the visual hierarchy** top-down: container → sections → elements (buttons, inputs, labels, icons, images, badges, tables…).
3. **Measure/estimate values:**
   - Colors: sample dominant fill, text, border colors as hex. Flag estimates with `"confidence": "estimated"`.
   - Typography: font size, weight, line-height, case.
   - Spacing: padding/gaps normalized to a 4px scale (4, 8, 12, 16, 24, 32, 48, 64).
   - Radii, shadows, borders.
4. **Infer states** even if not shown: hover, focus-visible, active, disabled, loading, error, empty. Mark inferred states `"inferred": true`.
5. **Infer behavior & API:** what is configurable (props/inputs), what events are emitted, what content is slotted/projected.
6. **Accessibility notes:** role, aria attributes, keyboard interactions, contrast concerns (flag anything under WCAG AA 4.5:1).
7. **Responsive intent:** how it should collapse/reflow at sm/md/lg.

## Output format — Component Spec

Write to `specs/<component-name>.spec.json`:

```json
{
  "name": "OrderSummaryCard",
  "type": "component",
  "description": "Card showing order line items with totals and a checkout CTA",
  "source": { "kind": "figma-image", "file": "order-card.png" },
  "layout": {
    "display": "flex", "direction": "column", "gap": "16",
    "padding": "24", "radius": "lg", "shadow": "md", "maxWidth": "420px"
  },
  "elements": [
    {
      "id": "title", "role": "heading", "level": 2,
      "text": "Order summary",
      "typography": { "size": "18", "weight": "600", "color": "text-primary" }
    },
    {
      "id": "checkout-btn", "role": "button", "variant": "primary",
      "text": "Checkout", "states": ["hover", "focus", "disabled", "loading"],
      "emits": "checkout"
    }
  ],
  "tokensUsed": ["color.surface", "color.text-primary", "color.brand-primary", "radius.lg", "shadow.md"],
  "props": [
    { "name": "items", "type": "OrderItem[]", "required": true },
    { "name": "currency", "type": "string", "default": "USD" },
    { "name": "loading", "type": "boolean", "default": false }
  ],
  "events": [{ "name": "checkout", "payload": "void" }],
  "a11y": { "role": "region", "label": "Order summary", "keyboard": ["Enter/Space activates checkout"] },
  "responsive": { "sm": "full-width, padding 16", "md+": "fixed 420px" },
  "confidence": { "colors": "estimated", "spacing": "estimated", "structure": "high" }
}
```

## Rules

- Map every color/size to a **token reference** (`color.brand-primary`) when a token file exists in the repo (check `tokens/design-tokens.json`); fall back to raw hex plus a `"needsToken": true` flag so design-token-extractor can register it.
- One spec file per component. Screens get a `type: "screen"` spec listing child component spec refs.
- Always end by reporting: spec path, components found, low-confidence items needing human confirmation.

## Composite designs (complete forms, multi-element widgets)

When the input is a complete form or a widget built from repeated primitives — e.g. a payment form with a card preview, labeled fields, and action buttons — do NOT spec it as one flat component. Produce a **spec tree**:

1. **Atoms** — one spec per reusable primitive found in the design: `FormLabel`, `TextInput` (variants: prefix icon, masked value), `Button`, `CardPreview`. First check `design-system-app/src/data/components.json` and existing `components/` — reference existing components instead of re-speccing them.
2. **Molecules** — `FormField` = FormLabel + control + help/error text, wired via `htmlFor`/`aria-describedby`.
3. **Layout** — a separate layout component (`FormLayout`) that owns ONLY grid, column spans, gaps, and responsive collapse (e.g. 2-column `2fr/1fr` grid → single column on mobile). No business content, children via slots.
4. **Composite** — the whole usable component (`UpdatePaymentMethodForm`) with `"type": "composite"` and `"children": ["specs/CardPreview.spec.json", "specs/FormField.spec.json", …]`. Its spec defines the form model (fields, validation, input masks like `1234 1234 1234 1234`, `06 / 2028`, CVV masking), state handling, and events (`submit` with form values, `cancel`).

Worked example — "Update payment method" design decomposes to:
`CardPreview` (gradient panel, contactless icon, name/expiry/masked number) · `FormLabel` · `TextInput` (variants: plain, card-number with brand icon, expiry segmented, CVV masked) · `FormField` · `Button` (primary/secondary) · `FormLayout` (rows: full, 2fr/1fr, footer actions) · `UpdatePaymentMethodForm` (composite root).

One spec file per node in `specs/`. Generators build children first, composite last.
