---
name: design-token-extractor
description: Extract, normalize, and maintain design tokens (colors, typography, spacing, radii, shadows) from design inputs or Component Specs, and emit multi-brand CSS custom properties plus a Tailwind config mapping. Use when the user provides design tokens, asks to set up theming/whitelabel/brand overrides, or when a Component Spec contains raw values flagged needsToken.
---

# Design Token Extractor

Own the token pipeline: raw design values → canonical `tokens/design-tokens.json` → generated CSS variables (per brand) → Tailwind mapping. Components must never hard-code raw values; they reference tokens only.

## Token architecture (3 layers)

1. **Primitive** — raw palette: `blue-600: #2563eb`, `space-4: 16px`. Never referenced by components.
2. **Semantic** — meaning: `color.brand-primary → {blue-600}`, `color.surface`, `color.text-primary`, `radius.lg`. This is the whitelabel override surface.
3. **Component** — optional per-component: `button.primary.bg → {color.brand-primary}`.

## Multi-brand model (whitelabel)

- The **default brand** defines every semantic variable on `:root`.
- Each **partner brand** is a CSS file that redefines only semantic variables under `[data-brand="partner-x"]`. Primitives are shared; partners may add their own.
- Switching brand = setting `data-brand` on `<html>`. No rebuild, no component change.

## Procedure

1. Read existing `tokens/design-tokens.json` if present — merge, never clobber. Preserve token names already referenced by components.
2. Ingest new values from: Figma variable export JSON, dev-mode CSS, a Component Spec's `needsToken` entries, or a brand guideline doc.
3. Normalize: hex lowercase, spacing snapped to 4px scale, name with kebab-case semantic names (`color.text-muted`, not `color.gray-2`).
4. Update the canonical JSON:

```json
{
  "primitive": {
    "color": { "blue-600": "#2563eb", "gray-900": "#111827" },
    "space": { "4": "1rem" }
  },
  "semantic": {
    "color": {
      "brand-primary": "{primitive.color.blue-600}",
      "text-primary": "{primitive.color.gray-900}"
    },
    "radius": { "lg": "0.75rem" },
    "shadow": { "md": "0 4px 12px rgb(0 0 0 / 0.08)" }
  },
  "brands": {
    "default": {},
    "partner-a": { "semantic.color.brand-primary": "#0d9488" }
  }
}
```

5. Regenerate outputs:
   - `tokens/css/default.css` — all semantic tokens as `--ds-*` variables on `:root` (e.g. `--ds-color-brand-primary`).
   - `tokens/css/<brand>.css` — overrides under `[data-brand="<brand>"]`.
   - `tokens/tailwind.tokens.js` — Tailwind `theme.extend` mapping every utility to `var(--ds-*)` (e.g. `colors: { 'brand-primary': 'var(--ds-color-brand-primary)' }`), so `bg-brand-primary` is brand-aware automatically.

## Rules

- CSS variable naming: `--ds-<category>-<name>` (`--ds-color-brand-primary`, `--ds-radius-lg`, `--ds-space-4`).
- Never emit raw hex into a brand override that duplicates the default — only actual differences.
- Validate contrast for each brand: `text-primary` on `surface` must meet WCAG AA; report failures, don't silently accept.
- End by reporting: tokens added/changed, brands regenerated, any naming conflicts.
