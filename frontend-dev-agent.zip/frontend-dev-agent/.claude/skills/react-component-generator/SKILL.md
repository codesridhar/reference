---
name: react-component-generator
description: Generate a production-quality React component (TypeScript + Tailwind, token-driven, accessible, multi-brand safe) from a Component Spec JSON produced by design-input-analyzer, or directly from a short description. Use when the user asks for a React component, JSX/TSX implementation, or to implement a spec in React.
---

# React Component Generator

Consume a Component Spec (`specs/*.spec.json`) and emit a React component that matches the design and the repo's conventions. If no spec exists for the request, first invoke `design-input-analyzer` (or ask the orchestrator to).

## Stack contract

- **TypeScript, function components, hooks.** No class components.
- **Tailwind utilities backed by CSS variables** from `tokens/` (`bg-brand-primary` → `var(--ds-color-brand-primary)`). Never hard-code hex, px shadows, or radii — if a needed token is missing, stop and route to `design-token-extractor` first.
- Multi-brand: components must render correctly under any `data-brand`; brand awareness comes only from CSS variables, never from JS brand checks.

## Output files (per component)

```
components/react/<ComponentName>/
├── <ComponentName>.tsx        # component
├── <ComponentName>.types.ts   # exported Props interface + domain types
├── <ComponentName>.test.tsx   # RTL tests: render, props, events, a11y roles
├── <ComponentName>.stories.tsx# Storybook CSF3 (skip if repo has no Storybook)
└── index.ts                   # barrel export
```

Match existing repo structure if it differs — inspect `components/react/` first and follow what's there.

## Generation rules

1. **Props from spec** — every `props[]` entry becomes a typed prop; spread-safe `className` passthrough; `...rest` forwarded to the root element. Use `forwardRef` when the root is interactive or form-related.
2. **States** — implement every state in the spec: hover/focus via Tailwind variants (`hover:`, `focus-visible:`), disabled via prop + `aria-disabled`, loading with spinner + `aria-busy`. Focus rings always visible (`focus-visible:ring-2 ring-brand-primary`).
3. **Events** — `on<Event>` callback props typed with payloads from the spec.
4. **Accessibility** — semantic elements first (`button`, not `div onClick`); apply the spec's `a11y` block; label every icon-only control; keyboard interactions per spec.
5. **Responsive** — implement the spec's `responsive` block with Tailwind breakpoints (`sm: md: lg:`), mobile-first.
6. **Composition** — content areas from the spec become `children` or named slot props (`header`, `footer`, `actions`); don't bake in copy that the spec marks as content.
7. **No new dependencies** without asking. Icons: use the repo's existing icon library, else inline SVG.

## Quality gate (before finishing)

- `tsc --noEmit` passes; tests pass if a test runner is configured.
- Grep your own output for raw hex / raw px values → replace with tokens.
- Verify against the source image once more: spacing rhythm, alignment, state coverage.
- Report: files created, tokens used, deviations from the design and why.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each in its own `components/react/<Name>/` folder. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: props in, events out, zero form state.
- **Layout** component arranges named slots only (grid/gap/responsive collapse) — accepts children, no content of its own.
- **Composite** imports the children, owns form state + validation + input masking, wires label/error a11y (`htmlFor`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues`, `onSubmit(values)`, `onCancel`, `loading`. It is the single usable entry point — a consumer renders ONE component.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
