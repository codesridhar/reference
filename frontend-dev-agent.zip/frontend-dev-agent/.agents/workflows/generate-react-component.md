# Generate React component from spec

Generate a React component from `specs/<Name>.spec.json` (run `/analyze-design` first if none exists).

Stack: TypeScript function components + hooks; Tailwind utilities backed by `--ds-*` variables. No raw hex/px — missing token means `/extract-tokens` first. Must render correctly under any `data-brand` with zero JS brand logic.

Files (match existing repo conventions): `components/react/<Name>/` → `<Name>.tsx`, `<Name>.types.ts`, `<Name>.test.tsx` (RTL), `<Name>.stories.tsx` (if Storybook), `index.ts`.

Rules: spec props → typed props + `className` passthrough + `forwardRef` on interactive roots; implement every spec state (`hover:`/`focus-visible:`, `aria-disabled`, `aria-busy` + spinner, visible focus ring); events → `on<Event>` typed callbacks; semantic elements + spec a11y block; mobile-first responsive per spec; content areas → `children`/slot props; no new dependencies without asking.

Quality gate: `tsc --noEmit` and tests pass, no raw hex/px in output, visual re-check vs source. Register in `design-system-app/src/data/components.json`, then report files, tokens used, deviations.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each in its own `components/react/<Name>/` folder. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: props in, events out, zero form state.
- **Layout** component arranges named slots only (grid/gap/responsive collapse) — accepts children, no content of its own.
- **Composite** imports the children, owns form state + validation + input masking, wires label/error a11y (`htmlFor`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues`, `onSubmit(values)`, `onCancel`, `loading`. It is the single usable entry point — a consumer renders ONE component.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
