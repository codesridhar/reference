# Generate Angular component from spec

Generate an Angular component from `specs/<name>.spec.json` (run `/analyze-design` first if none exists).

Stack: standalone components, signals, `input()`/`output()`, OnPush, `@if`/`@for`/`@switch`. Tailwind utilities backed by `--ds-*` variables; SCSS only for what utilities can't express. No raw hex/px — missing token means `/extract-tokens` first. No brand logic in TypeScript.

Files (match repo conventions + `angular.json` prefix): `components/angular/<name>/` → `<name>.component.ts` (inline template if < ~40 lines), `.html`, `.scss`, `.spec.ts` (TestBed), `index.ts`.

Rules: spec props → `input<T>()`/`input.required<T>()`; events → `output<T>()`; prefer `host` bindings over wrapper divs; implement every spec state (hover/focus-visible, `[attr.aria-disabled]` + block emit, `aria-busy` + spinner, visible focus ring); content areas → `<ng-content select>`/`TemplateRef`; semantic elements + spec a11y block; form controls implement `ControlValueAccessor`; pre-v17 repos follow existing idioms; no new dependencies without asking.

Quality gate: build and specs pass, no raw hex/px, visual re-check vs source. Register in `design-system-app/src/data/components.json`, then report files, tokens used, deviations.

## Composite specs (spec tree)

When the spec is `"type": "composite"`, generate **depth-first**: atoms → molecules → layout → composite, each its own standalone component in `components/angular/<name>/`. Reuse components already in the registry instead of regenerating.

- **Atoms/molecules** stay presentational: inputs in, outputs out, zero form state. Form controls implement `ControlValueAccessor` so they bind to reactive forms.
- **Layout** component arranges projected content only (`<ng-content select>` slots, grid/gap/responsive collapse).
- **Composite** builds a `FormGroup` (typed reactive forms) with validators + input masking, binds child controls via `formControlName`, wires label/error a11y (`for`, `aria-describedby`, `aria-invalid`), and exposes the public API: `initialValues` input, `submitted(values)` / `cancelled` outputs, `loading` input. It is the single usable entry point.
- Test the composite end-to-end (fill → validate → submit payload) and atoms in isolation. Register every new component, atoms included, in the docs registry.
