# Analyze design → Component Spec

Analyze the attached/referenced design input (Figma screenshot, image, or PDF page — render PDFs to images first) and write `specs/<ComponentName>.spec.json`. Do NOT generate framework code.

1. Identify the component boundary; if it's a full screen, list candidate components and confirm scope.
2. Decompose hierarchy: container → sections → elements.
3. Estimate values: colors (hex, mark `"confidence": "estimated"`), typography, spacing snapped to a 4px scale, radii, shadows.
4. Infer states even if not shown (hover, focus-visible, active, disabled, loading, error, empty) — mark `"inferred": true`.
5. Infer the API: props, events, slotted content.
6. Add a11y block (role, aria, keyboard, contrast flags vs WCAG AA) and responsive intent (sm/md/lg).

Spec fields: name, description, source, layout, elements[], tokensUsed[], props[], events[], a11y, responsive, confidence.

Reference tokens from `tokens/design-tokens.json` where they exist; otherwise raw value + `"needsToken": true`. Finish by reporting the spec path and low-confidence items.

## Composite designs (complete forms, multi-element widgets)

When the input is a complete form or a widget built from repeated primitives — e.g. a payment form with a card preview, labeled fields, and action buttons — do NOT spec it as one flat component. Produce a **spec tree**:

1. **Atoms** — one spec per reusable primitive found in the design: `FormLabel`, `TextInput` (variants: prefix icon, masked value), `Button`, `CardPreview`. First check `design-system-app/src/data/components.json` and existing `components/` — reference existing components instead of re-speccing them.
2. **Molecules** — `FormField` = FormLabel + control + help/error text, wired via `htmlFor`/`aria-describedby`.
3. **Layout** — a separate layout component (`FormLayout`) that owns ONLY grid, column spans, gaps, and responsive collapse (e.g. 2-column `2fr/1fr` grid → single column on mobile). No business content, children via slots.
4. **Composite** — the whole usable component (`UpdatePaymentMethodForm`) with `"type": "composite"` and `"children": ["specs/CardPreview.spec.json", "specs/FormField.spec.json", …]`. Its spec defines the form model (fields, validation, input masks like `1234 1234 1234 1234`, `06 / 2028`, CVV masking), state handling, and events (`submit` with form values, `cancel`).

Worked example — "Update payment method" design decomposes to:
`CardPreview` (gradient panel, contactless icon, name/expiry/masked number) · `FormLabel` · `TextInput` (variants: plain, card-number with brand icon, expiry segmented, CVV masked) · `FormField` · `Button` (primary/secondary) · `FormLayout` (rows: full, 2fr/1fr, footer actions) · `UpdatePaymentMethodForm` (composite root).

One spec file per node in `specs/`. Generators build children first, composite last.
