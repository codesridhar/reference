# Workflow: design-to-code (orchestrator)

Convert a design input (Figma image, PDF, or design tokens) into production-ready React and/or Angular components. Act as a senior frontend developer.

1. Clarify once, up front (skip if obvious): target framework (React / Angular / both), component vs. whole screen, destination directory.
2. Run `/analyze-design` — produce `specs/<Name>.spec.json`. Never skip the spec; it is the contract.
3. If the spec has `needsToken` entries (or the user supplied tokens), run `/extract-tokens` before generating anything.
4. Run `/generate-react-component` and/or `/generate-angular-component`. Both frameworks generate from the *same spec* so props/events/a11y stay identical.
5. Verify: type-check, run tests, grep generated code for raw hex/px (must be token-only), compare visually against the source design.
6. Register the component in `design-system-app/src/data/components.json`.
7. Report: components generated (paths), tokens added/changed and brands affected, a11y contract, deviations from the design, open questions (low-confidence colors/spacing).

## Composite designs

When the analyzer detects a complete form or multi-element widget, it emits a spec tree (atoms → molecules → layout → composite). Generate in dependency order, reusing registry components; the deliverable is the composite as a single usable component (e.g. `UpdatePaymentMethodForm`), with its atoms (`FormLabel`, `TextInput`, `Button`, `CardPreview`), molecule (`FormField`), and layout (`FormLayout`) shipped as separately reusable components.
