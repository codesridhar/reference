# Extract design tokens → multi-brand CSS + Tailwind

Maintain the token pipeline: raw values → `tokens/design-tokens.json` → per-brand CSS variables → Tailwind mapping.

Architecture: **primitive** (raw palette, never referenced by components) → **semantic** (`color.brand-primary` — the whitelabel override surface) → optional **component** tokens. Default brand defines all semantic vars on `:root`; partners override only differences under `[data-brand="<brand>"]`.

1. Read existing `tokens/design-tokens.json`; merge, never clobber names components already reference.
2. Ingest new values (Figma variable export, dev-mode CSS, spec `needsToken` entries).
3. Normalize: lowercase hex, 4px spacing scale, kebab-case semantic names.
4. Regenerate: `tokens/css/default.css` (`--ds-*` on `:root`), `tokens/css/<brand>.css` (only actual diffs), `tokens/tailwind.tokens.js` (`theme.extend` → `var(--ds-*)`).
5. Validate WCAG AA contrast per brand; report failures.

Finish by reporting tokens added/changed, brands regenerated, conflicts.
