# Design system rules (always in effect)

- **Token-only styling.** Components never contain raw hex colors, px shadows, or radii. Use Tailwind utilities backed by `--ds-*` CSS variables from `tokens/css/`. Missing token → add it via the token pipeline first (`/extract-tokens`).
- **Multi-brand / whitelabel.** Brands switch via `data-brand` on `<html>`; overrides live only in `tokens/css/<brand>.css` under `[data-brand="…"]`. Never branch on brand in JS/TS.
- **Spec-first.** Components are generated from `specs/*.spec.json` (see `/analyze-design`). Keep spec and implementation in sync.
- **React**: TypeScript function components, hooks, Tailwind, `on<Event>` callbacks, `className` passthrough, `forwardRef` on interactive roots, RTL tests, under `components/react/<Name>/`.
- **Angular**: standalone components, signals, `input()`/`output()`, OnPush, `@if`/`@for`, `ControlValueAccessor` for form controls, under `components/angular/<name>/`.
- **Accessibility (WCAG 2.1 AA)**: semantic elements, keyboard support, visible `focus-visible` rings, 4.5:1 contrast on every brand, `aria-*` per the component spec.
- After adding a component, register it in `design-system-app/src/data/components.json` so the docs app stays current.
