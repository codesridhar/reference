# Frontend Developer Agent — Design-to-Code Pipeline

Converts design inputs (**Figma images, PDFs, design tokens**) into production-ready **React** and **Angular** components — for **Claude Code**, **GitHub Copilot**, **Cursor**, and **Google Antigravity** — with a multi-brand (whitelabel) design system and a documentation app.

## Repository layout

```
frontend-dev-agent/
├── .claude/                        # Claude Code
│   ├── agents/frontend-developer.md      # orchestrator agent
│   └── skills/                           # 4 modular skills
│       ├── design-input-analyzer/        # image/PDF → Component Spec JSON
│       ├── design-token-extractor/       # tokens → brand CSS vars + Tailwind map
│       ├── react-component-generator/    # spec → React (TS + Tailwind)
│       └── angular-component-generator/  # spec → Angular (standalone + signals)
├── .github/                        # GitHub Copilot
│   ├── copilot-instructions.md           # repo-wide rules
│   ├── chatmodes/frontend-developer.chatmode.md   # "Frontend Developer" chat mode
│   ├── agents/frontend-developer.agent.md         # Copilot custom agent profile
│   ├── skills/                           # Agent Skills (open SKILL.md standard, same 4 skills)
│   └── prompts/                          # slash prompts mirroring the skills
│       ├── analyze-design.prompt.md
│       ├── extract-tokens.prompt.md
│       ├── generate-react-component.prompt.md
│       └── generate-angular-component.prompt.md
├── .copilot/                       # Copilot CLI user-level bundle (copy to ~/.copilot/)
│   ├── agents/frontend-developer.md      # custom agent profile
│   └── skills/                           # same 4 skills, available in every repo
├── .cursor/                        # Cursor
│   ├── rules/design-system.mdc           # always-on token/brand/a11y rules
│   ├── rules/frontend-developer.mdc      # pipeline rule (auto-attached on design tasks)
│   └── commands/                         # /analyze-design, /extract-tokens,
│                                         # /generate-react-component, /generate-angular-component
├── .agents/                        # Google Antigravity
│   ├── rules/design-system.md            # always-on rules
│   └── workflows/                        # /design-to-code (orchestrator) + 4 stage workflows
├── tokens/                         # single source of truth for theming
│   ├── design-tokens.json                # canonical 3-layer tokens + brand overrides
│   ├── css/default.css                   # :root --ds-* variables
│   ├── css/partner-a.css                 # [data-brand="partner-a"] overrides
│   ├── css/partner-b.css
│   ├── css/partner-c.css                 # Colors.pdf teal/cyan palette
│   └── tailwind.tokens.js                # Tailwind theme.extend → var(--ds-*)
├── specs/                          # generated Component Specs (pipeline artifacts)
└── design-system-app/              # React + Vite documentation app
```

## The pipeline

```
design input (Figma image / PDF / tokens)
   → [1] design-input-analyzer      → specs/<Name>.spec.json
   → [2] design-token-extractor     → tokens/* (only when new values appear)
   → [3] react/angular generator    → components/react/* or components/angular/*
   → [4] verify                     → type-check, tests, token-purity grep, visual diff
   → [5] docs registration          → design-system-app/src/data/components.json
```

The **Component Spec** is the contract: both framework generators consume the same spec, so React and Angular components stay behaviorally identical (same props/inputs, events/outputs, a11y).

## Using with Claude Code

Copy `.claude/` (and `tokens/`) into your project, then:

```
> Use the frontend-developer agent to implement design/checkout-card.png as a React component
> Implement the same spec in Angular
> Register these brand tokens from figma-variables.json
```

Skills also trigger individually ("analyze this design", "extract tokens from…").

## Using with GitHub Copilot (VS Code)

Copy `.github/` (and `tokens/`) into your repo. Then in Copilot Chat:

1. Select the **Frontend Developer** chat mode, or
2. Use prompts directly: `/analyze-design` (attach image) → `/extract-tokens` → `/generate-react-component` / `/generate-angular-component`.

`copilot-instructions.md` enforces the token/brand/a11y rules on every completion.

Newer Copilot versions also pick up:

- **Custom agent**: `.github/agents/frontend-developer.agent.md` — run with `copilot --agent=frontend-developer --prompt "…"` (CLI) or select it in chat.
- **Agent Skills**: `.github/skills/` holds the same four SKILL.md skills (open standard shared with Claude — Copilot also reads `.claude/skills/` directly). Invoke via `/skill-name`.

## Using with Copilot CLI (user-level, `~/.copilot/`)

To make the agent available in *every* repo without copying files per project:

```bash
cp -R .copilot/agents ~/.copilot/agents
cp -R .copilot/skills ~/.copilot/skills
copilot --agent=frontend-developer --prompt "Implement design/checkout-card.png as a React component"
```

## Using with Cursor

Copy `.cursor/` (and `tokens/`) into your repo:

- `design-system.mdc` applies the token/brand/a11y rules to every request.
- `frontend-developer.mdc` auto-attaches the pipeline when you mention implementing a design.
- Slash commands: `/analyze-design` (attach image) → `/extract-tokens` → `/generate-react-component` / `/generate-angular-component`.

## Using with Google Antigravity

Copy `.agents/` (and `tokens/`) into your workspace:

- `rules/design-system.md` is always in effect.
- Run the whole pipeline with `/design-to-code`, or invoke stages individually: `/analyze-design`, `/extract-tokens`, `/generate-react-component`, `/generate-angular-component`.

## Multi-brand / whitelabel model

- Default brand defines every semantic token on `:root` (`--ds-color-brand-primary`, …).
- Partners override **only** what differs, under `[data-brand="partner-x"]`.
- Switching brand = `<html data-brand="partner-x">`. No rebuild, no JS brand logic — ever.
- Tailwind utilities map to variables (`bg-brand-primary` → `var(--ds-color-brand-primary)`), so all generated components are brand-aware automatically.

## Design system documentation app

```bash
cd design-system-app
npm install
npm run dev
```

Includes: getting-started guide, live token reference, component gallery with live previews, per-component API/token/a11y/usage docs, guidelines, and a **brand switcher** that re-themes the whole app instantly. New components generated by the agent are auto-registered via `src/data/components.json`.
