/** @type {import('tailwindcss').Config} */
import tokens from '../tokens/tailwind.tokens.js';

export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: tokens,
  },
  plugins: [],
};
