import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  server: {
    fs: {
      // allow importing token CSS from the repo root (../tokens)
      allow: [path.resolve(__dirname, '..')],
    },
  },
});
