import { useState } from 'react';

/* Live preview implementations — token-driven, brand-aware. */

export function DsButton({ variant = 'primary', size = 'md', loading, disabled, children, onClick, ...rest }) {
  const base =
    'inline-flex items-center justify-center gap-2 font-medium rounded-ds-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2';
  const sizes = { sm: 'px-3 py-1.5 text-sm', md: 'px-4 py-2.5 text-sm', lg: 'px-5 py-3 text-base' };
  const variants = {
    primary: 'bg-brand-primary hover:bg-brand-primary-hover text-text-on-brand shadow-ds-sm',
    secondary: 'bg-surface border border-ds-border text-text-primary hover:bg-surface-muted',
    danger: 'bg-danger text-text-on-brand hover:opacity-90',
  };
  const isBlocked = disabled || loading;
  return (
    <button
      type="button"
      className={`${base} ${sizes[size]} ${variants[variant]} ${isBlocked ? 'opacity-50 cursor-not-allowed' : ''}`}
      aria-disabled={disabled || undefined}
      aria-busy={loading || undefined}
      onClick={isBlocked ? undefined : onClick}
      {...rest}
    >
      {loading && (
        <span
          aria-hidden="true"
          className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
        />
      )}
      {children}
    </button>
  );
}

export function DsTextInput({ label, error, disabled, placeholder }) {
  const [value, setValue] = useState('');
  const id = `input-${label?.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className="flex flex-col gap-1 w-64">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <input
        id={id}
        value={value}
        placeholder={placeholder}
        disabled={disabled}
        aria-invalid={!!error || undefined}
        aria-describedby={error ? `${id}-error` : undefined}
        onChange={(e) => setValue(e.target.value)}
        className={`px-3 py-2 text-sm bg-surface border rounded-ds-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary ${
          error ? 'border-danger' : 'border-ds-border'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      />
      {error && (
        <span id={`${id}-error`} className="text-sm text-danger">
          {error}
        </span>
      )}
    </div>
  );
}

export function DsInput({
  label,
  description,
  error,
  disabled,
  placeholder,
  type = 'text',
  inputClassName = '',
  action,
  value: valueProp,
  onChange,
  id: idProp,
}) {
  const [internal, setInternal] = useState('');
  const isControlled = valueProp !== undefined;
  const value = isControlled ? valueProp : internal;
  const id = idProp ?? `ds-input-${label?.toLowerCase().replace(/\s+/g, '-') ?? 'field'}`;
  const descriptionId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [descriptionId, errorId].filter(Boolean).join(' ') || undefined;

  const field = (
    <input
      id={id}
      type={type}
      value={value}
      placeholder={placeholder}
      disabled={disabled}
      aria-invalid={error ? true : undefined}
      aria-describedby={describedBy}
      onChange={(e) => {
        if (!isControlled) setInternal(e.target.value);
        onChange?.(e);
      }}
      className={`block w-full min-h-10 px-3 py-2 text-sm bg-surface text-text-primary placeholder:text-text-placeholder border rounded-ds-sm transition-colors hover:border-border-input-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed ${
        error ? 'border-danger' : 'border-border-input'
      } ${inputClassName}`}
    />
  );

  return (
    <div className="flex flex-col gap-2 w-full font-ds">
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-text-primary">
          {label}
        </label>
      )}
      {action ? (
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">{field}</div>
          <div className="shrink-0">{action}</div>
        </div>
      ) : (
        field
      )}
      {description && (
        <p id={descriptionId} className="text-sm text-text-secondary">
          {description}
        </p>
      )}
      {error && (
        <p id={errorId} className="text-sm text-danger" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function DsCard({ elevated, header, footer, children }) {
  return (
    <div
      className={`bg-surface border border-ds-border rounded-ds-lg overflow-hidden w-80 ${
        elevated ? 'shadow-ds-md' : 'shadow-ds-sm'
      }`}
    >
      {header && <div className="px-5 py-3 border-b border-ds-border font-semibold">{header}</div>}
      <div className="px-5 py-4 text-sm text-text-primary">{children}</div>
      {footer && <div className="px-5 py-3 border-t border-ds-border flex justify-end">{footer}</div>}
    </div>
  );
}

function DimensionsField({ label, defaultValue }) {
  const [value, setValue] = useState(defaultValue);
  const id = `dim-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  return (
    <div className="flex items-center justify-between gap-4">
      <label htmlFor={id} className="text-sm font-medium text-text-primary shrink-0 w-28">
        {label}
      </label>
      <input
        id={id}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="w-40 min-h-9 px-3 py-1.5 text-sm bg-surface text-text-primary border border-border-input rounded-ds-sm hover:border-border-input-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2"
      />
    </div>
  );
}

export function DsPopover({
  title = 'Dimensions',
  description = 'Set the dimensions for the layer.',
  defaultOpen = true,
  triggerLabel = 'Open popover',
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="relative inline-flex font-ds">
      <DsButton
        variant="primary"
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-controls="ds-popover-preview-panel"
        onClick={() => setOpen((v) => !v)}
      >
        {triggerLabel}
      </DsButton>
      {open && (
        <div
          id="ds-popover-preview-panel"
          role="dialog"
          aria-labelledby="ds-popover-preview-title"
          aria-describedby="ds-popover-preview-desc"
          className="absolute left-1/2 top-full z-50 mt-2 w-80 -translate-x-1/2 flex flex-col gap-4 p-6 bg-surface text-text-primary border border-ds-border rounded-ds-md shadow-ds-md"
        >
          <div className="flex flex-col gap-1">
            <h2 id="ds-popover-preview-title" className="text-sm font-semibold text-text-primary m-0">
              {title}
            </h2>
            <p id="ds-popover-preview-desc" className="text-sm text-text-secondary m-0">
              {description}
            </p>
          </div>
          <div className="flex flex-col gap-4">
            <DimensionsField label="Width" defaultValue="100%" />
            <DimensionsField label="Max. width" defaultValue="300px" />
            <DimensionsField label="Height" defaultValue="25px" />
            <DimensionsField label="Max. height" defaultValue="none" />
          </div>
        </div>
      )}
    </div>
  );
}

function MastercardMark({ className = '' }) {
  return (
    <svg className={className} width="36" height="22" viewBox="0 0 36 22" aria-hidden="true">
      <circle cx="13" cy="11" r="9" className="fill-network-mastercard-red" />
      <circle cx="23" cy="11" r="9" className="fill-network-mastercard-orange" />
      <path
        d="M18 4.2c1.9 1.6 3.1 4 3.1 6.8s-1.2 5.2-3.1 6.8c-1.9-1.6-3.1-4-3.1-6.8s1.2-5.2 3.1-6.8z"
        className="fill-network-mastercard-red opacity-80"
      />
    </svg>
  );
}

export function DsCardPreview({
  brand = 'Untitled.',
  cardholderName = 'OLIVIA RHYE',
  expiry = '06/28',
  cardNumber = '1234 1234 1234 1234',
}) {
  return (
    <div className="flex w-full items-center justify-center bg-card-mesh rounded-t-ds-xl px-4 py-6 sm:px-6 sm:py-8 font-ds">
      <div
        role="img"
        aria-label={`Card preview, ${brand}, for ${cardholderName}, expires ${expiry}`}
        className="relative flex w-full max-w-[340px] flex-col justify-between aspect-[1.586] rounded-ds-lg border border-glass-border bg-glass p-5 text-on-glass shadow-ds-lg backdrop-blur-glass"
      >
        <div className="flex items-start justify-between">
          <span className="text-sm font-semibold tracking-tight">{brand}</span>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="opacity-90">
            <path
              d="M8.5 8.5c1.5 1.5 1.5 5.5 0 7M12 6c2.8 2.2 2.8 9.8 0 12M15.5 3.5c4 3.2 4 13.8 0 17"
              stroke="currentColor"
              strokeWidth="1.75"
              strokeLinecap="round"
            />
          </svg>
        </div>
        <div className="mt-auto flex items-end justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="mb-2 flex items-center gap-4">
              <span className="truncate text-xs font-medium uppercase tracking-wider">{cardholderName}</span>
              <span className="shrink-0 text-xs font-medium tabular-nums">{expiry}</span>
            </div>
            <p className="m-0 text-base font-medium tracking-widest tabular-nums">{cardNumber}</p>
          </div>
          <MastercardMark className="shrink-0" />
        </div>
      </div>
    </div>
  );
}

function FormLayoutDemo() {
  return (
    <div className="flex w-full flex-col font-ds">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-[2fr_1fr] md:gap-x-4 md:gap-y-5">
        <DsInput label="Name on card" placeholder="Olivia Rhye" />
        <DsInput label="Expiry" placeholder="06 / 2028" />
        <DsInput label="Card number" placeholder="1234 1234 1234 1234" />
        <DsInput label="CVV" placeholder="•••" type="password" />
      </div>
      <div className="mt-6 grid grid-cols-2 gap-3">
        <DsButton variant="secondary" className="w-full">
          Cancel
        </DsButton>
        <DsButton variant="primary" className="w-full">
          Update
        </DsButton>
      </div>
    </div>
  );
}

function formatCardNumberPreview(value) {
  const digits = value.replace(/\D/g, '').slice(0, 16);
  return digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
}

function formatExpiryPreview(value) {
  const digits = value.replace(/\D/g, '').slice(0, 6);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
}

function formatExpiryShort(value) {
  const digits = value.replace(/\D/g, '');
  if (digits.length < 4) return digits.slice(0, 2);
  return `${digits.slice(0, 2)}/${digits.slice(4, 6) || digits.slice(2, 4)}`;
}

export function DsUpdatePaymentMethodForm() {
  const [nameOnCard, setNameOnCard] = useState('Olivia Rhye');
  const [expiry, setExpiry] = useState('06 / 2028');
  const [cardNumber, setCardNumber] = useState('1234123412341234');
  const [cvv, setCvv] = useState('');

  return (
    <form
      className="flex w-full max-w-md flex-col overflow-hidden rounded-ds-xl border border-ds-border bg-surface shadow-ds-lg font-ds"
      onSubmit={(e) => e.preventDefault()}
      aria-labelledby="upm-preview-title"
      aria-describedby="upm-preview-desc"
    >
      <DsCardPreview
        brand="Untitled."
        cardholderName={nameOnCard.toUpperCase() || '•••• ••••'}
        expiry={formatExpiryShort(expiry) || '••/••'}
        cardNumber={formatCardNumberPreview(cardNumber) || '•••• •••• •••• ••••'}
      />
      <div className="flex flex-col gap-5 p-6">
        <div className="flex flex-col gap-1">
          <h2 id="upm-preview-title" className="m-0 text-lg font-semibold text-text-primary">
            Update payment method
          </h2>
          <p id="upm-preview-desc" className="m-0 text-sm text-text-secondary">
            Update your card details.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-[2fr_1fr] md:gap-x-4 md:gap-y-5">
          <DsInput
            label="Name on card"
            value={nameOnCard}
            onChange={(e) => setNameOnCard(e.target.value)}
          />
          <DsInput
            label="Expiry"
            value={expiry}
            onChange={(e) => setExpiry(formatExpiryPreview(e.target.value))}
          />
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-text-primary" htmlFor="upm-card-number">
              Card number
            </label>
            <div className="flex items-center min-h-10 rounded-ds-sm bg-surface border border-border-input focus-within:ring-2 focus-within:ring-brand-primary focus-within:ring-offset-2">
              <span className="pl-3" aria-hidden="true">
                <MastercardMark className="h-4 w-6" />
              </span>
              <input
                id="upm-card-number"
                value={formatCardNumberPreview(cardNumber)}
                onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, '').slice(0, 16))}
                className="block w-full min-h-10 pl-2 pr-3 py-2 text-sm bg-transparent border-0 focus-visible:outline-none"
              />
            </div>
          </div>
          <DsInput
            label="CVV"
            type="password"
            placeholder="•••"
            value={cvv}
            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <DsButton type="button" variant="secondary" className="w-full">
            Cancel
          </DsButton>
          <DsButton type="submit" variant="primary" className="w-full">
            Update
          </DsButton>
        </div>
      </div>
    </form>
  );
}

/* Preview scenes rendered on component detail pages */
export const previews = {
  button: () => (
    <div className="flex flex-wrap items-center gap-4">
      <DsButton variant="primary">Save changes</DsButton>
      <DsButton variant="secondary">Cancel</DsButton>
      <DsButton variant="danger">Delete</DsButton>
      <DsButton variant="primary" loading>
        Saving…
      </DsButton>
      <DsButton variant="primary" disabled>
        Disabled
      </DsButton>
    </div>
  ),
  'text-input': () => (
    <div className="flex flex-wrap gap-6">
      <DsTextInput label="Email" placeholder="you@company.com" />
      <DsTextInput label="Username" error="Username is already taken" />
      <DsTextInput label="Account ID" disabled placeholder="Read-only" />
    </div>
  ),
  card: () => (
    <div className="flex flex-wrap gap-6">
      <DsCard header="Pro plan" footer={<DsButton size="sm">Upgrade</DsButton>}>
        $29/month — unlimited projects, priority support.
      </DsCard>
      <DsCard elevated>Simple elevated card without header or footer.</DsCard>
    </div>
  ),
  input: () => (
    <div className="flex flex-col gap-8 w-full max-w-xl">
      <DsInput
        label="Email"
        placeholder="Email"
        description="Enter your email address."
        type="email"
        action={<DsButton variant="primary">Subscribe</DsButton>}
      />
      <div className="flex flex-wrap gap-6">
        <div className="w-64">
          <DsInput label="Username" error="Username is already taken" placeholder="jane" />
        </div>
        <div className="w-64">
          <DsInput label="Account ID" disabled placeholder="Read-only" />
        </div>
      </div>
    </div>
  ),
  popover: () => (
    <div className="flex justify-center py-16 w-full min-h-[28rem]">
      <DsPopover defaultOpen />
    </div>
  ),
  'card-preview': () => (
    <div className="w-full max-w-md overflow-hidden rounded-ds-xl border border-ds-border shadow-ds-lg">
      <DsCardPreview
        brand="Untitled."
        cardholderName="OLIVIA RHYE"
        expiry="06/28"
        cardNumber="1234 1234 1234 1234"
      />
    </div>
  ),
  'form-layout': () => (
    <div className="w-full max-w-md">
      <FormLayoutDemo />
    </div>
  ),
  'update-payment-method-form': () => (
    <div className="flex justify-center w-full">
      <DsUpdatePaymentMethodForm />
    </div>
  ),
};
