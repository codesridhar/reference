const brands = [
  { id: 'default', label: 'Default' },
  { id: 'partner-a', label: 'Partner A' },
  { id: 'partner-b', label: 'Partner B' },
  { id: 'partner-c', label: 'Partner C' },
];

export default function BrandSwitcher({ brand, onChange }) {
  return (
    <div>
      <label
        htmlFor="brand-select"
        className="block text-xs font-semibold uppercase tracking-wide text-text-secondary mb-1"
      >
        Brand preview
      </label>
      <select
        id="brand-select"
        value={brand}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-ds-border rounded-ds-md px-2 py-1.5 text-sm bg-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary"
      >
        {brands.map((b) => (
          <option key={b.id} value={b.id}>
            {b.label}
          </option>
        ))}
      </select>
      <p className="text-xs text-text-secondary mt-2">
        Whitelabel via <code>data-brand</code> CSS variables — no rebuild.
      </p>
    </div>
  );
}
