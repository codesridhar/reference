import { NavLink, Route, Routes } from 'react-router-dom';
import { useEffect, useState } from 'react';
import GettingStarted from './pages/GettingStarted.jsx';
import Tokens from './pages/Tokens.jsx';
import Components from './pages/Components.jsx';
import ComponentDetail from './pages/ComponentDetail.jsx';
import Guidelines from './pages/Guidelines.jsx';
import BrandSwitcher from './components/BrandSwitcher.jsx';

const nav = [
  { to: '/', label: 'Getting started', end: true },
  { to: '/tokens', label: 'Design tokens' },
  { to: '/components', label: 'Components' },
  { to: '/guidelines', label: 'Guidelines' },
];

export default function App() {
  const [brand, setBrand] = useState(
    () => localStorage.getItem('ds-brand') || 'default'
  );

  useEffect(() => {
    document.documentElement.setAttribute('data-brand', brand);
    localStorage.setItem('ds-brand', brand);
  }, [brand]);

  return (
    <div className="flex min-h-screen">
      <aside className="w-60 shrink-0 border-r border-ds-border bg-surface flex flex-col">
        <div className="px-5 py-5 border-b border-ds-border">
          <div className="font-semibold text-lg">Design System</div>
          <div className="text-sm text-text-secondary">Team documentation</div>
        </div>
        <nav className="p-3 flex flex-col gap-1">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `px-3 py-2 rounded-ds-md text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-brand-primary text-text-on-brand'
                    : 'text-text-primary hover:bg-surface-muted'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto p-4 border-t border-ds-border">
          <BrandSwitcher brand={brand} onChange={setBrand} />
        </div>
      </aside>

      <main className="flex-1 px-10 py-8 max-w-5xl">
        <Routes>
          <Route path="/" element={<GettingStarted />} />
          <Route path="/tokens" element={<Tokens />} />
          <Route path="/components" element={<Components />} />
          <Route path="/components/:id" element={<ComponentDetail />} />
          <Route path="/guidelines" element={<Guidelines />} />
        </Routes>
      </main>
    </div>
  );
}
