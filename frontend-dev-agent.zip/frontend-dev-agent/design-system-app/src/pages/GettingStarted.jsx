export default function GettingStarted() {
  return (
    <article className="prose-like max-w-3xl">
      <h1 className="text-3xl font-bold mb-2">Getting started</h1>
      <p className="text-text-secondary mb-8">
        How the design system, the token pipeline, and the frontend developer agent fit together.
      </p>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-3">How it works</h2>
        <ol className="list-decimal ml-5 space-y-2 text-sm leading-6">
          <li>
            A designer hands over a Figma frame (image or PDF) or a token export.
          </li>
          <li>
            The <strong>frontend-developer agent</strong> (Claude Code or GitHub Copilot) analyzes it into a{' '}
            <code>Component Spec</code>, registers any new tokens, and generates the React and/or Angular
            component.
          </li>
          <li>
            Generated components use only <code>--ds-*</code> CSS variables via Tailwind — no raw values.
          </li>
          <li>The component is registered here, in the docs app, automatically.</li>
        </ol>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-3">Multi-brand / whitelabel</h2>
        <p className="text-sm leading-6 mb-3">
          One codebase serves multiple brands. The default brand defines every semantic token on{' '}
          <code>:root</code>; each partner overrides only what differs under{' '}
          <code>[data-brand="partner-x"]</code>. Try the brand switcher in the sidebar — every component
          re-themes instantly with no rebuild.
        </p>
        <pre className="bg-surface border border-ds-border rounded-ds-lg p-4 text-xs overflow-auto">
{`<html data-brand="partner-a">  <!-- that's the whole switch -->

[data-brand="partner-a"] {
  --ds-color-brand-primary: #0d9488;
  --ds-radius-md: 0.25rem;
}`}
        </pre>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-3">Using the agent</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-surface border border-ds-border rounded-ds-lg p-4">
            <h3 className="font-semibold mb-2 text-sm">Claude Code</h3>
            <pre className="text-xs overflow-auto">
{`# drop the design in the repo, then:
> Use the frontend-developer agent to
  implement design/checkout-card.png
  as a React component`}
            </pre>
          </div>
          <div className="bg-surface border border-ds-border rounded-ds-lg p-4">
            <h3 className="font-semibold mb-2 text-sm">GitHub Copilot</h3>
            <pre className="text-xs overflow-auto">
{`# select "Frontend Developer" chat mode
/analyze-design  (attach the image)
/generate-react-component
/generate-angular-component`}
            </pre>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-3">Run this app</h2>
        <pre className="bg-surface border border-ds-border rounded-ds-lg p-4 text-xs">
{`cd design-system-app
npm install
npm run dev`}
        </pre>
      </section>
    </article>
  );
}
