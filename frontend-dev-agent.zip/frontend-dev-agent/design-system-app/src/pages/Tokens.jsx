const colorTokens = [
  'brand-primary',
  'brand-primary-hover',
  'brand-accent',
  'surface',
  'surface-muted',
  'border',
  'text-primary',
  'text-secondary',
  'text-on-brand',
  'danger',
  'success',
  'warning',
];

const radiusTokens = ['sm', 'md', 'lg', 'full'];
const shadowTokens = ['sm', 'md', 'lg'];
const spaceTokens = ['1', '2', '3', '4', '6', '8', '12', '16'];

function TokenRow({ cssVar, preview }) {
  return (
    <div className="flex items-center gap-4 py-2 border-b border-ds-border last:border-0">
      {preview}
      <code className="text-xs">{cssVar}</code>
    </div>
  );
}

export default function Tokens() {
  return (
    <article>
      <h1 className="text-3xl font-bold mb-2">Design tokens</h1>
      <p className="text-text-secondary mb-8 max-w-2xl">
        Semantic tokens are the contract between design and code — and the whitelabel override surface.
        Values below are live: switch brands in the sidebar and watch them change.
      </p>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-4">Color</h2>
        <div className="bg-surface border border-ds-border rounded-ds-lg p-5">
          {colorTokens.map((t) => (
            <TokenRow
              key={t}
              cssVar={`--ds-color-${t}`}
              preview={
                <span
                  className="w-10 h-10 rounded-ds-md border border-ds-border shrink-0"
                  style={{ background: `var(--ds-color-${t})` }}
                />
              }
            />
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-4">Radius</h2>
        <div className="bg-surface border border-ds-border rounded-ds-lg p-5 flex gap-8 flex-wrap">
          {radiusTokens.map((t) => (
            <div key={t} className="flex flex-col items-center gap-2">
              <span
                className="w-16 h-16 bg-brand-primary/10 border-2 border-brand-primary"
                style={{ borderRadius: `var(--ds-radius-${t})`, background: 'var(--ds-color-surface-muted)' }}
              />
              <code className="text-xs">--ds-radius-{t}</code>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-4">Shadow</h2>
        <div className="bg-surface border border-ds-border rounded-ds-lg p-8 flex gap-10 flex-wrap">
          {shadowTokens.map((t) => (
            <div key={t} className="flex flex-col items-center gap-3">
              <span
                className="w-24 h-16 bg-surface rounded-ds-md"
                style={{ boxShadow: `var(--ds-shadow-${t})` }}
              />
              <code className="text-xs">--ds-shadow-{t}</code>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Spacing</h2>
        <div className="bg-surface border border-ds-border rounded-ds-lg p-5">
          {spaceTokens.map((t) => (
            <TokenRow
              key={t}
              cssVar={`--ds-space-${t}`}
              preview={
                <span
                  className="h-4 bg-brand-primary rounded-ds-sm shrink-0"
                  style={{ width: `var(--ds-space-${t})` }}
                />
              }
            />
          ))}
        </div>
      </section>
    </article>
  );
}
