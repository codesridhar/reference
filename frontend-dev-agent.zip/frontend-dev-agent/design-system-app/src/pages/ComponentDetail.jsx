import { Link, useParams } from 'react-router-dom';
import { useState } from 'react';
import components from '../data/components.json';
import { previews } from '../components/previews.jsx';

export default function ComponentDetail() {
  const { id } = useParams();
  const comp = components.find((c) => c.id === id);
  const [tab, setTab] = useState('react');

  if (!comp) {
    return (
      <div>
        <p className="mb-4">Component not found.</p>
        <Link to="/components" className="text-brand-primary underline">
          Back to components
        </Link>
      </div>
    );
  }

  const Preview = previews[comp.id];

  return (
    <article>
      <Link to="/components" className="text-sm text-brand-primary hover:underline">
        ← Components
      </Link>
      <div className="flex items-center gap-3 mt-2 mb-1">
        <h1 className="text-3xl font-bold">{comp.name}</h1>
        <span className="text-xs px-2 py-0.5 rounded-ds-full bg-surface-muted border border-ds-border text-text-secondary">
          {comp.status}
        </span>
      </div>
      <p className="text-text-secondary mb-8 max-w-2xl">{comp.description}</p>

      {Preview && (
        <section className="mb-10">
          <h2 className="text-xl font-semibold mb-3">Live preview</h2>
          <div className="bg-surface border border-ds-border rounded-ds-lg p-8">
            <Preview />
          </div>
          <p className="text-xs text-text-secondary mt-2">
            Brand-aware — switch brands in the sidebar.
          </p>
        </section>
      )}

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-3">API</h2>
        <div className="bg-surface border border-ds-border rounded-ds-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-surface-muted text-left">
                <th className="px-4 py-2 font-semibold">Prop / Input</th>
                <th className="px-4 py-2 font-semibold">Type</th>
                <th className="px-4 py-2 font-semibold">Default</th>
                <th className="px-4 py-2 font-semibold">Description</th>
              </tr>
            </thead>
            <tbody>
              {comp.props.map((p) => (
                <tr key={p.name} className="border-t border-ds-border align-top">
                  <td className="px-4 py-2"><code>{p.name}</code></td>
                  <td className="px-4 py-2"><code>{p.type}</code></td>
                  <td className="px-4 py-2"><code>{p.default}</code></td>
                  <td className="px-4 py-2 text-text-secondary">{p.description}</td>
                </tr>
              ))}
              {comp.events.map((e) => (
                <tr key={e.name} className="border-t border-ds-border align-top">
                  <td className="px-4 py-2"><code>{e.name}</code></td>
                  <td className="px-4 py-2"><code>event · {e.payload}</code></td>
                  <td className="px-4 py-2">—</td>
                  <td className="px-4 py-2 text-text-secondary">{e.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-3">Code</h2>
        <div className="flex gap-2 mb-2" role="tablist" aria-label="Framework">
          {comp.frameworks.map((f) => (
            <button
              key={f}
              role="tab"
              aria-selected={tab === f}
              onClick={() => setTab(f)}
              className={`px-3 py-1.5 text-sm rounded-ds-md font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary ${
                tab === f
                  ? 'bg-brand-primary text-text-on-brand'
                  : 'bg-surface border border-ds-border text-text-primary'
              }`}
            >
              {f === 'react' ? 'React' : 'Angular'}
            </button>
          ))}
        </div>
        <pre className="bg-surface border border-ds-border rounded-ds-lg p-4 text-xs overflow-auto">
          {comp.code[tab]}
        </pre>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-3">Tokens used</h2>
        <div className="flex flex-wrap gap-2">
          {comp.tokens.map((t) => (
            <code key={t} className="text-xs">{t}</code>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-3">Accessibility</h2>
        <ul className="list-disc ml-5 text-sm space-y-1">
          {comp.a11y.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-surface border border-ds-border rounded-ds-lg p-5">
          <h3 className="font-semibold text-success mb-2">Do</h3>
          <ul className="list-disc ml-5 text-sm space-y-1">
            {comp.usage.do.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        </div>
        <div className="bg-surface border border-ds-border rounded-ds-lg p-5">
          <h3 className="font-semibold text-danger mb-2">Don't</h3>
          <ul className="list-disc ml-5 text-sm space-y-1">
            {comp.usage.dont.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        </div>
      </section>
    </article>
  );
}
