const sections = [
  {
    title: 'Token usage',
    rules: [
      'Components never contain raw hex colors, px shadows, or radii — only --ds-* variables via Tailwind utilities.',
      'Reference semantic tokens (color.brand-primary), never primitives (blue-600).',
      'A missing token is a token-pipeline task, not an excuse for an inline value.',
    ],
  },
  {
    title: 'Multi-brand / whitelabel',
    rules: [
      'Brand differences live only in tokens/css/<brand>.css under [data-brand="…"].',
      'Never branch on brand in JS/TS — if a brand needs different behavior (not just style), escalate to design review.',
      'Every new component must be visually checked against all active brands before merge.',
      'Partner overrides redefine only what differs; everything else inherits from default.',
    ],
  },
  {
    title: 'Accessibility (WCAG 2.1 AA)',
    rules: [
      'Semantic HTML first: button for actions, a for navigation, native inputs for forms.',
      'Every interactive element has a visible focus-visible ring (ring-brand-primary).',
      'Text contrast ≥ 4.5:1 on every brand — token changes must be re-validated per brand.',
      'Icon-only controls get aria-label; loading states set aria-busy; errors link via aria-describedby.',
      'Full keyboard support: Tab order follows visual order, Enter/Space activate, Escape dismisses.',
    ],
  },
  {
    title: 'Component API conventions',
    rules: [
      'React: typed props, on<Event> callbacks, className passthrough, forwardRef on interactive roots.',
      'Angular: standalone + signals, input()/output(), OnPush, ControlValueAccessor for form controls.',
      'React and Angular versions of the same component share one spec: same props/inputs, events/outputs, and a11y contract.',
      'Content is composable (children / ng-content), not hard-coded.',
    ],
  },
  {
    title: 'Workflow',
    rules: [
      'Every component starts as a Component Spec (specs/*.spec.json) produced by the design-input-analyzer.',
      'Specs are the review artifact: low-confidence colors/spacings are flagged for designer confirmation.',
      'Generated components must pass: type-check, tests, raw-value grep, and visual comparison against the source design.',
      'Register every new component in the docs app (src/data/components.json).',
    ],
  },
];

export default function Guidelines() {
  return (
    <article>
      <h1 className="text-3xl font-bold mb-2">Guidelines</h1>
      <p className="text-text-secondary mb-8 max-w-2xl">
        Rules the team — and the frontend-developer agent — follow for every component.
      </p>
      <div className="space-y-6">
        {sections.map((s) => (
          <section key={s.title} className="bg-surface border border-ds-border rounded-ds-lg p-6">
            <h2 className="text-lg font-semibold mb-3">{s.title}</h2>
            <ul className="list-disc ml-5 text-sm space-y-2">
              {s.rules.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </article>
  );
}
