import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { InputComponent } from './input.component';

@Component({
  standalone: true,
  imports: [InputComponent, ReactiveFormsModule],
  template: `<ds-input label="Email" [formControl]="control" [error]="error" />`,
})
class HostComponent {
  control = new FormControl('initial', { nonNullable: true });
  error: string | undefined;
}

describe('InputComponent', () => {
  let fixture: ComponentFixture<InputComponent>;
  let component: InputComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InputComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(InputComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('label', 'Email');
    fixture.componentRef.setInput('placeholder', 'Email');
    fixture.componentRef.setInput('description', 'Enter your email address.');
    fixture.detectChanges();
  });

  it('renders label, placeholder, and description', () => {
    const el: HTMLElement = fixture.nativeElement;
    expect(el.querySelector('label')?.textContent).toContain('Email');
    expect(el.querySelector('input')?.getAttribute('placeholder')).toBe('Email');
    expect(el.textContent).toContain('Enter your email address.');
  });

  it('links description via aria-describedby', () => {
    const input = fixture.nativeElement.querySelector('input') as HTMLInputElement;
    const description = fixture.nativeElement.querySelector('p') as HTMLParagraphElement;
    expect(input.getAttribute('aria-describedby')).toBe(description.id);
  });

  it('emits valueChange on input', () => {
    const spy = jasmine.createSpy('valueChange');
    component.valueChange.subscribe(spy);
    const input = fixture.nativeElement.querySelector('input') as HTMLInputElement;
    input.value = 'hi';
    input.dispatchEvent(new Event('input'));
    expect(spy).toHaveBeenCalledWith('hi');
  });

  it('sets aria-invalid when error is present', () => {
    fixture.componentRef.setInput('error', 'Email needs an @');
    fixture.detectChanges();
    const input = fixture.nativeElement.querySelector('input') as HTMLInputElement;
    expect(input.getAttribute('aria-invalid')).toBe('true');
    expect(fixture.nativeElement.querySelector('[role="alert"]')?.textContent).toContain(
      'Email needs an @',
    );
  });

  it('works as a ControlValueAccessor with reactive forms', async () => {
    const hostFixture = TestBed.createComponent(HostComponent);
    hostFixture.detectChanges();
    const input = hostFixture.nativeElement.querySelector('input') as HTMLInputElement;
    expect(input.value).toBe('initial');

    input.value = 'updated';
    input.dispatchEvent(new Event('input'));
    hostFixture.detectChanges();
    expect(hostFixture.componentInstance.control.value).toBe('updated');
  });
});
