export { InputComponent, DsInputStartDirective } from './input.component';
export type { DsInputType } from './input.component';
export type { DsInputType } from './input.component';
