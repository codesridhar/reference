import {
  ChangeDetectionStrategy,
  Component,
  computed,
  contentChild,
  Directive,
  effect,
  forwardRef,
  input,
  output,
  signal,
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
} from '@angular/forms';

let nextId = 0;

export type DsInputType =
  | 'text'
  | 'email'
  | 'password'
  | 'search'
  | 'tel'
  | 'url'
  | 'number';

@Directive({
  selector: '[dsInputStart]',
  standalone: true,
})
export class DsInputStartDirective {}

@Component({
  selector: 'ds-input',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputComponent),
      multi: true,
    },
  ],
  templateUrl: './input.component.html',
  styleUrl: './input.component.scss',
  host: {
    class: 'ds-input-host block w-full',
  },
})
export class InputComponent implements ControlValueAccessor {
  readonly label = input<string | undefined>(undefined);
  readonly description = input<string | undefined>(undefined);
  readonly placeholder = input<string>('');
  readonly type = input<DsInputType>('text');
  readonly name = input<string | undefined>(undefined);
  readonly id = input<string | undefined>(undefined);
  readonly disabledInput = input(false, { alias: 'disabled' });
  readonly readOnly = input(false);
  readonly required = input(false);
  readonly error = input<string | undefined>(undefined);
  readonly className = input('', { alias: 'className' });
  readonly inputClassName = input('');
  readonly ariaLabel = input<string | undefined>(undefined, { alias: 'aria-label' });
  readonly autocomplete = input<string | undefined>(undefined);
  readonly inputMode = input<string | undefined>(undefined);
  readonly maxLength = input<number | undefined>(undefined);
  /** Optional controlled value from parent (in addition to CVA). */
  readonly valueInput = input<string | undefined>(undefined, { alias: 'value' });

  readonly valueChange = output<string>();
  readonly blurred = output<FocusEvent>();
  readonly focused = output<FocusEvent>();

  protected readonly value = signal('');
  protected readonly cvaDisabled = signal(false);

  private readonly startSlot = contentChild(DsInputStartDirective);
  protected readonly hasStartAdornment = computed(() => !!this.startSlot());

  private readonly autoId = `ds-input-${++nextId}`;

  protected readonly fieldId = computed(() => this.id() ?? this.autoId);
  protected readonly descriptionId = computed(() =>
    this.description() ? `${this.fieldId()}-description` : undefined,
  );
  protected readonly errorId = computed(() =>
    this.error() ? `${this.fieldId()}-error` : undefined,
  );
  protected readonly describedBy = computed(() => {
    const ids = [this.descriptionId(), this.errorId()].filter(Boolean);
    return ids.length ? ids.join(' ') : undefined;
  });
  protected readonly isDisabled = computed(
    () => this.disabledInput() || this.cvaDisabled(),
  );
  protected readonly fieldClasses = computed(() => {
    const base = [
      'block w-full min-h-10 px-3 py-2 text-sm font-ds',
      'bg-surface text-text-primary placeholder:text-text-placeholder',
      'border border-border-input rounded-ds-sm',
      'transition-colors',
      'hover:border-border-input-hover',
      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
      'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-border-input',
      'read-only:bg-surface-muted',
    ];
    if (this.error()) base.push('border-danger hover:border-danger');
    if (this.inputClassName()) base.push(this.inputClassName());
    return base.join(' ');
  });

  protected readonly adornmentFieldClasses = computed(() => {
    const base = [
      'block w-full min-h-10 pl-2 pr-3 py-2 text-sm font-ds',
      'bg-transparent text-text-primary placeholder:text-text-placeholder',
      'border-0 rounded-ds-sm focus-visible:outline-none',
      'disabled:opacity-50 disabled:cursor-not-allowed',
    ];
    if (this.inputClassName()) base.push(this.inputClassName());
    return base.join(' ');
  });

  private onChange: (value: string) => void = () => undefined;
  private onTouched: () => void = () => undefined;

  constructor() {
    effect(() => {
      const incoming = this.valueInput();
      if (incoming !== undefined) {
        this.value.set(incoming);
      }
    });
  }

  writeValue(value: string | null): void {
    this.value.set(value ?? '');
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.cvaDisabled.set(isDisabled);
  }

  protected onInput(event: Event): void {
    const next = (event.target as HTMLInputElement).value;
    this.value.set(next);
    this.onChange(next);
    this.valueChange.emit(next);
  }

  protected onBlur(event: FocusEvent): void {
    this.onTouched();
    this.blurred.emit(event);
  }

  protected onFocus(event: FocusEvent): void {
    this.focused.emit(event);
  }
}
