import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CardPreviewComponent } from './card-preview.component';

describe('CardPreviewComponent', () => {
  let fixture: ComponentFixture<CardPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CardPreviewComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CardPreviewComponent);
    fixture.componentRef.setInput('brand', 'Untitled.');
    fixture.componentRef.setInput('cardholderName', 'OLIVIA RHYE');
    fixture.componentRef.setInput('expiry', '06/28');
    fixture.componentRef.setInput('cardNumber', '1234 1234 1234 1234');
    fixture.detectChanges();
  });

  it('renders card content', () => {
    const el: HTMLElement = fixture.nativeElement;
    expect(el.textContent).toContain('Untitled.');
    expect(el.textContent).toContain('OLIVIA RHYE');
    expect(el.textContent).toContain('06/28');
    expect(el.textContent).toContain('1234 1234 1234 1234');
  });

  it('exposes an accessible summary', () => {
    const img = fixture.nativeElement.querySelector('[role="img"]') as HTMLElement;
    expect(img.getAttribute('aria-label')).toContain('ending 1234');
  });
});
