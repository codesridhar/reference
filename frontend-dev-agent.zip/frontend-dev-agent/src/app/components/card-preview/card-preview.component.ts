import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

export type DsCardNetwork = 'mastercard' | 'visa' | 'amex' | 'generic';

@Component({
  selector: 'ds-card-preview',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './card-preview.component.html',
  styleUrl: './card-preview.component.scss',
  host: {
    class: 'ds-card-preview-host block w-full',
  },
})
export class CardPreviewComponent {
  readonly brand = input('Untitled.');
  readonly cardholderName = input('');
  readonly expiry = input('');
  readonly cardNumber = input('');
  readonly network = input<DsCardNetwork>('mastercard');
  readonly className = input('', { alias: 'className' });

  protected readonly ariaLabel = computed(() => {
    const digits = this.cardNumber().replace(/\D/g, '');
    const last4 = digits.slice(-4) || '••••';
    return [
      'Card preview',
      this.brand(),
      this.cardholderName() ? `for ${this.cardholderName()}` : null,
      this.cardNumber() ? `ending ${last4}` : null,
      this.expiry() ? `expires ${this.expiry()}` : null,
    ]
      .filter(Boolean)
      .join(', ');
  });

  protected readonly displayName = computed(
    () => this.cardholderName() || '•••• ••••',
  );
  protected readonly displayExpiry = computed(() => this.expiry() || '••/••');
  protected readonly displayNumber = computed(
    () => this.cardNumber() || '•••• •••• •••• ••••',
  );
}
