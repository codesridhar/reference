import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { FormLayoutComponent } from './form-layout.component';

@Component({
  standalone: true,
  imports: [FormLayoutComponent],
  template: `
    <ds-form-layout>
      <span dsFormFields>Field A</span>
      <button type="button" dsFormActions>Save</button>
    </ds-form-layout>
  `,
})
class HostComponent {}

describe('FormLayoutComponent', () => {
  let fixture: ComponentFixture<HostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(HostComponent);
    fixture.detectChanges();
  });

  it('projects fields and actions', () => {
    const el: HTMLElement = fixture.nativeElement;
    expect(el.textContent).toContain('Field A');
    expect(el.textContent).toContain('Save');
  });
});
