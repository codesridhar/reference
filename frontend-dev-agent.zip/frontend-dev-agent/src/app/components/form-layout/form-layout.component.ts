import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'ds-form-layout',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './form-layout.component.html',
  styleUrl: './form-layout.component.scss',
  host: {
    class: 'ds-form-layout-host block w-full',
  },
})
export class FormLayoutComponent {
  readonly className = input('', { alias: 'className' });
  readonly fieldsClassName = input('');
  readonly actionsClassName = input('');
}
