import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';
import { PopoverComponent } from './popover.component';

@Component({
  standalone: true,
  imports: [PopoverComponent],
  template: `
    <ds-popover
      [title]="title"
      [description]="description"
      [defaultOpen]="defaultOpen"
      [aria-label]="ariaLabel"
      (openChange)="onOpenChange($event)"
    >
      <button type="button" dsPopoverTrigger>Open</button>
      <span>Body content</span>
    </ds-popover>
  `,
})
class HostComponent {
  title = 'Dimensions';
  description = 'Set the dimensions for the layer.';
  defaultOpen = false;
  ariaLabel: string | undefined;
  lastOpen: boolean | undefined;
  onOpenChange(open: boolean) {
    this.lastOpen = open;
  }
}

describe('PopoverComponent', () => {
  let fixture: ComponentFixture<HostComponent>;
  let host: HostComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(HostComponent);
    host = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('renders the trigger and keeps the panel closed by default', () => {
    const button = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    expect(button.textContent).toContain('Open');
    expect(button.getAttribute('aria-expanded')).toBe('false');
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeNull();
  });

  it('opens on trigger click and exposes dialog a11y', () => {
    const button = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    button.click();
    fixture.detectChanges();

    const dialog = fixture.nativeElement.querySelector('[role="dialog"]') as HTMLElement;
    expect(dialog).toBeTruthy();
    expect(button.getAttribute('aria-expanded')).toBe('true');
    expect(dialog.querySelector('h2')?.textContent).toContain('Dimensions');
    expect(dialog.textContent).toContain('Set the dimensions for the layer.');
    expect(dialog.getAttribute('aria-labelledby')).toBeTruthy();
    expect(host.lastOpen).toBe(true);
  });

  it('closes on Escape', () => {
    host.defaultOpen = true;
    fixture = TestBed.createComponent(HostComponent);
    host = fixture.componentInstance;
    host.defaultOpen = true;
    fixture.detectChanges();

    const popover = fixture.debugElement.children[0].componentInstance as PopoverComponent;
    // Force open via trigger click for reliable state
    const button = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    button.click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeTruthy();

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeNull();
    void popover;
  });

  it('uses aria-label when title is omitted', () => {
    host.title = '';
    host.ariaLabel = 'Layer settings';
    fixture.detectChanges();

    const button = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    button.click();
    fixture.detectChanges();

    const dialog = fixture.nativeElement.querySelector('[role="dialog"]') as HTMLElement;
    expect(dialog.getAttribute('aria-label')).toBe('Layer settings');
  });
});
