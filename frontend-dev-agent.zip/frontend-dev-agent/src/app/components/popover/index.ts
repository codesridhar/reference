export { PopoverComponent } from './popover.component';
export type { DsPopoverSide, DsPopoverAlign } from './popover.component';
