import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  HostListener,
  OnInit,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
  viewChild,
} from '@angular/core';

export type DsPopoverSide = 'top' | 'right' | 'bottom' | 'left';
export type DsPopoverAlign = 'start' | 'center' | 'end';

const OFFSET_PX = 8;

@Component({
  selector: 'ds-popover',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './popover.component.html',
  styleUrl: './popover.component.scss',
  host: {
    class: 'ds-popover-host relative inline-flex',
  },
})
export class PopoverComponent implements OnInit {
  private readonly host = inject(ElementRef<HTMLElement>);

  readonly title = input<string | undefined>(undefined);
  readonly description = input<string | undefined>(undefined);
  readonly openInput = input<boolean | undefined>(undefined, { alias: 'open' });
  readonly defaultOpen = input(false);
  readonly side = input<DsPopoverSide>('bottom');
  readonly align = input<DsPopoverAlign>('center');
  readonly closeOnOutsideClick = input(true);
  readonly closeOnEscape = input(true);
  readonly className = input('', { alias: 'className' });
  readonly contentClassName = input('');
  readonly ariaLabel = input<string | undefined>(undefined, { alias: 'aria-label' });

  readonly openChange = output<boolean>();

  private static nextId = 0;
  protected readonly panelId = `ds-popover-${++PopoverComponent.nextId}`;
  protected readonly titleId = computed(() =>
    this.title() ? `${this.panelId}-title` : undefined,
  );
  protected readonly descriptionId = computed(() =>
    this.description() ? `${this.panelId}-description` : undefined,
  );

  private readonly uncontrolledOpen = signal(false);

  protected readonly isOpen = computed(() => {
    const controlled = this.openInput();
    if (controlled !== undefined) return controlled;
    return this.uncontrolledOpen();
  });

  protected readonly panelClasses = computed(() => {
    const base = [
      'fixed z-50 flex flex-col gap-4 w-80 max-w-full',
      'p-6 bg-surface text-text-primary border border-ds-border',
      'rounded-ds-md shadow-ds-md font-ds',
      'focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
    ];
    if (this.contentClassName()) base.push(this.contentClassName());
    return base.join(' ');
  });

  protected readonly panelTop = signal('0px');
  protected readonly panelLeft = signal('0px');
  protected readonly panelVisibility = signal<'hidden' | 'visible'>('hidden');

  private readonly triggerRef = viewChild<ElementRef<HTMLElement>>('triggerWrap');
  private readonly panelRef = viewChild<ElementRef<HTMLElement>>('panel');

  constructor() {
    effect(() => {
      const open = this.isOpen();
      queueMicrotask(() => this.syncTriggerAria());
      if (!open) {
        this.panelVisibility.set('hidden');
        return;
      }
      queueMicrotask(() => {
        this.updatePosition();
        this.focusPanel();
      });
    });
  }

  ngOnInit(): void {
    this.uncontrolledOpen.set(this.defaultOpen());
    this.syncTriggerAria();
  }

  protected toggle(): void {
    this.setOpen(!this.isOpen());
  }

  protected setOpen(next: boolean): void {
    if (this.openInput() === undefined) {
      this.uncontrolledOpen.set(next);
    }
    this.openChange.emit(next);
    if (!next) {
      queueMicrotask(() => this.focusTrigger());
    }
  }

  @HostListener('document:keydown', ['$event'])
  protected onDocumentKeydown(event: KeyboardEvent): void {
    if (!this.isOpen() || !this.closeOnEscape()) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      this.setOpen(false);
    }
  }

  @HostListener('document:pointerdown', ['$event'])
  protected onDocumentPointerDown(event: PointerEvent): void {
    if (!this.isOpen() || !this.closeOnOutsideClick()) return;
    const target = event.target as Node;
    if (this.host.nativeElement.contains(target)) return;
    this.setOpen(false);
  }

  @HostListener('window:resize')
  @HostListener('window:scroll')
  protected onViewportChange(): void {
    if (this.isOpen()) this.updatePosition();
  }

  private syncTriggerAria(): void {
    const triggerRoot = this.triggerRef()?.nativeElement;
    if (!triggerRoot) return;
    const control = triggerRoot.querySelector<HTMLElement>(
      'button, [href], [role="button"]',
    );
    const el = control ?? triggerRoot;
    el.setAttribute('aria-haspopup', 'dialog');
    el.setAttribute('aria-expanded', String(this.isOpen()));
    el.setAttribute('aria-controls', this.panelId);
  }

  private updatePosition(): void {
    const triggerRoot = this.triggerRef()?.nativeElement;
    const triggerEl =
      triggerRoot?.querySelector<HTMLElement>(
        'button, [href], input, [tabindex]:not([tabindex="-1"])',
      ) ?? triggerRoot;
    const panelEl = this.panelRef()?.nativeElement;
    if (!triggerEl || !panelEl) return;

    const triggerRect = triggerEl.getBoundingClientRect();
    const panelRect = panelEl.getBoundingClientRect();
    const side = this.side();
    const align = this.align();

    let top = 0;
    let left = 0;

    if (side === 'bottom') top = triggerRect.bottom + OFFSET_PX;
    else if (side === 'top') top = triggerRect.top - panelRect.height - OFFSET_PX;
    else if (side === 'left') left = triggerRect.left - panelRect.width - OFFSET_PX;
    else left = triggerRect.right + OFFSET_PX;

    if (side === 'top' || side === 'bottom') {
      if (align === 'start') left = triggerRect.left;
      else if (align === 'end') left = triggerRect.right - panelRect.width;
      else left = triggerRect.left + (triggerRect.width - panelRect.width) / 2;
    } else if (align === 'start') {
      top = triggerRect.top;
    } else if (align === 'end') {
      top = triggerRect.bottom - panelRect.height;
    } else {
      top = triggerRect.top + (triggerRect.height - panelRect.height) / 2;
    }

    const margin = 8;
    left = Math.min(Math.max(margin, left), window.innerWidth - panelRect.width - margin);
    top = Math.min(Math.max(margin, top), window.innerHeight - panelRect.height - margin);

    this.panelTop.set(`${top}px`);
    this.panelLeft.set(`${left}px`);
    this.panelVisibility.set('visible');
  }

  private focusPanel(): void {
    const panel = this.panelRef()?.nativeElement;
    if (!panel) return;
    const focusable = panel.querySelector<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    );
    (focusable ?? panel).focus();
  }

  private focusTrigger(): void {
    const triggerRoot = this.triggerRef()?.nativeElement;
    const focusable = triggerRoot?.querySelector<HTMLElement>(
      'button, [href], input, [tabindex]:not([tabindex="-1"])',
    );
    (focusable ?? triggerRoot)?.focus();
  }
}
