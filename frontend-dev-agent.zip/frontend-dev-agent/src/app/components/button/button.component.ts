import {
  ChangeDetectionStrategy,
  Component,
  input,
  output,
} from '@angular/core';

export type DsButtonVariant = 'primary' | 'secondary' | 'danger';
export type DsButtonSize = 'sm' | 'md' | 'lg';

@Component({
  selector: 'ds-button',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './button.component.html',
  styleUrl: './button.component.scss',
  host: {
    class: 'ds-button-host inline-flex',
  },
})
export class ButtonComponent {
  readonly variant = input<DsButtonVariant>('primary');
  readonly size = input<DsButtonSize>('md');
  readonly loading = input(false);
  readonly disabled = input(false);
  readonly type = input<'button' | 'submit' | 'reset'>('button');
  readonly className = input('', { alias: 'className' });

  readonly clicked = output<MouseEvent>();

  protected isBlocked(): boolean {
    return this.disabled() || this.loading();
  }

  protected classes(): string {
    const base = [
      'inline-flex items-center justify-center gap-2 font-medium font-ds',
      'rounded-ds-md transition-colors',
      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
    ];
    const sizes: Record<DsButtonSize, string> = {
      sm: 'min-h-9 px-3 py-1.5 text-sm',
      md: 'min-h-11 px-4 py-2.5 text-sm',
      lg: 'min-h-12 px-5 py-3 text-base',
    };
    const variants: Record<DsButtonVariant, string> = {
      primary:
        'bg-brand-primary hover:bg-brand-primary-hover text-text-on-brand shadow-ds-sm',
      secondary:
        'bg-surface border border-ds-border text-text-primary hover:bg-surface-muted',
      danger: 'bg-danger text-text-on-brand hover:opacity-90',
    };
    const blocked = this.isBlocked() ? 'opacity-50 cursor-not-allowed' : '';
    return [...base, sizes[this.size()], variants[this.variant()], blocked, this.className()]
      .filter(Boolean)
      .join(' ');
  }

  protected onClick(event: MouseEvent): void {
    if (this.isBlocked()) {
      event.preventDefault();
      return;
    }
    this.clicked.emit(event);
  }
}
