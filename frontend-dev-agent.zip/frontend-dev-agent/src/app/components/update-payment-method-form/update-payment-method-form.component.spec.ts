import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdatePaymentMethodFormComponent } from './update-payment-method-form.component';

describe('UpdatePaymentMethodFormComponent', () => {
  let fixture: ComponentFixture<UpdatePaymentMethodFormComponent>;
  let component: UpdatePaymentMethodFormComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdatePaymentMethodFormComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(UpdatePaymentMethodFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('renders title and actions', () => {
    const el: HTMLElement = fixture.nativeElement;
    expect(el.textContent).toContain('Update payment method');
    expect(el.textContent).toContain('Update your card details.');
    expect(el.textContent).toContain('Cancel');
    expect(el.textContent).toContain('Update');
  });

  it('emits cancelled when Cancel is clicked', () => {
    const spy = jasmine.createSpy('cancelled');
    component.cancelled.subscribe(spy);
    const buttons = fixture.nativeElement.querySelectorAll('button');
    const cancel = Array.from(buttons as NodeListOf<HTMLButtonElement>).find((b) =>
      b.textContent?.includes('Cancel'),
    );
    cancel?.click();
    expect(spy).toHaveBeenCalled();
  });

  it('emits submitted with valid values', () => {
    const spy = jasmine.createSpy('submitted');
    component.submitted.subscribe(spy);
    fixture.componentRef.setInput('initialValues', {
      nameOnCard: 'Olivia Rhye',
      expiry: '06 / 2028',
      cardNumber: '1234123412341234',
      cvv: '123',
    });
    fixture.detectChanges();

    const form = fixture.nativeElement.querySelector('form') as HTMLFormElement;
    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    fixture.detectChanges();

    expect(spy).toHaveBeenCalledWith({
      nameOnCard: 'Olivia Rhye',
      expiry: '06 / 2028',
      cardNumber: '1234123412341234',
      cvv: '123',
    });
  });
});
