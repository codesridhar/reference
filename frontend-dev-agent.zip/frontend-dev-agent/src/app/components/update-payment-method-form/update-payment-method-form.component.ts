import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  input,
  output,
  signal,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ButtonComponent } from '../button/button.component';
import { CardPreviewComponent } from '../card-preview/card-preview.component';
import { FormLayoutComponent } from '../form-layout/form-layout.component';
import {
  DsInputStartDirective,
  InputComponent,
} from '../input/input.component';
import {
  digitsOnly,
  formatCardExpiryShort,
  formatCardNumber,
  formatExpiry,
  validatePaymentMethod,
  type PaymentMethodValues,
} from './payment-masks';

let nextFormId = 0;

@Component({
  selector: 'ds-update-payment-method-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    ReactiveFormsModule,
    ButtonComponent,
    CardPreviewComponent,
    FormLayoutComponent,
    InputComponent,
    DsInputStartDirective,
  ],
  templateUrl: './update-payment-method-form.component.html',
  styleUrl: './update-payment-method-form.component.scss',
  host: {
    class: 'ds-update-payment-method-form-host block w-full',
  },
})
export class UpdatePaymentMethodFormComponent {
  readonly initialValues = input<Partial<PaymentMethodValues> | undefined>(undefined);
  readonly brand = input('Untitled.');
  readonly loading = input(false);
  readonly title = input('Update payment method');
  readonly description = input('Update your card details.');
  readonly cancelLabel = input('Cancel');
  readonly submitLabel = input('Update');
  readonly className = input('', { alias: 'className' });

  readonly submitted = output<PaymentMethodValues>();
  readonly cancelled = output<void>();

  private readonly formId = `ds-upm-${++nextFormId}`;
  protected readonly titleId = `${this.formId}-title`;
  protected readonly descriptionId = `${this.formId}-description`;

  protected readonly form = new FormGroup({
    nameOnCard: new FormControl('Olivia Rhye', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2)],
    }),
    expiry: new FormControl('06 / 2028', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    cardNumber: new FormControl('1234123412341234', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    cvv: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(3), Validators.maxLength(4)],
    }),
  });

  protected readonly fieldErrors = signal<Partial<Record<keyof PaymentMethodValues, string>>>(
    {},
  );
  protected readonly showErrors = signal(false);

  /** Tick to recompute preview computed values when form changes. */
  protected readonly formTick = signal(0);

  protected readonly previewName = computed(() => {
    this.formTick();
    return (this.form.controls.nameOnCard.value || '').toUpperCase();
  });
  protected readonly previewExpiry = computed(() => {
    this.formTick();
    return formatCardExpiryShort(this.form.controls.expiry.value);
  });
  protected readonly previewNumber = computed(() => {
    this.formTick();
    return formatCardNumber(this.form.controls.cardNumber.value);
  });
  protected readonly displayCardNumber = computed(() => {
    this.formTick();
    return formatCardNumber(this.form.controls.cardNumber.value);
  });
  protected readonly displayName = computed(() => {
    this.formTick();
    return this.form.controls.nameOnCard.value;
  });
  protected readonly displayExpiry = computed(() => {
    this.formTick();
    return this.form.controls.expiry.value;
  });
  protected readonly displayCvv = computed(() => {
    this.formTick();
    return this.form.controls.cvv.value;
  });

  constructor() {
    effect(() => {
      const seed = this.initialValues();
      if (!seed) return;
      this.form.patchValue({
        nameOnCard: seed.nameOnCard ?? this.form.controls.nameOnCard.value,
        expiry: seed.expiry ? formatExpiry(seed.expiry) : this.form.controls.expiry.value,
        cardNumber: seed.cardNumber
          ? digitsOnly(seed.cardNumber)
          : this.form.controls.cardNumber.value,
        cvv: seed.cvv ?? this.form.controls.cvv.value,
      });
      this.formTick.update((n) => n + 1);
    });
  }

  protected onNameChange(value: string): void {
    this.form.controls.nameOnCard.setValue(value);
    this.formTick.update((n) => n + 1);
  }

  protected onExpiryChange(value: string): void {
    this.form.controls.expiry.setValue(formatExpiry(value));
    this.formTick.update((n) => n + 1);
  }

  protected onCardNumberChange(value: string): void {
    this.form.controls.cardNumber.setValue(digitsOnly(value).slice(0, 16));
    this.formTick.update((n) => n + 1);
  }

  protected onCvvChange(value: string): void {
    this.form.controls.cvv.setValue(digitsOnly(value).slice(0, 4));
    this.formTick.update((n) => n + 1);
  }

  protected errorFor(key: keyof PaymentMethodValues): string | undefined {
    if (!this.showErrors()) return undefined;
    return this.fieldErrors()[key];
  }

  protected onCancel(): void {
    this.cancelled.emit();
  }

  protected onSubmit(event: Event): void {
    event.preventDefault();
    const values: PaymentMethodValues = {
      nameOnCard: this.form.controls.nameOnCard.value,
      expiry: formatExpiry(this.form.controls.expiry.value),
      cardNumber: digitsOnly(this.form.controls.cardNumber.value),
      cvv: this.form.controls.cvv.value,
    };
    const errors = validatePaymentMethod(values);
    this.fieldErrors.set(errors);
    this.showErrors.set(true);
    if (Object.keys(errors).length > 0) return;
    this.submitted.emit({
      nameOnCard: values.nameOnCard.trim(),
      expiry: values.expiry,
      cardNumber: values.cardNumber,
      cvv: values.cvv,
    });
  }
}
