/** Keep digits only. */
export function digitsOnly(value: string): string {
  return value.replace(/\D/g, '');
}

/** Format up to 16 digits as "1234 1234 1234 1234". */
export function formatCardNumber(value: string): string {
  const digits = digitsOnly(value).slice(0, 16);
  return digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
}

/** Format expiry as "MM / YYYY". */
export function formatExpiry(value: string): string {
  const digits = digitsOnly(value).slice(0, 6);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
}

/** Card face expiry "MM/YY" from "MM / YYYY" or digits. */
export function formatCardExpiryShort(value: string): string {
  const digits = digitsOnly(value);
  if (digits.length < 2) return digits;
  const mm = digits.slice(0, 2);
  if (digits.length < 4) return mm;
  const yyyy = digits.slice(2, 6);
  const yy = yyyy.length === 4 ? yyyy.slice(2) : yyyy;
  return `${mm}/${yy}`;
}

export interface PaymentMethodValues {
  nameOnCard: string;
  expiry: string;
  cardNumber: string;
  cvv: string;
}

export function validatePaymentMethod(
  values: PaymentMethodValues,
): Partial<Record<keyof PaymentMethodValues, string>> {
  const errors: Partial<Record<keyof PaymentMethodValues, string>> = {};

  if (values.nameOnCard.trim().length < 2) {
    errors.nameOnCard = 'Enter the name on the card';
  }

  const expiryDigits = digitsOnly(values.expiry);
  if (!/^(0[1-9]|1[0-2])\d{4}$/.test(expiryDigits)) {
    errors.expiry = 'Enter expiry as MM / YYYY';
  }

  const numberDigits = digitsOnly(values.cardNumber);
  if (numberDigits.length !== 16) {
    errors.cardNumber = 'Enter a 16-digit card number';
  }

  if (!/^\d{3,4}$/.test(values.cvv)) {
    errors.cvv = 'Enter a 3 or 4 digit CVV';
  }

  return errors;
}
