import type { CardNetwork } from './CardPreview.types';

export function MastercardLogo({ className = '' }: { className?: string }) {
  return (
    <svg
      className={className}
      width="36"
      height="22"
      viewBox="0 0 36 22"
      aria-hidden="true"
      focusable="false"
    >
      <circle cx="13" cy="11" r="9" className="fill-network-mastercard-red" />
      <circle cx="23" cy="11" r="9" className="fill-network-mastercard-orange" />
      <path
        d="M18 4.2c1.9 1.6 3.1 4 3.1 6.8s-1.2 5.2-3.1 6.8c-1.9-1.6-3.1-4-3.1-6.8s1.2-5.2 3.1-6.8z"
        className="fill-network-mastercard-red opacity-80"
      />
    </svg>
  );
}

export function ContactlessIcon({ className = '' }: { className?: string }) {
  return (
    <svg
      className={className}
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <path
        d="M8.5 8.5c1.5 1.5 1.5 5.5 0 7M12 6c2.8 2.2 2.8 9.8 0 12M15.5 3.5c4 3.2 4 13.8 0 17"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function NetworkLogo({
  network,
  className = '',
}: {
  network: CardNetwork;
  className?: string;
}) {
  if (network === 'mastercard') {
    return <MastercardLogo className={className} />;
  }
  return (
    <span
      className={`text-[10px] font-semibold uppercase tracking-wide text-on-glass ${className}`}
    >
      {network}
    </span>
  );
}
