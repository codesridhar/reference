import { render, screen } from '@testing-library/react';
import { CardPreview } from './CardPreview';

describe('CardPreview', () => {
  it('renders brand, name, expiry, and number', () => {
    render(
      <CardPreview
        brand="Untitled."
        cardholderName="OLIVIA RHYE"
        expiry="06/28"
        cardNumber="1234 1234 1234 1234"
      />,
    );

    expect(screen.getByText('Untitled.')).toBeInTheDocument();
    expect(screen.getByText('OLIVIA RHYE')).toBeInTheDocument();
    expect(screen.getByText('06/28')).toBeInTheDocument();
    expect(screen.getByText('1234 1234 1234 1234')).toBeInTheDocument();
  });

  it('exposes an accessible summary label', () => {
    render(
      <CardPreview
        brand="Untitled."
        cardholderName="Olivia Rhye"
        expiry="06/28"
        cardNumber="1234 1234 1234 1234"
      />,
    );

    expect(
      screen.getByRole('img', {
        name: /Card preview, Untitled\., for Olivia Rhye, ending 1234, expires 06\/28/i,
      }),
    ).toBeInTheDocument();
  });
});
