import { ContactlessIcon, NetworkLogo } from './CardIcons';
import type { CardPreviewProps } from './CardPreview.types';

function lastFour(cardNumber: string): string {
  const digits = cardNumber.replace(/\D/g, '');
  return digits.slice(-4) || '••••';
}

export function CardPreview({
  brand = 'Untitled.',
  cardholderName = '',
  expiry = '',
  cardNumber = '',
  network = 'mastercard',
  className = '',
}: CardPreviewProps) {
  const label = [
    'Card preview',
    brand,
    cardholderName ? `for ${cardholderName}` : null,
    cardNumber ? `ending ${lastFour(cardNumber)}` : null,
    expiry ? `expires ${expiry}` : null,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <div
      className={[
        'flex w-full items-center justify-center bg-card-mesh',
        'rounded-t-ds-xl px-4 py-6 sm:px-6 sm:py-8',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
    >
      <div
        role="img"
        aria-label={label}
        className={[
          'relative flex w-full max-w-[340px] flex-col justify-between',
          'aspect-[1.586] rounded-ds-lg border border-glass-border bg-glass',
          'p-5 text-on-glass shadow-ds-lg backdrop-blur-glass',
        ].join(' ')}
      >
        <div className="flex items-start justify-between">
          <span className="text-sm font-semibold tracking-tight">{brand}</span>
          <ContactlessIcon className="text-on-glass opacity-90" />
        </div>

        <div className="mt-auto flex items-end justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="mb-2 flex items-center gap-4">
              <span className="truncate text-xs font-medium uppercase tracking-wider">
                {cardholderName || '•••• ••••'}
              </span>
              <span className="shrink-0 text-xs font-medium tabular-nums">
                {expiry || '••/••'}
              </span>
            </div>
            <p className="m-0 text-base font-medium tracking-widest tabular-nums">
              {cardNumber || '•••• •••• •••• ••••'}
            </p>
          </div>
          <NetworkLogo network={network} className="shrink-0" />
        </div>
      </div>
    </div>
  );
}

export type { CardNetwork, CardPreviewProps } from './CardPreview.types';
