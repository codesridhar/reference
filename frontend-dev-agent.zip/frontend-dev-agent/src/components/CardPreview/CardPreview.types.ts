export type CardNetwork = 'mastercard' | 'visa' | 'amex' | 'generic';

export interface CardPreviewProps {
  /** Brand wordmark on the card face. */
  brand?: string;
  /** Cardholder name; displayed uppercase. */
  cardholderName?: string;
  /** Expiry shown on card (e.g. 06/28). */
  expiry?: string;
  /** Card number; typically space-grouped. */
  cardNumber?: string;
  /** Payment network logo. */
  network?: CardNetwork;
  /** Passthrough class on the mesh panel root. */
  className?: string;
}
