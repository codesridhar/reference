import { createRef } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Popover } from './Popover';

describe('Popover', () => {
  it('renders the trigger and keeps the panel closed by default', () => {
    render(
      <Popover trigger={<button type="button">Open</button>} title="Dimensions">
        <span>Body</span>
      </Popover>,
    );

    expect(screen.getByRole('button', { name: 'Open' })).toHaveAttribute(
      'aria-expanded',
      'false',
    );
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('opens on trigger click and exposes dialog a11y attrs', async () => {
    const user = userEvent.setup();
    render(
      <Popover
        trigger={<button type="button">Open</button>}
        title="Dimensions"
        description="Set the dimensions for the layer."
      >
        <span>Body</span>
      </Popover>,
    );

    await user.click(screen.getByRole('button', { name: 'Open' }));

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Open' })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
    expect(screen.getByRole('heading', { name: 'Dimensions' })).toBeInTheDocument();
    expect(screen.getByText('Set the dimensions for the layer.')).toBeInTheDocument();
    expect(dialog.getAttribute('aria-labelledby')).toBeTruthy();
    expect(dialog.getAttribute('aria-describedby')).toBeTruthy();
  });

  it('calls onOpenChange when toggled', async () => {
    const user = userEvent.setup();
    const onOpenChange = jest.fn();
    render(
      <Popover
        trigger={<button type="button">Open</button>}
        onOpenChange={onOpenChange}
      >
        Content
      </Popover>,
    );

    await user.click(screen.getByRole('button', { name: 'Open' }));
    expect(onOpenChange).toHaveBeenCalledWith(true);
  });

  it('closes on Escape and returns focus to the trigger', async () => {
    const user = userEvent.setup();
    render(
      <Popover
        defaultOpen
        trigger={<button type="button">Open</button>}
        title="Dimensions"
      >
        Content
      </Popover>,
    );

    expect(await screen.findByRole('dialog')).toBeInTheDocument();
    await user.keyboard('{Escape}');
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
    expect(screen.getByRole('button', { name: 'Open' })).toHaveFocus();
  });

  it('supports controlled open state', () => {
    const { rerender } = render(
      <Popover open={false} trigger={<button type="button">Open</button>} title="T">
        Body
      </Popover>,
    );
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();

    rerender(
      <Popover open trigger={<button type="button">Open</button>} title="T">
        Body
      </Popover>,
    );
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('forwards ref to the root wrapper', () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <Popover ref={ref} trigger={<button type="button">Open</button>}>
        Body
      </Popover>,
    );
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it('uses aria-label when title is omitted', async () => {
    const user = userEvent.setup();
    render(
      <Popover
        trigger={<button type="button">Open</button>}
        aria-label="Layer settings"
      >
        Body
      </Popover>,
    );
    await user.click(screen.getByRole('button', { name: 'Open' }));
    expect(await screen.findByRole('dialog', { name: 'Layer settings' })).toBeInTheDocument();
  });
});
