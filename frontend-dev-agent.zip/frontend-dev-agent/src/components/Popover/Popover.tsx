import {
  cloneElement,
  forwardRef,
  isValidElement,
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent as ReactKeyboardEvent,
  type MouseEvent as ReactMouseEvent,
  type ReactElement,
  type Ref,
} from 'react';
import { createPortal } from 'react-dom';
import type { PopoverAlign, PopoverProps, PopoverSide } from './Popover.types';

const OFFSET_PX = 8;

const panelBase = [
  'z-50 flex flex-col gap-4 w-80 max-w-full',
  'p-6 bg-surface text-text-primary border border-ds-border',
  'rounded-ds-md shadow-ds-md font-ds',
  'focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
].join(' ');
const titleBase = 'text-sm font-semibold text-text-primary m-0';
const descriptionBase = 'text-sm text-text-secondary m-0';

function mergeRefs<T>(...refs: Array<Ref<T> | undefined>) {
  return (node: T | null) => {
    for (const ref of refs) {
      if (!ref) continue;
      if (typeof ref === 'function') ref(node);
      else (ref as { current: T | null }).current = node;
    }
  };
}

function computePosition(
  triggerRect: DOMRect,
  panelRect: DOMRect,
  side: PopoverSide,
  align: PopoverAlign,
): { top: number; left: number } {
  let top = 0;
  let left = 0;

  if (side === 'bottom') {
    top = triggerRect.bottom + OFFSET_PX;
  } else if (side === 'top') {
    top = triggerRect.top - panelRect.height - OFFSET_PX;
  } else if (side === 'left') {
    left = triggerRect.left - panelRect.width - OFFSET_PX;
  } else {
    left = triggerRect.right + OFFSET_PX;
  }

  if (side === 'top' || side === 'bottom') {
    if (align === 'start') left = triggerRect.left;
    else if (align === 'end') left = triggerRect.right - panelRect.width;
    else left = triggerRect.left + (triggerRect.width - panelRect.width) / 2;
  } else if (align === 'start') {
    top = triggerRect.top;
  } else if (align === 'end') {
    top = triggerRect.bottom - panelRect.height;
  } else {
    top = triggerRect.top + (triggerRect.height - panelRect.height) / 2;
  }

  const margin = 8;
  left = Math.min(Math.max(margin, left), window.innerWidth - panelRect.width - margin);
  top = Math.min(Math.max(margin, top), window.innerHeight - panelRect.height - margin);

  return { top, left };
}

export const Popover = forwardRef<HTMLDivElement, PopoverProps>(function Popover(
  {
    trigger,
    title,
    description,
    children,
    open: openProp,
    defaultOpen = false,
    onOpenChange,
    side = 'bottom',
    align = 'center',
    closeOnOutsideClick = true,
    closeOnEscape = true,
    className = '',
    contentClassName = '',
    'aria-label': ariaLabel,
  },
  ref,
) {
  const reactId = useId();
  const panelId = `ds-popover-${reactId}`;
  const titleId = title ? `${panelId}-title` : undefined;
  const descriptionId = description ? `${panelId}-description` : undefined;

  const isControlled = openProp !== undefined;
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const open = isControlled ? Boolean(openProp) : internalOpen;

  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [coords, setCoords] = useState<{ top: number; left: number } | null>(null);

  const setOpen = useCallback(
    (next: boolean) => {
      if (!isControlled) setInternalOpen(next);
      onOpenChange?.(next);
    },
    [isControlled, onOpenChange],
  );

  const updatePosition = useCallback(() => {
    const triggerEl = triggerRef.current;
    const panelEl = panelRef.current;
    if (!triggerEl || !panelEl) return;
    const next = computePosition(
      triggerEl.getBoundingClientRect(),
      panelEl.getBoundingClientRect(),
      side,
      align,
    );
    setCoords(next);
  }, [side, align]);

  useLayoutEffect(() => {
    if (!open) {
      setCoords(null);
      return;
    }
    updatePosition();
  }, [open, updatePosition, children, title, description]);

  useEffect(() => {
    if (!open) return;
    const onResize = () => updatePosition();
    window.addEventListener('resize', onResize);
    window.addEventListener('scroll', onResize, true);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('scroll', onResize, true);
    };
  }, [open, updatePosition]);

  useEffect(() => {
    if (!open) return;
    const panel = panelRef.current;
    if (!panel) return;

    const focusable = panel.querySelector<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    );
    (focusable ?? panel).focus();

    return () => {
      triggerRef.current?.focus();
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (closeOnEscape && event.key === 'Escape') {
        event.preventDefault();
        setOpen(false);
      }
    };

    const onPointerDown = (event: MouseEvent | PointerEvent) => {
      if (!closeOnOutsideClick) return;
      const target = event.target as Node;
      if (panelRef.current?.contains(target)) return;
      if (triggerRef.current?.contains(target)) return;
      if (rootRef.current?.contains(target) && !panelRef.current) return;
      setOpen(false);
    };

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('pointerdown', onPointerDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('pointerdown', onPointerDown);
    };
  }, [open, closeOnEscape, closeOnOutsideClick, setOpen]);

  const toggle = (event?: ReactMouseEvent) => {
    event?.stopPropagation();
    setOpen(!open);
  };

  const triggerNode = isValidElement(trigger)
    ? cloneElement(trigger as ReactElement<{
        ref?: Ref<HTMLElement>;
        onClick?: (event: ReactMouseEvent) => void;
        'aria-expanded'?: boolean;
        'aria-haspopup'?: string;
        'aria-controls'?: string;
      }>, {
        ref: mergeRefs(
          triggerRef,
          (trigger as ReactElement & { ref?: Ref<HTMLElement> }).ref,
        ),
        onClick: (event: ReactMouseEvent) => {
          (trigger as ReactElement<{ onClick?: (e: ReactMouseEvent) => void }>).props
            .onClick?.(event);
          toggle(event);
        },
        'aria-expanded': open,
        'aria-haspopup': 'dialog',
        'aria-controls': panelId,
      })
    : (
      <button
        type="button"
        ref={triggerRef as Ref<HTMLButtonElement>}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-controls={panelId}
        onClick={() => toggle()}
        className="inline-flex items-center justify-center font-medium rounded-ds-md px-4 py-2.5 text-sm bg-brand-primary hover:bg-brand-primary-hover text-text-on-brand shadow-ds-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2"
      >
        {trigger}
      </button>
    );

  const panelStyle: CSSProperties = coords
    ? { position: 'fixed', top: coords.top, left: coords.left }
    : { position: 'fixed', top: 0, left: 0, visibility: 'hidden' };

  const panel = open
    ? createPortal(
        <div
          ref={panelRef}
          id={panelId}
          role="dialog"
          aria-modal="false"
          aria-labelledby={titleId}
          aria-describedby={descriptionId}
          aria-label={title ? undefined : ariaLabel}
          tabIndex={-1}
          style={panelStyle}
          className={`${panelBase} ${contentClassName}`.trim()}
          onKeyDown={(event: ReactKeyboardEvent<HTMLDivElement>) => {
            if (closeOnEscape && event.key === 'Escape') {
              event.stopPropagation();
              setOpen(false);
            }
          }}
        >
          {(title || description) && (
            <div className="flex flex-col gap-1">
              {title ? (
                <h2 id={titleId} className={titleBase}>
                  {title}
                </h2>
              ) : null}
              {description ? (
                <p id={descriptionId} className={descriptionBase}>
                  {description}
                </p>
              ) : null}
            </div>
          )}
          {children ? <div className="flex flex-col gap-4">{children}</div> : null}
        </div>,
        document.body,
      )
    : null;

  return (
    <div
      ref={mergeRefs(rootRef, ref)}
      className={`relative inline-flex ${className}`.trim()}
    >
      {triggerNode}
      {panel}
    </div>
  );
});

Popover.displayName = 'Popover';

export type { PopoverProps, PopoverSide, PopoverAlign } from './Popover.types';
