import type { ReactNode } from 'react';

export type PopoverSide = 'top' | 'right' | 'bottom' | 'left';
export type PopoverAlign = 'start' | 'center' | 'end';

export interface PopoverProps {
  /** Element that toggles the popover open/closed. */
  trigger: ReactNode;
  /** Optional panel heading; wires aria-labelledby when set. */
  title?: string;
  /** Optional supporting text under the title. */
  description?: string;
  /** Rich panel body content. */
  children?: ReactNode;
  /** Controlled open state. */
  open?: boolean;
  /** Uncontrolled initial open state. */
  defaultOpen?: boolean;
  /** Fired when open state should change. */
  onOpenChange?: (open: boolean) => void;
  /** Preferred placement relative to the trigger. */
  side?: PopoverSide;
  /** Cross-axis alignment for the chosen side. */
  align?: PopoverAlign;
  /** Dismiss on pointer down outside trigger and panel. */
  closeOnOutsideClick?: boolean;
  /** Dismiss when Escape is pressed. */
  closeOnEscape?: boolean;
  /** Passthrough class on the root (trigger wrapper). */
  className?: string;
  /** Optional class on the floating panel surface. */
  contentClassName?: string;
  /** Accessible name when title is omitted. */
  'aria-label'?: string;
}
