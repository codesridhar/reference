export interface PaymentMethodValues {
  nameOnCard: string;
  /** Display format e.g. "06 / 2028" */
  expiry: string;
  /** Digits only (16). */
  cardNumber: string;
  cvv: string;
}

export interface UpdatePaymentMethodFormProps {
  initialValues?: Partial<PaymentMethodValues>;
  brand?: string;
  loading?: boolean;
  title?: string;
  description?: string;
  cancelLabel?: string;
  submitLabel?: string;
  className?: string;
  onSubmit?: (values: PaymentMethodValues) => void;
  onCancel?: () => void;
}

export type PaymentMethodErrors = Partial<Record<keyof PaymentMethodValues, string>>;
