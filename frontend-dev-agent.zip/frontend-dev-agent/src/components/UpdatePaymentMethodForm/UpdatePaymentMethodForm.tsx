import { FormEvent, useId, useState } from 'react';
import { Button } from '../Button';
import { CardPreview } from '../CardPreview';
import { MastercardLogo } from '../CardPreview/CardIcons';
import { FormLayout } from '../FormLayout';
import { Input } from '../Input';
import {
  digitsOnly,
  formatCardExpiryShort,
  formatCardNumber,
  formatExpiry,
  validatePaymentMethod,
} from './paymentMasks';
import type {
  PaymentMethodErrors,
  PaymentMethodValues,
  UpdatePaymentMethodFormProps,
} from './UpdatePaymentMethodForm.types';

const DEFAULT_VALUES: PaymentMethodValues = {
  nameOnCard: 'Olivia Rhye',
  expiry: '06 / 2028',
  cardNumber: '1234123412341234',
  cvv: '',
};

export function UpdatePaymentMethodForm({
  initialValues,
  brand = 'Untitled.',
  loading = false,
  title = 'Update payment method',
  description = 'Update your card details.',
  cancelLabel = 'Cancel',
  submitLabel = 'Update',
  className = '',
  onSubmit,
  onCancel,
}: UpdatePaymentMethodFormProps) {
  const titleId = useId();
  const descriptionId = useId();

  const [values, setValues] = useState<PaymentMethodValues>({
    ...DEFAULT_VALUES,
    ...initialValues,
    cardNumber: digitsOnly(initialValues?.cardNumber ?? DEFAULT_VALUES.cardNumber),
    expiry: formatExpiry(initialValues?.expiry ?? DEFAULT_VALUES.expiry),
  });
  const [errors, setErrors] = useState<PaymentMethodErrors>({});
  const [touched, setTouched] = useState<Partial<Record<keyof PaymentMethodValues, boolean>>>(
    {},
  );

  const setField = <K extends keyof PaymentMethodValues>(key: K, value: PaymentMethodValues[K]) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  const validateField = (key: keyof PaymentMethodValues, next: PaymentMethodValues) => {
    const all = validatePaymentMethod(next);
    setErrors((prev) => ({ ...prev, [key]: all[key] }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validatePaymentMethod(values);
    setErrors(nextErrors);
    setTouched({
      nameOnCard: true,
      expiry: true,
      cardNumber: true,
      cvv: true,
    });
    if (Object.keys(nextErrors).length > 0) return;
    onSubmit?.({
      nameOnCard: values.nameOnCard.trim(),
      expiry: formatExpiry(values.expiry),
      cardNumber: digitsOnly(values.cardNumber),
      cvv: values.cvv,
    });
  };

  return (
    <form
      className={[
        'flex w-full max-w-md flex-col overflow-hidden',
        'rounded-ds-xl border border-ds-border bg-surface shadow-ds-lg font-ds',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      aria-labelledby={titleId}
      aria-describedby={descriptionId}
      noValidate
      onSubmit={handleSubmit}
    >
      <CardPreview
        brand={brand}
        cardholderName={values.nameOnCard.toUpperCase()}
        expiry={formatCardExpiryShort(values.expiry)}
        cardNumber={formatCardNumber(values.cardNumber)}
        network="mastercard"
      />

      <div className="flex flex-col gap-5 p-6">
        <div className="flex flex-col gap-1">
          <h2 id={titleId} className="m-0 text-lg font-semibold text-text-primary">
            {title}
          </h2>
          <p id={descriptionId} className="m-0 text-sm text-text-secondary">
            {description}
          </p>
        </div>

        <FormLayout
          fields={
            <>
              <Input
                label="Name on card"
                name="nameOnCard"
                autoComplete="cc-name"
                value={values.nameOnCard}
                error={touched.nameOnCard ? errors.nameOnCard : undefined}
                onChange={(v) => {
                  const next = { ...values, nameOnCard: v };
                  setField('nameOnCard', v);
                  if (touched.nameOnCard) validateField('nameOnCard', next);
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, nameOnCard: true }));
                  validateField('nameOnCard', values);
                }}
              />
              <Input
                label="Expiry"
                name="expiry"
                autoComplete="cc-exp"
                inputMode="numeric"
                placeholder="06 / 2028"
                value={values.expiry}
                error={touched.expiry ? errors.expiry : undefined}
                onChange={(v) => {
                  const formatted = formatExpiry(v);
                  const next = { ...values, expiry: formatted };
                  setField('expiry', formatted);
                  if (touched.expiry) validateField('expiry', next);
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, expiry: true }));
                  validateField('expiry', values);
                }}
              />
              <Input
                label="Card number"
                name="cardNumber"
                autoComplete="cc-number"
                inputMode="numeric"
                value={formatCardNumber(values.cardNumber)}
                error={touched.cardNumber ? errors.cardNumber : undefined}
                startAdornment={<MastercardLogo className="h-4 w-6" />}
                onChange={(v) => {
                  const digits = digitsOnly(v).slice(0, 16);
                  const next = { ...values, cardNumber: digits };
                  setField('cardNumber', digits);
                  if (touched.cardNumber) validateField('cardNumber', next);
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, cardNumber: true }));
                  validateField('cardNumber', values);
                }}
              />
              <Input
                label="CVV"
                name="cvv"
                type="password"
                autoComplete="cc-csc"
                inputMode="numeric"
                maxLength={4}
                placeholder="•••"
                value={values.cvv}
                error={touched.cvv ? errors.cvv : undefined}
                onChange={(v) => {
                  const digits = digitsOnly(v).slice(0, 4);
                  const next = { ...values, cvv: digits };
                  setField('cvv', digits);
                  if (touched.cvv) validateField('cvv', next);
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, cvv: true }));
                  validateField('cvv', values);
                }}
              />
            </>
          }
          actions={
            <>
              <Button
                type="button"
                variant="secondary"
                className="w-full"
                disabled={loading}
                onClick={() => onCancel?.()}
              >
                {cancelLabel}
              </Button>
              <Button
                type="submit"
                variant="primary"
                className="w-full"
                loading={loading}
              >
                {submitLabel}
              </Button>
            </>
          }
        />
      </div>
    </form>
  );
}

export type {
  PaymentMethodErrors,
  PaymentMethodValues,
  UpdatePaymentMethodFormProps,
} from './UpdatePaymentMethodForm.types';
