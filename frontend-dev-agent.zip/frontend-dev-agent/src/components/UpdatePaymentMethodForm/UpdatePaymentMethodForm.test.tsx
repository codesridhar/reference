import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { UpdatePaymentMethodForm } from './UpdatePaymentMethodForm';

describe('UpdatePaymentMethodForm', () => {
  it('renders title, subtitle, fields, and actions', () => {
    render(<UpdatePaymentMethodForm />);

    expect(
      screen.getByRole('heading', { name: 'Update payment method' }),
    ).toBeInTheDocument();
    expect(screen.getByText('Update your card details.')).toBeInTheDocument();
    expect(screen.getByLabelText('Name on card')).toBeInTheDocument();
    expect(screen.getByLabelText('Expiry')).toBeInTheDocument();
    expect(screen.getByLabelText('Card number')).toBeInTheDocument();
    expect(screen.getByLabelText('CVV')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Update' })).toBeInTheDocument();
  });

  it('updates the card preview when name changes', async () => {
    const user = userEvent.setup();
    render(
      <UpdatePaymentMethodForm
        initialValues={{ nameOnCard: '', cardNumber: '', expiry: '', cvv: '' }}
      />,
    );

    await user.type(screen.getByLabelText('Name on card'), 'Jane Doe');
    expect(screen.getByText('JANE DOE')).toBeInTheDocument();
  });

  it('calls onCancel when Cancel is clicked', async () => {
    const user = userEvent.setup();
    const onCancel = jest.fn();
    render(<UpdatePaymentMethodForm onCancel={onCancel} />);
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(onCancel).toHaveBeenCalledTimes(1);
  });

  it('submits masked values when valid', async () => {
    const user = userEvent.setup();
    const onSubmit = jest.fn();
    render(
      <UpdatePaymentMethodForm
        initialValues={{
          nameOnCard: 'Olivia Rhye',
          expiry: '06 / 2028',
          cardNumber: '1234123412341234',
          cvv: '',
        }}
        onSubmit={onSubmit}
      />,
    );

    await user.type(screen.getByLabelText('CVV'), '123');
    await user.click(screen.getByRole('button', { name: 'Update' }));

    expect(onSubmit).toHaveBeenCalledWith({
      nameOnCard: 'Olivia Rhye',
      expiry: '06 / 2028',
      cardNumber: '1234123412341234',
      cvv: '123',
    });
  });

  it('shows validation errors and blocks submit when incomplete', async () => {
    const user = userEvent.setup();
    const onSubmit = jest.fn();
    render(
      <UpdatePaymentMethodForm
        initialValues={{
          nameOnCard: '',
          expiry: '',
          cardNumber: '',
          cvv: '',
        }}
        onSubmit={onSubmit}
      />,
    );

    await user.click(screen.getByRole('button', { name: 'Update' }));
    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getByRole('alert')).toBeInTheDocument();
  });
});
