import { createRef } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Input } from './Input';

describe('Input', () => {
  it('renders label, placeholder, and description', () => {
    render(
      <Input label="Email" placeholder="Email" description="Enter your email address." />,
    );

    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument();
    expect(screen.getByText('Enter your email address.')).toBeInTheDocument();
  });

  it('links label via htmlFor and description via aria-describedby', () => {
    render(
      <Input label="Email" description="Enter your email address." />,
    );

    const field = screen.getByLabelText('Email');
    const description = screen.getByText('Enter your email address.');
    expect(field).toHaveAttribute('aria-describedby', description.id);
  });

  it('calls onChange with the string value', async () => {
    const user = userEvent.setup();
    const onChange = jest.fn();
    render(<Input label="Email" onChange={onChange} />);

    await user.type(screen.getByLabelText('Email'), 'a');
    expect(onChange).toHaveBeenCalledWith('a');
  });

  it('sets aria-invalid and announces error', () => {
    render(<Input label="Email" error="Email needs an @" />);

    const field = screen.getByLabelText('Email');
    expect(field).toHaveAttribute('aria-invalid', 'true');
    expect(screen.getByRole('alert')).toHaveTextContent('Email needs an @');
    expect(field.getAttribute('aria-describedby')).toContain(
      screen.getByRole('alert').id,
    );
  });

  it('forwards ref to the native input', () => {
    const ref = createRef<HTMLInputElement>();
    render(<Input label="Email" ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });

  it('disables the native input when disabled', () => {
    render(<Input label="Email" disabled />);
    expect(screen.getByLabelText('Email')).toBeDisabled();
  });

  it('uses aria-label when visible label is omitted', () => {
    render(<Input aria-label="Search query" placeholder="Search" />);
    expect(screen.getByLabelText('Search query')).toBeInTheDocument();
  });
});
