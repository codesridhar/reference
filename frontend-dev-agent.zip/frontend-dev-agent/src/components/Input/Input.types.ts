import type { FocusEvent, InputHTMLAttributes, ReactNode } from 'react';

export type InputType =
  | 'text'
  | 'email'
  | 'password'
  | 'search'
  | 'tel'
  | 'url'
  | 'number';

export interface InputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'size' | 'onChange' | 'onBlur' | 'onFocus'> {
  /** Visible label text. Prefer this over aria-label alone. */
  label?: string;
  /** Helper text shown below the field. */
  description?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Native input type. */
  type?: InputType;
  /** Disables editing and dims the control. */
  disabled?: boolean;
  /** Prevents editing while remaining focusable. */
  readOnly?: boolean;
  /** Marks the field as required. */
  required?: boolean;
  /** Error message; sets aria-invalid and links via aria-describedby. */
  error?: string;
  /** Passthrough class on the root wrapper. */
  className?: string;
  /** Optional class on the native input (e.g. flex-1 for row layouts). */
  inputClassName?: string;
  /** Adjacent action (e.g. Button) rendered on the same row as the field. */
  action?: ReactNode;
  /** Leading adornment inside the field (e.g. card network logo). */
  startAdornment?: ReactNode;
  /** Accessible name when visible label is omitted. */
  'aria-label'?: string;
  /** Fired when the field value changes. */
  onChange?: (value: string) => void;
  /** Fired when the field loses focus. */
  onBlur?: (event: FocusEvent<HTMLInputElement>) => void;
  /** Fired when the field receives focus. */
  onFocus?: (event: FocusEvent<HTMLInputElement>) => void;
}
