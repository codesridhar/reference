import {
  forwardRef,
  useId,
  useState,
  type ChangeEvent,
  type FocusEvent,
} from 'react';
import type { InputProps } from './Input.types';

const rootBase = 'flex flex-col gap-2 font-ds w-full';

const labelBase = 'text-sm font-medium text-text-primary';

const fieldBase = [
  'block w-full min-h-10 px-3 py-2 text-sm font-ds',
  'bg-surface text-text-primary placeholder:text-text-placeholder',
  'border border-border-input rounded-ds-sm',
  'transition-colors',
  'hover:border-border-input-hover',
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
  'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-border-input',
  'read-only:bg-surface-muted',
].join(' ');

const fieldWithAdornment = [
  'block w-full min-h-10 pl-2 pr-3 py-2 text-sm font-ds',
  'bg-transparent text-text-primary placeholder:text-text-placeholder',
  'border-0 rounded-ds-sm',
  'focus-visible:outline-none',
  'disabled:opacity-50 disabled:cursor-not-allowed',
  'read-only:bg-transparent',
].join(' ');

const adornmentShell = [
  'flex w-full items-center min-h-10 rounded-ds-sm',
  'bg-surface border border-border-input',
  'transition-colors',
  'hover:border-border-input-hover',
  'focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-primary focus-within:ring-offset-2',
].join(' ');

const fieldError = 'border-danger hover:border-danger';

const hintBase = 'text-sm text-text-secondary';
const errorBase = 'text-sm text-danger';

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  {
    label,
    description,
    placeholder = '',
    value,
    defaultValue,
    type = 'text',
    name,
    id: idProp,
    disabled = false,
    readOnly = false,
    required = false,
    error,
    className = '',
    inputClassName = '',
    action,
    startAdornment,
    'aria-label': ariaLabel,
    onChange,
    onBlur,
    onFocus,
    ...rest
  },
  ref,
) {
  const autoId = useId();
  const id = idProp ?? autoId;
  const descriptionId = description ? `${id}-description` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [descriptionId, errorId].filter(Boolean).join(' ') || undefined;

  const isControlled = value !== undefined;
  const [internal, setInternal] = useState(defaultValue ?? '');
  const current = isControlled ? value : internal;

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (!isControlled) setInternal(event.target.value);
    onChange?.(event.target.value);
  };

  const handleBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event);
  };

  const handleFocus = (event: FocusEvent<HTMLInputElement>) => {
    onFocus?.(event);
  };

  const inputEl = (
    <input
      {...rest}
      ref={ref}
      id={id}
      name={name}
      type={type}
      value={current}
      placeholder={placeholder}
      disabled={disabled}
      readOnly={readOnly}
      required={required}
      aria-invalid={error ? true : undefined}
      aria-describedby={describedBy}
      aria-label={label ? undefined : ariaLabel}
      onChange={handleChange}
      onBlur={handleBlur}
      onFocus={handleFocus}
      className={`${startAdornment ? fieldWithAdornment : fieldBase} ${
        !startAdornment && error ? fieldError : ''
      } ${inputClassName}`.trim()}
    />
  );

  const field = startAdornment ? (
    <div
      className={`${adornmentShell} ${error ? fieldError : ''} ${
        disabled ? 'opacity-50' : ''
      }`.trim()}
    >
      <span className="flex shrink-0 items-center pl-3" aria-hidden="true">
        {startAdornment}
      </span>
      {inputEl}
    </div>
  ) : (
    inputEl
  );

  return (
    <div className={`${rootBase} ${className}`.trim()}>
      {label ? (
        <label htmlFor={id} className={labelBase}>
          {label}
          {required ? (
            <span className="text-danger" aria-hidden="true">
              {' '}
              *
            </span>
          ) : null}
        </label>
      ) : null}
      {action ? (
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">{field}</div>
          <div className="shrink-0">{action}</div>
        </div>
      ) : (
        field
      )}
      {description ? (
        <p id={descriptionId} className={hintBase}>
          {description}
        </p>
      ) : null}
      {error ? (
        <p id={errorId} className={errorBase} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
});

Input.displayName = 'Input';

export type { InputProps, InputType } from './Input.types';
