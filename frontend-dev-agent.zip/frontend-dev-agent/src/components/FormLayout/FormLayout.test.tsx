import { render, screen } from '@testing-library/react';
import { FormLayout } from './FormLayout';

describe('FormLayout', () => {
  it('renders fields and actions slots', () => {
    render(
      <FormLayout
        fields={<span>Field A</span>}
        actions={<button type="button">Save</button>}
      />,
    );

    expect(screen.getByText('Field A')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Save' })).toBeInTheDocument();
  });
});
