import type { ReactNode } from 'react';

export interface FormLayoutProps {
  /** Form field nodes placed into the responsive grid. */
  fields: ReactNode;
  /** Footer action controls (typically Cancel + primary). */
  actions?: ReactNode;
  /** Passthrough class on the root. */
  className?: string;
  /** Optional class on the fields grid. */
  fieldsClassName?: string;
  /** Optional class on the actions row. */
  actionsClassName?: string;
}
