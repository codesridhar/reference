import type { FormLayoutProps } from './FormLayout.types';

export function FormLayout({
  fields,
  actions,
  className = '',
  fieldsClassName = '',
  actionsClassName = '',
}: FormLayoutProps) {
  return (
    <div className={`flex w-full flex-col font-ds ${className}`.trim()}>
      <div
        className={[
          'grid grid-cols-1 gap-4 md:grid-cols-[2fr_1fr] md:gap-x-4 md:gap-y-5',
          fieldsClassName,
        ]
          .filter(Boolean)
          .join(' ')}
      >
        {fields}
      </div>
      {actions ? (
        <div
          className={[
            'mt-6 grid grid-cols-2 gap-3',
            actionsClassName,
          ]
            .filter(Boolean)
            .join(' ')}
        >
          {actions}
        </div>
      ) : null}
    </div>
  );
}

export type { FormLayoutProps } from './FormLayout.types';
