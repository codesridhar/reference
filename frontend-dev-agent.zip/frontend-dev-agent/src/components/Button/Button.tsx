import { forwardRef } from 'react';
import type { ButtonProps } from './Button.types';

const base = [
  'inline-flex items-center justify-center gap-2 font-medium font-ds',
  'rounded-ds-md transition-colors',
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2',
].join(' ');

const sizes = {
  sm: 'min-h-9 px-3 py-1.5 text-sm',
  md: 'min-h-11 px-4 py-2.5 text-sm',
  lg: 'min-h-12 px-5 py-3 text-base',
} as const;

const variants = {
  primary:
    'bg-brand-primary hover:bg-brand-primary-hover text-text-on-brand shadow-ds-sm',
  secondary:
    'bg-surface border border-ds-border text-text-primary hover:bg-surface-muted',
  danger: 'bg-danger text-text-on-brand hover:opacity-90',
} as const;

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = 'primary',
    size = 'md',
    loading = false,
    disabled = false,
    type = 'button',
    className = '',
    children,
    onClick,
    ...rest
  },
  ref,
) {
  const blocked = disabled || loading;

  return (
    <button
      {...rest}
      ref={ref}
      type={type}
      disabled={blocked}
      aria-disabled={blocked || undefined}
      aria-busy={loading || undefined}
      onClick={blocked ? undefined : onClick}
      className={`${base} ${sizes[size]} ${variants[variant]} ${
        blocked ? 'opacity-50 cursor-not-allowed' : ''
      } ${className}`.trim()}
    >
      {loading ? (
        <span
          aria-hidden="true"
          className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"
        />
      ) : null}
      {children}
    </button>
  );
});

Button.displayName = 'Button';

export type { ButtonProps, ButtonSize, ButtonVariant } from './Button.types';
