import { createRef } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Button } from './Button';

describe('Button', () => {
  it('renders children', () => {
    render(<Button>Update</Button>);
    expect(screen.getByRole('button', { name: 'Update' })).toBeInTheDocument();
  });

  it('fires onClick when activated', async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(<Button onClick={onClick}>Update</Button>);
    await user.click(screen.getByRole('button', { name: 'Update' }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it('does not fire onClick when disabled', async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(
      <Button disabled onClick={onClick}>
        Update
      </Button>,
    );
    await user.click(screen.getByRole('button', { name: 'Update' }));
    expect(onClick).not.toHaveBeenCalled();
  });

  it('sets aria-busy when loading and blocks clicks', async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(
      <Button loading onClick={onClick}>
        Update
      </Button>,
    );
    const btn = screen.getByRole('button', { name: 'Update' });
    expect(btn).toHaveAttribute('aria-busy', 'true');
    await user.click(btn);
    expect(onClick).not.toHaveBeenCalled();
  });

  it('forwards ref to the native button', () => {
    const ref = createRef<HTMLButtonElement>();
    render(<Button ref={ref}>Cancel</Button>);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });
});
