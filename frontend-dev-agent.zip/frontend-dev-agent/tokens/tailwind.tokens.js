/**
 * Generated from tokens/design-tokens.json — Tailwind theme.extend mapping.
 * Every utility resolves to a CSS variable, so all utilities are brand-aware.
 * Usage in tailwind.config.js:
 *   const tokens = require('./tokens/tailwind.tokens.js');
 *   module.exports = { theme: { extend: tokens } };
 */
module.exports = {
  colors: {
    'brand-primary': 'var(--ds-color-brand-primary)',
    'brand-primary-hover': 'var(--ds-color-brand-primary-hover)',
    'brand-accent': 'var(--ds-color-brand-accent)',
    surface: 'var(--ds-color-surface)',
    'surface-muted': 'var(--ds-color-surface-muted)',
    'ds-border': 'var(--ds-color-border)',
    'border-input': 'var(--ds-color-border-input)',
    'border-input-hover': 'var(--ds-color-border-input-hover)',
    'text-primary': 'var(--ds-color-text-primary)',
    'text-secondary': 'var(--ds-color-text-secondary)',
    'text-placeholder': 'var(--ds-color-text-placeholder)',
    'text-on-brand': 'var(--ds-color-text-on-brand)',
    danger: 'var(--ds-color-danger)',
    success: 'var(--ds-color-success)',
    warning: 'var(--ds-color-warning)',
    glass: 'var(--ds-color-glass)',
    'glass-border': 'var(--ds-color-glass-border)',
    'on-glass': 'var(--ds-color-on-glass)',
    'network-mastercard-red': 'var(--ds-color-network-mastercard-red)',
    'network-mastercard-orange': 'var(--ds-color-network-mastercard-orange)',
  },
  borderRadius: {
    'ds-sm': 'var(--ds-radius-sm)',
    'ds-md': 'var(--ds-radius-md)',
    'ds-lg': 'var(--ds-radius-lg)',
    'ds-xl': 'var(--ds-radius-xl)',
    'ds-full': 'var(--ds-radius-full)',
  },
  boxShadow: {
    'ds-sm': 'var(--ds-shadow-sm)',
    'ds-md': 'var(--ds-shadow-md)',
    'ds-lg': 'var(--ds-shadow-lg)',
  },
  backgroundImage: {
    'card-mesh': 'var(--ds-gradient-card-mesh)',
  },
  backdropBlur: {
    glass: 'var(--ds-blur-glass)',
  },
  fontFamily: {
    ds: 'var(--ds-font-family)',
  },
};
