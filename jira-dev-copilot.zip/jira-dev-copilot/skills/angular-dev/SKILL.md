---
name: angular-dev
description: Reference for implementing, fixing, and testing Angular applications — component/service/module conventions, RxJS subscription patterns, reactive forms, dependency injection, routing, and the ng CLI commands for generating code, testing, linting, and building. Use when working on "Angular component", "fix this Angular bug", "Angular service", "write an Angular test", "Angular story", or any task in a repo containing angular.json.
---

# Angular Development

Reference knowledge for implementing Jira stories in Angular codebases. Load this after the stack has been identified as Angular. Pair with the `angular-developer` agent, which owns the actual implementation loop — this file is the checklist/knowledge base it should consult.

## 1. Detect the project and version before writing code

- Confirm it's Angular: look for `angular.json` at the repo root. If absent, this is not an Angular CLI project — check for a hand-rolled webpack + `@angular/core` setup instead, but treat `angular.json` as the strong signal.
- Read `package.json` and note the exact `@angular/core` version. Version gates behavior:
  - **v14+**: standalone components (`standalone: true`, no NgModule required) are available. Check if the repo already uses standalone components anywhere (`grep -r "standalone: true" src/`) — if yes, match that style for new components; if the repo is still NgModule-based, do NOT introduce standalone components unilaterally.
  - **v15**: standalone directives/pipes; `provideRouter()` for standalone routing.
  - **v16+**: Angular Signals (`signal()`, `computed()`, `effect()`) available. Check if signals are already used (`grep -r "signal(" src/`) before introducing them — don't mix paradigms inconsistently within one feature.
  - **v17+**: new control-flow syntax in templates (`@if`, `@for`, `@switch`) replaces `*ngIf`/`*ngFor`. Check the primary template style in the repo (`grep -rl "@if\|@for" src/` vs `*ngIf`) and match it. Do not convert existing templates to the new syntax as a drive-by change.
  - Pre-v14: everything is NgModule-based, constructor DI, RxJS + `async` pipe or manual subscribe. No standalone, no signals.
- Check `angular.json` `projects.<name>.architect` for the configured test runner (default Karma unless replaced by Jest — some repos migrate to `jest` via `@angular-builders/jest`; check `package.json` devDependencies for `jest` alongside Angular to confirm).

## 2. Component structure conventions

- One component per folder: `feature-name/feature-name.component.ts`, `.html`, `.scss`/`.css`, and `.spec.ts`. Some repos use inline templates/styles for very small components — check existing sibling components before deciding.
- Naming: kebab-case file names, PascalCase class names suffixed `Component` (e.g., `UserProfileComponent`), selector prefixed per the project's convention in `angular.json` (`"prefix": "app"` typically) — e.g., `app-user-profile`.
- Keep components "dumb" where possible: presentation in the component, business/data logic in an injected service. If a component's `.ts` file is doing HTTP calls directly, that's a smell — check if the repo already has a service layer convention (`*.service.ts`) and follow it.
- Inputs/Outputs: use `@Input()` / `@Output()` decorators (or the newer `input()`/`output()` signal-based functions in v17.1+ if the repo already uses signals). Never mutate `@Input()` values directly inside the child.

## 3. Services and dependency injection

- Services are `@Injectable({ providedIn: 'root' })` for app-wide singletons unless the repo scopes them to a specific module/component providers array — check existing services for the pattern in use.
- Constructor injection is standard: `constructor(private http: HttpClient, private userService: UserService) {}`. In v14+ codebases that have adopted it, `inject()` function-based DI may appear instead — match whichever the file/module already uses.
- Custom injection tokens: look for `InjectionToken` usage (e.g., `export const API_BASE_URL = new InjectionToken<string>('apiBaseUrl')`) when a story requires injecting config/env values rather than hardcoding them.
- HTTP calls go through `HttpClient`, typically wrapped in a service method returning an `Observable<T>`. Do not call `HttpClient` directly from components.

## 4. RxJS patterns — get subscription management right

- Prefer the `async` pipe in templates (`{{ data$ | async }}` or `*ngIf="data$ | async as data"`) over manual `.subscribe()` in the component — it auto-unsubscribes and avoids leaks. Use this by default for new code.
- When manual `.subscribe()` in a component is unavoidable (e.g., triggering a side effect, not rendering data), always unsubscribe. Two standard patterns — check which the repo already uses:
  - `takeUntil(this.destroy$)`: declare `private destroy$ = new Subject<void>();`, pipe every subscription with `.pipe(takeUntil(this.destroy$))`, and in `ngOnDestroy()` call `this.destroy$.next(); this.destroy$.complete();`.
  - `takeUntilDestroyed()` (Angular v16+): `.pipe(takeUntilDestroyed())` inside an injection context, no manual `Subject` needed.
- Never leave a raw `.subscribe()` with no teardown in a component with a lifecycle — this is the single most common Angular bug/leak pattern reviewers flag.
- Combine multiple observables with `combineLatest`, `forkJoin` (for one-shot parallel requests), or `switchMap`/`mergeMap`/`concatMap` for dependent chains — pick based on whether prior in-flight requests should be cancelled (`switchMap`) or preserved (`mergeMap`/`concatMap`).

## 5. Forms

- Determine which the repo uses: reactive forms (`ReactiveFormsModule`, `FormGroup`/`FormControl`/`FormBuilder`) or template-driven (`FormsModule`, `[(ngModel)]`). Check the feature module's imports or the standalone component's `imports` array.
- Default to reactive forms for anything with validation logic, dynamic fields, or unit-testable form state — this is the Angular team's recommended approach for non-trivial forms.
- Reactive form pattern:
  ```ts
  this.form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    name: ['', Validators.required],
  });
  ```
  Access errors via `this.form.get('email')?.errors`, and gate submit on `this.form.valid`.
- Template-driven forms are acceptable for very simple single-field cases if that's the established repo convention — don't introduce reactive forms into a template-driven-only codebase without cause.

## 6. Routing conventions

- Routes are declared in `*-routing.module.ts` files (NgModule style) or passed to `provideRouter()` in `app.config.ts` (standalone style, v15+).
- Use `loadChildren`/`loadComponent` for lazy-loaded feature routes — check if the repo lazy-loads by convention before adding an eagerly-loaded route to a large feature area.
- Route guards: `CanActivate`, `CanDeactivate` etc. as classes (older) or functional guards (`CanActivateFn`, v14.2+) — match existing guard style in the repo.
- Route params: `ActivatedRoute.snapshot.paramMap.get('id')` for one-time reads, or `ActivatedRoute.paramMap` observable if the component must react to param changes without being destroyed/recreated.

## 7. Generating code — use the CLI, don't hand-roll boilerplate

```bash
ng generate component feature-name/component-name --skip-tests=false
ng generate service feature-name/services/service-name
ng generate module feature-name --routing
ng generate directive feature-name/directives/directive-name
ng generate pipe feature-name/pipes/pipe-name
```
- Use `--dry-run` first if unsure of output paths in an unfamiliar repo structure.
- After generation, the CLI auto-registers the component/directive/pipe in the relevant NgModule's `declarations` (skip this for standalone components — they self-declare via their own `imports` array instead).

## 8. Testing — Karma/Jasmine (default) or Jest

- Spec file pattern: `TestBed.configureTestingModule({...})`, `TestBed.createComponent(FooComponent)`, `fixture.detectChanges()` to trigger initial binding.
- Mock injected services with jasmine spies: `jasmine.createSpyObj('UserService', ['getUser'])`, or provide a fake via `{ provide: UserService, useValue: fakeUserService }`.
- Run locally during interactive development:
  ```bash
  ng test
  ```
- Run once, headless, for CI/automated verification (this is what you should run after implementing a story to confirm nothing broke):
  ```bash
  ng test --watch=false --browsers=ChromeHeadless
  ```
- If the repo uses Jest instead (`@angular-builders/jest` or a custom `jest.config.js` present), run `npm test` or `npx jest` instead — check `package.json` scripts first (`"test"` script is the source of truth for the actual invocation).
- Test HTTP calls with `HttpClientTestingModule` and `HttpTestingController` (`httpMock.expectOne(...)`, `.flush(mockData)`) — never let a spec hit a real network endpoint.
- Write specs colocated as `*.component.spec.ts` / `*.service.spec.ts` next to the file under test, matching existing repo structure.

## 9. Linting

```bash
ng lint
```
- If `ng lint` is not configured (removed from Angular CLI defaults since v15 unless ESLint schematic was added), check `package.json` for a direct `eslint` script instead: `npm run lint`. Look for `.eslintrc.json` at the root to confirm ESLint is in use.
- Fix lint errors before considering a story implementation-complete; do not suppress with inline `// eslint-disable` unless a pre-existing pattern in the file already does so for the same rule.

## 10. Building

```bash
ng build --configuration production
```
- Use this as a final sanity check before handing off for review/check-in — a production build catches AOT template errors, unused import issues, and budget (bundle size) violations that `ng serve` (JIT/dev mode) will not.
- Check `angular.json` `budgets` config if the build fails on size — do not casually raise budget limits to make a failing build pass; flag it instead.
- For a dev/local sanity run instead of full prod validation: `ng build` (uses the `development` configuration by default in newer CLI versions).

## 11. Common pitfalls to avoid

- Introducing NgModules into an all-standalone repo, or vice versa — always match the existing paradigm within the feature area you're touching.
- Subscribing without unsubscribing (see RxJS section) — the top leak source.
- Mutating `@Input()` objects/arrays in place instead of treating them as immutable from the child's perspective (breaks `OnPush` change detection if used).
- Forgetting `ChangeDetectorRef.markForCheck()` or `detectChanges()` when using `ChangeDetectionStrategy.OnPush` and updating state outside Angular's normal event/async pipe flow — check the component's `@Component` decorator for `changeDetection: ChangeDetectionStrategy.OnPush` before assuming default dirty-checking will pick up manual state mutations.
- Circular DI between services — resolve via a shared parent service or `forwardRef()`, not by restructuring the whole module graph.
