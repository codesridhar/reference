---
name: sdlc-workflow
description: Runs the full Jira-to-code SDLC pipeline inside VS Code / IntelliJ — fetch a Jira story, analyze it, ask clarifying questions, pick the right stack developer, get permission, implement, test, review, and gate git check-in and Jira updates behind explicit user approval. Trigger on phrases like "work on JIRA-1234", "pick up this Jira story", "implement this ticket", "start work on <ticket key>", "let's start <TICKET-KEY>", "run the dev copilot workflow", "take this story through to done", "build out JIRA-5678", "can you handle this Jira ticket", "process this story end to end", "kick off the SDLC workflow for <key>".
---

# SDLC Workflow (Jira Dev Copilot)

Run this exact 9-phase pipeline whenever this skill fires. Follow phases in order. Do not skip a phase and do not silently merge two phases together — each STOP point below is a hard stop, not a suggestion. This checklist is the same one the `dev-lead` agent enforces when a user invokes it directly as an agent instead of triggering this skill — if the user is talking to dev-lead directly, defer to that agent's own state instead of re-running this from scratch.

## Phase 1 — Resolve and fetch the Jira issue

1. Extract the Jira issue key (e.g. `JIRA-1234`, `ABC-42`) from the user's message using a regex-like scan for `[A-Z][A-Z0-9]+-[0-9]+`.
2. If no key is found, STOP and ask the user which Jira issue key to work on. Do not guess a key or proceed with a partial identifier.
3. Fetch the issue:
   - Prefer Atlassian MCP tools if present in the current session (look for tool names like `getJiraIssue`, `searchJiraIssuesUsingJql`). Use `getJiraIssue` with the resolved key to pull summary, description, acceptance criteria, issue type, status, components, labels, and linked issues.
   - If Atlassian MCP tools are not available in this session, fall back to Jira REST API v3 via curl:
     ```
     curl -s -u "$JIRA_EMAIL:$JIRA_API_TOKEN" \
       -H "Accept: application/json" \
       "$JIRA_BASE_URL/rest/api/3/issue/<ISSUE-KEY>?fields=summary,description,status,components,labels,issuelinks,customfield_*"
     ```
     Read `JIRA_BASE_URL`, `JIRA_EMAIL`, and `JIRA_API_TOKEN` from environment variables. Never print `JIRA_API_TOKEN` to output, logs, or commit messages. If any of these three env vars is missing, STOP and tell the user which one is missing and ask them to set it — do not attempt an unauthenticated request.
   - Delegate the actual fetch mechanics to the `jira-analyst` agent's conventions if that agent is present; otherwise perform the fetch directly using the steps above.

## Phase 2 — Summarize and analyze

4. Produce a short summary of the story: title, issue type, priority, listed acceptance criteria (verbatim, bulleted), and any attached mockups/links.
5. Analyze scope: identify which repo(s), modules, or components the story likely touches, using Jira's `components` field, labels, and any repo names mentioned in the description or comments.
6. State explicitly what is in scope and what is out of scope for this piece of work, in one short paragraph.

## Phase 3 — Clarify ambiguity (hard stop if triggered)

7. Check the story against this checklist:
   - Are there acceptance criteria at all, or only a vague description?
   - Do any acceptance criteria contradict each other or the description?
   - Is the affected component/repo unclear or unstated?
   - Are there undefined terms, unspecified edge cases, or missing UX/API details needed to implement correctly?
8. If ANY of the above is true, STOP here. Do not proceed to stack detection or implementation. Ask the user specific, numbered clarifying questions that name exactly what is missing or contradictory. Do not guess intent, do not "assume the most likely interpretation" silently, and do not fill gaps with placeholder behavior without saying so out loud first.
9. Only continue to Phase 4 once the user has answered enough to remove the blocking ambiguity, or the user explicitly tells you to proceed with stated assumptions (in which case restate the assumptions you're locking in before moving on).

## Phase 4 — Detect the stack and pick the developer agent

10. Inspect the repository for stack signals:
    - **Angular** → `angular.json` present, or `@angular/core` in `package.json` dependencies. Use `angular-developer`.
    - **React** → `react` / `react-dom` in `package.json`, or `.tsx`/`.jsx` component files present. Use `react-developer`.
    - **Java Spring** → `pom.xml` or `build.gradle`/`build.gradle.kts` present with a `spring-boot` dependency or `spring-boot-starter-*` artifacts. Use `java-spring-developer`.
    - **Legacy stack** → presence of jQuery, Backbone, Underscore, Marionette, Handlebars, or `.less` files (e.g. `jquery` in `package.json`, `Backbone.View`/`Marionette.` in source, `.hbs`/`.handlebars` templates, `.less` stylesheets). Use `legacy-js-developer`.
11. Cross-check the repo signal against the Jira issue's `components` field and `labels` — if they disagree (e.g. repo looks like Angular but the Jira component says "Legacy Portal"), surface the conflict to the user and ask which is authoritative rather than silently picking one.
12. If multiple stacks are plausible (e.g. a monorepo with both Angular and Spring), identify the specific sub-path the story touches and pick the agent for that sub-path; state your reasoning.
13. Explicitly state to the user: "This looks like a `<stack>` change. I'll use the `<stack-developer-agent-name>` agent to implement it." If the stack cannot be determined with reasonable confidence, STOP and ask the user which stack/repo this targets.

## Phase 5 — Plan and get permission to execute (gate 1 of 3)

14. Present a short implementation plan: files/modules likely to change, the approach, and how each acceptance criterion will be satisfied. Keep it concise — a bulleted plan, not a design doc.
15. STOP and explicitly ask the user for permission to execute this plan, e.g. "Should I go ahead and implement this?" Do not proceed on the basis of the user's earlier enthusiasm, an earlier "sounds good," or any prior message in the conversation — this permission question must get its own explicit yes for this specific plan. A non-answer, a change of subject, or an ambiguous reply is not consent; ask again or ask for clarification.
16. If the user says no, wants changes, or wants to pause, revise the plan or stop — do not implement anything.

## Phase 6 — Execute

17. Once the user has said yes, hand off implementation to the chosen stack-developer agent's conventions (naming, folder structure, framework idioms, styling approach) for that stack.
18. Make focused changes scoped to the story; avoid unrelated refactors unless the user asked for them.
19. If you discover the plan needs to change materially mid-implementation (e.g. a hidden dependency, a much larger blast radius), pause and tell the user before continuing — do not silently expand scope.

## Phase 7 — Write and run tests

20. Hand off to (or follow the conventions of) the `qa-engineer` agent to write test cases mapped one-to-one to each acceptance criterion identified in Phase 2.
21. Run the test suite (unit tests at minimum; integration tests if the stack and story warrant it).
22. Report pass/fail per acceptance criterion in a short table or list — do not just say "tests pass," show which criterion each test covers.
23. If tests fail, fix the implementation or the test (whichever is wrong) and re-run before moving to Phase 8. Do not proceed to code review with known-failing tests unless the user explicitly accepts that state.

## Phase 8 — Code review

24. Hand off to (or follow the conventions of) the `code-reviewer` agent and run a review pass against this checklist:
    - Correctness against acceptance criteria
    - Code style / consistency with surrounding codebase conventions
    - Security: no hardcoded secrets, no injection risks, no leaked tokens/credentials in code or comments
    - Test coverage: are the new tests from Phase 7 meaningful, not just present
25. Produce an explicit verdict: **APPROVE** or **CHANGES-REQUESTED**, with a bulleted list of findings either way.
26. If **CHANGES-REQUESTED**, loop back to Phase 6 to address the findings, then re-run Phase 7 and Phase 8 again. Do not skip straight to check-in with unresolved changes-requested findings.

## Phase 9 — Git check-in (gate 2 of 3)

27. Once code review is APPROVE, STOP and explicitly ask the user for permission before running any git command that mutates remote or shared state (`add`, `commit`, `push`), e.g. "Code review passed. Should I commit and push this to a feature branch?" This is a separate, distinct question from the Phase 5 execute-permission question — never fold it into that earlier answer, and never infer consent for check-in from the earlier "yes, go ahead and implement it."
28. If the user says no or wants to hold off, stop here and leave the work uncommitted locally; do not push anything.
29. Only after explicit yes: follow the `git-commands` skill for the exact command sequences. Create a feature branch named `feature/<JIRA-KEY>-<slug>` (slug = short kebab-case summary of the story), commit with message `[<JIRA-KEY>] <summary>`, and push using PAT-based auth as described in that skill. Never use the `gh` CLI — it is not installed and must never be invoked.

## Phase 10 — Jira update (gate 3 of 3)

30. STOP and explicitly ask the user for permission before touching the Jira issue at all, e.g. "Want me to update the Jira ticket now — transition status and add a comment with the summary?" This is a third, separate permission question — distinct from both the execute gate and the check-in gate. Do not infer consent from either earlier yes.
31. If the user says no or wants to defer, stop here — leave the Jira issue untouched and tell the user it's ready to update whenever they want.
32. Only after explicit yes: transition the issue's status (using `transitionJiraIssue`/`getTransitionsForJiraIssue` if Atlassian MCP tools are available, else the Jira REST v3 transitions endpoint) and post a comment (`addCommentToJiraIssue` or REST v3 `/comment` endpoint) summarizing what was done — include the commit link/hash, branch name, and the test pass/fail results from Phase 7.

## Hard rules across all phases

- There are exactly three permission gates: **execute** (end of Phase 5), **check-in** (Phase 9), and **Jira update** (Phase 10). Each is asked separately, each requires its own explicit yes, and a yes to one never implies yes to another.
- Never guess when acceptance criteria are ambiguous — Phase 3 is a hard stop, not advisory.
- Never invoke `gh` CLI for any git or GitHub operation.
- Never print or commit secrets (`JIRA_API_TOKEN`, `GITHUB_PAT`, `.env` contents).
- If interrupted mid-pipeline, on resume restate which phase you're in before continuing, so the user isn't surprised by what happens next.

## Relationship to the dev-lead agent

The `dev-lead` agent embodies this identical 9/10-phase checklist as its own operating procedure for users who invoke it directly as an agent (rather than triggering this skill via natural language). The phase numbering, the three permission gates, and the stack-detection rules are the same in both places — this skill exists so the same discipline applies even when the user talks to the general assistant instead of explicitly summoning `dev-lead`.
