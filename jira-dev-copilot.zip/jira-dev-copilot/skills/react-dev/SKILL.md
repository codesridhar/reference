---
name: react-dev
description: Reference for implementing, fixing, and testing React applications — functional component and hooks conventions, state-management detection, prop typing, file naming, and Jest/React Testing Library test patterns and commands. Use when working on "React component", "fix this React bug", "React hook", "write a React test", "React story", or any task in a repo with react/react-dom in package.json.
---

# React Development

Reference knowledge for implementing Jira stories in React codebases. Load this after the stack has been identified as React. Pair with the `react-developer` agent, which owns the implementation loop — this file is the checklist/knowledge base it should consult.

## 1. Detect the project shape before writing code

- Confirm React: `package.json` has `react` and `react-dom` dependencies.
- Identify the framework/tooling layer, because it changes routing, build, and env-var conventions:
  - **Next.js**: `next` in `package.json`, presence of `next.config.js`/`next.config.mjs`, and either a `pages/` or `app/` directory. `app/` directory = App Router (React Server Components, `page.tsx`/`layout.tsx` files, server vs client components distinguished by `'use client'` directive). `pages/` directory only = Pages Router (older, all client-rendered by default with `getServerSideProps`/`getStaticProps` for data).
  - **Vite**: `vite.config.ts`/`vite.config.js` present, `vite` in devDependencies, entry via `src/main.tsx`.
  - **Create React App (CRA)**: `react-scripts` in `package.json` dependencies, `public/index.html` + `src/index.js`. Treat as legacy/maintenance-mode — CRA is deprecated; don't introduce new CRA-specific patterns, but don't migrate off it as a drive-by change either.
- Check for `.jsx` vs `.tsx` — if `.tsx`/`.ts` files exist and `typescript` is a dependency, the project is TypeScript; write new code in TypeScript matching existing patterns. Do not introduce `.jsx` files into a `.tsx`-only codebase.

## 2. Component conventions

- Functional components + hooks are the default for any codebase started in the hooks era (React 16.8+, which is effectively all current codebases). Only use class components if the file you're editing is already a class component — match the surrounding code, don't rewrite a class component to hooks as an unrelated drive-by change during a bug fix.
- Component definition style — check existing files for the dominant pattern before picking one:
  ```tsx
  // Arrow function + const (common in TS codebases)
  export const UserCard = ({ user }: UserCardProps) => { ... };

  // function declaration (common in CRA/JS codebases)
  export default function UserCard({ user }) { ... }
  ```
- Keep components small and single-purpose; extract shared logic into custom hooks (`useX` naming, in a `hooks/` folder or colocated `use-feature.ts`) rather than duplicating `useEffect`/`useState` logic across components.
- Common hook pitfalls to check for: missing dependency array entries in `useEffect` (don't just silence the eslint-plugin-react-hooks warning — fix the actual dependency), and unnecessary `useEffect` for values that could be computed directly during render or via `useMemo`.

## 3. State management — detect what's already there, don't introduce a new one

Check `package.json` dependencies in this order and follow whichever is present:
- **Redux Toolkit** (`@reduxjs/toolkit`, `react-redux`): look for a `store/` or `redux/` directory with `slice` files (`createSlice`). New state goes into a new or existing slice; components read via `useSelector`, dispatch via `useDispatch` (or the typed `useAppSelector`/`useAppDispatch` hooks if the repo defines them).
- **Zustand** (`zustand`): look for a `store.ts`/`useStore.ts` with `create()`. State and actions typically live together in one hook; call the store hook directly in components, no Provider wrapping needed unless the repo has set one up for scoping.
- **Recoil** (`recoil`): look for `atom()`/`selector()` definitions, usually in a `state/` or `atoms/` folder; components use `useRecoilState`/`useRecoilValue`.
- **Context API only** (no state library dependency, `createContext`/`useContext` used directly): check for a `contexts/` or `providers/` folder. Follow the existing provider composition pattern (often a single `AppProviders` wrapper) rather than adding a new top-level provider in `main.tsx`/`_app.tsx` directly.
- If none of the above and state is entirely local (`useState`/`useReducer` in components, prop drilling), don't introduce a state management library to solve a single story — that's a scope-creep architecture decision, not a bug fix or feature task. Flag it if prop drilling is genuinely unworkable.

## 4. Prop typing

- TypeScript projects: define a `Props` interface (or `type`) per component, exported if other files need to reference it: `interface UserCardProps { user: User; onSelect?: (id: string) => void; }`. Avoid `any` — if the shape is genuinely unknown, use `unknown` and narrow.
- JavaScript-only projects: check for `prop-types` in dependencies. If present, use `PropTypes` on every new component matching existing usage (`UserCard.propTypes = { user: PropTypes.object.isRequired }`). If prop-types is not used anywhere in the repo, don't introduce it for one component — match repo convention.

## 5. File and folder naming

- Component files: PascalCase matching the component name (`UserCard.tsx`, `UserCard.jsx`). One default-exported (or named-exported, check repo convention) component per file.
- Colocate tests next to the component: `UserCard.tsx` + `UserCard.test.tsx` (or `.spec.tsx` — check which suffix the repo already uses; don't mix both in the same codebase) in the same folder, or under a sibling `__tests__/` directory if that's the established pattern.
- Hooks: `useSomething.ts`, camelCase starting with `use`.
- Non-component utility files: camelCase (`formatDate.ts`, `apiClient.ts`).
- Barrel files (`index.ts` re-exporting a folder's contents) — only add one if the folder already uses that pattern elsewhere in the repo.

## 6. Testing — Jest + React Testing Library

- Core imports: `import { render, screen } from '@testing-library/react'; import userEvent from '@testing-library/user-event';`.
- Query priority (per RTL guidance — use in this order of preference): `getByRole` > `getByLabelText` > `getByPlaceholderText` > `getByText` > `getByTestId` (last resort, only if the repo already leans on `data-testid`).
- Avoid testing implementation details: don't assert on internal state, don't shallow-render and inspect props. Test what the user sees and does:
  ```tsx
  test('submits the form with entered email', async () => {
    render(<SignupForm onSubmit={mockSubmit} />);
    await userEvent.type(screen.getByLabelText(/email/i), 'a@b.com');
    await userEvent.click(screen.getByRole('button', { name: /sign up/i }));
    expect(mockSubmit).toHaveBeenCalledWith({ email: 'a@b.com' });
  });
  ```
- Use `userEvent` over `fireEvent` for anything simulating real user interaction (typing, clicking) — it more accurately dispatches the full sequence of DOM events. `fireEvent` is acceptable for low-level DOM event tests only.
- Mock network calls (`fetch`/`axios`) rather than hitting real endpoints — check if the repo uses MSW (`msw` in devDependencies, look for a `mocks/` or `handlers.ts` directory) as the standard, and add handlers there rather than ad-hoc per-test mocking if MSW is already the convention.
- Wrap components needing context/router/store in a custom `render` helper if the repo already defines one (commonly `test-utils.tsx` re-exporting `render` with providers baked in) — use that helper instead of raw RTL `render` when the component depends on providers.

## 7. Running tests

- Check `package.json` `scripts` first — the actual invocation varies by tooling:
  - CRA: `npm test` (interactive watch mode by default). For a single non-interactive run (what to use after implementing a story, e.g., in CI or before handoff): `npm test -- --watchAll=false` (or `CI=true npm test` which CRA auto-detects to run once).
  - Vite + Vitest: check if `vitest` replaces Jest (`"test": "vitest"` in scripts) — run `npm run test -- --run` for a single pass, or `npx vitest run`.
  - Next.js / generic Jest setup: `npm test` or `npm run test -- --watchAll=false`, or `npx jest --watchAll=false` directly if no convenient script exists.
- Always run tests non-interactively (no open watch mode) when verifying a story is complete, since the agent needs a terminating command with a pass/fail exit code.

## 8. Linting

```bash
npx eslint . --ext .js,.jsx,.ts,.tsx
```
or, more reliably, check `package.json` for the project's own lint script and use that instead (`npm run lint`) — it will already carry the correct flags/config path (`.eslintrc`, `eslint.config.js` flat config, etc.). Fix reported errors before considering the story done; don't blanket-disable rules.

## 9. Common pitfalls to avoid

- Introducing a new state management library or routing library because it's "cleaner" — always match what's already in `package.json`.
- Using `useEffect` for derived state that could just be computed inline or via `useMemo` — a very common React anti-pattern reviewers flag.
- Missing `key` props (or using array index as `key` on lists that can reorder/filter) when rendering lists — use a stable unique id from the data.
- Directly mutating state objects/arrays instead of creating new references (`setState(prev => ({...prev, x: 1}))` not `state.x = 1; setState(state)`) — breaks React's change detection.
- Forgetting to guard client-only browser APIs (`window`, `localStorage`) in Next.js Server Components / SSR contexts — wrap in `useEffect` or check `typeof window !== 'undefined'`, and confirm whether the file needs a `'use client'` directive in App Router.
- Writing tests that query by CSS class or DOM structure instead of accessible role/label — brittle and against RTL's guiding philosophy.
