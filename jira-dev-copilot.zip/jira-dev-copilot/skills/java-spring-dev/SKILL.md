---
name: java-spring-dev
description: Reference for implementing, fixing, and testing Java Spring Boot services — layered architecture, constructor injection, REST/HTTP conventions, Spring Data JPA, validation, exception handling, configuration profiles, and JUnit5/Mockito/Testcontainers test patterns and build commands. Use when working on "Spring Boot endpoint", "Java microservice", "fix this Spring bug", "write a JUnit test", "Spring Boot story", or any task in a repo with pom.xml/build.gradle containing spring-boot-starter.
---

# Java Spring Boot Development

Reference knowledge for implementing Jira stories in Spring Boot codebases. Load this after the stack has been identified as Java/Spring. Pair with the `java-spring-developer` agent, which owns the implementation loop — this file is the checklist/knowledge base it should consult.

## 1. Detect the project before writing code

- Maven: `pom.xml` at root (or module root in a multi-module build) containing a `spring-boot-starter*` dependency and typically `spring-boot-starter-parent` as the parent, or `spring-boot-dependencies` in `dependencyManagement` for repos not using the parent POM.
- Gradle: `build.gradle`/`build.gradle.kts` with `org.springframework.boot` plugin and `implementation 'org.springframework.boot:spring-boot-starter*'` dependencies.
- Identify the Spring Boot major version (`<parent><version>` in pom.xml, or the plugin version in build.gradle) — Spring Boot 3.x requires Java 17+ and uses `jakarta.*` namespaces (not `javax.*`); Spring Boot 2.x uses `javax.*`. Getting this wrong causes immediate compile failures — check one existing import (e.g. `jakarta.persistence.Entity` vs `javax.persistence.Entity`) before writing new JPA/validation annotations.
- Check for a multi-module structure (parent `pom.xml` with `<modules>`) vs a single-module service — locate the actual service module before editing.

## 2. Layered architecture — respect existing boundaries

Standard layering, top to bottom:
- **Controller** (`@RestController`): HTTP concerns only — request mapping, status codes, request/response DTOs. No business logic, no direct repository calls.
- **Service** (`@Service`): business logic, transaction boundaries (`@Transactional`), orchestrates repositories.
- **Repository** (`@Repository`, usually a Spring Data JPA interface): data access only.
- **DTO**: request/response shapes exposed at the API boundary — never leak JPA `@Entity` objects directly out of the controller. Map entity ↔ DTO explicitly, or via MapStruct/ModelMapper if already a dependency (check `pom.xml`/`build.gradle` before introducing a mapping library).
- Package structure is typically `com.company.service.{controller,service,repository,dto,entity,exception,config}` (package-by-layer) or `com.company.service.{feature}/...` (package-by-feature) — check the existing package layout of the module before deciding where a new class belongs; don't mix conventions within one module.

## 3. Dependency injection — constructor injection only

- Always use constructor-based injection, never field injection (`@Autowired` on a field) for new code:
  ```java
  @Service
  public class OrderService {
      private final OrderRepository orderRepository;
      private final PaymentClient paymentClient;

      public OrderService(OrderRepository orderRepository, PaymentClient paymentClient) {
          this.orderRepository = orderRepository;
          this.paymentClient = paymentClient;
      }
  }
  ```
- If the project has Lombok as a dependency (`lombok` in pom.xml/build.gradle), use `@RequiredArgsConstructor` on `final` fields instead of hand-writing the constructor — but only if Lombok is already used elsewhere in the module; don't introduce Lombok into a Lombok-free codebase for one class.
- `@Autowired` on the constructor is optional/redundant when there's only one constructor (Spring auto-detects it) — omit it unless the file's existing style includes it.

## 4. REST conventions

- `@RestController` + `@RequestMapping("/api/v1/orders")` at the class level, HTTP-method-specific annotations at the method level (`@GetMapping`, `@PostMapping("/{id}")`, `@PutMapping`, `@PatchMapping`, `@DeleteMapping`).
- Always return `ResponseEntity<T>` for explicit status code control rather than a bare object, unless the existing controller consistently returns bare objects/DTOs and relies on default 200 — match the file's convention:
  ```java
  @GetMapping("/{id}")
  public ResponseEntity<OrderResponse> getOrder(@PathVariable Long id) {
      return ResponseEntity.ok(orderService.getOrder(id));
  }

  @PostMapping
  public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody OrderRequest request) {
      OrderResponse created = orderService.createOrder(request);
      return ResponseEntity.status(HttpStatus.CREATED).body(created);
  }
  ```
- Correct status codes matter: `200 OK` reads, `201 Created` for POST that creates a resource (with a `Location` header if the repo convention includes one), `204 No Content` for successful DELETE, `400 Bad Request` for validation failures, `404 Not Found` for missing resources, `409 Conflict` for state conflicts.

## 5. Spring Data JPA repository patterns

- Extend `JpaRepository<Entity, IdType>` (or `CrudRepository` if the repo is deliberately minimal — check existing repositories):
  ```java
  public interface OrderRepository extends JpaRepository<Order, Long> {
      List<Order> findByCustomerIdAndStatus(Long customerId, OrderStatus status);
      Optional<Order> findByOrderNumber(String orderNumber);
  }
  ```
- Prefer derived query methods (method-name-based) for simple lookups; use `@Query` (JPQL or native) for anything the naming convention can't express cleanly. Avoid `@Query(nativeQuery = true)` unless the existing repo already relies on native SQL for similar cases — it bypasses JPQL portability.
- Return `Optional<T>` for single-result lookups that may not find a match; unwrap explicitly with `.orElseThrow(() -> new ResourceNotFoundException(...))` in the service layer, not the repository.
- Use pagination (`Pageable`, return `Page<T>`) for any list endpoint that could return unbounded rows — check whether the repo already has a pagination convention for other list endpoints and match it.

## 6. Validation

- Annotate request DTOs with Bean Validation constraints (`@NotNull`, `@NotBlank`, `@Size`, `@Email`, `@Positive`, etc. from `jakarta.validation.constraints` in Boot 3.x / `javax.validation.constraints` in Boot 2.x).
- Trigger validation in the controller with `@Valid @RequestBody OrderRequest request` — validation failures throw `MethodArgumentNotValidException`, which should be handled centrally (see exception handling below), not with manual `if` checks duplicating what annotations already express.
- For cross-field validation not expressible with standard annotations, use a custom validator (`@Constraint` + `ConstraintValidator`) if the repo already has a pattern for these, otherwise validate in the service layer and throw a domain exception.

## 7. Centralized exception handling

- Look for an existing `@ControllerAdvice` (often `GlobalExceptionHandler`) class before creating a new one — add new `@ExceptionHandler` methods there rather than scattering try/catch in controllers:
  ```java
  @ControllerAdvice
  public class GlobalExceptionHandler {
      @ExceptionHandler(ResourceNotFoundException.class)
      public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex) {
          return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ErrorResponse(ex.getMessage()));
      }

      @ExceptionHandler(MethodArgumentNotValidException.class)
      public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
          return ResponseEntity.badRequest().body(ErrorResponse.fromBindingResult(ex.getBindingResult()));
      }
  }
  ```
- Define custom domain exceptions (`ResourceNotFoundException`, `InvalidStateException`, etc.) in an `exception` package rather than throwing generic `RuntimeException` — check what custom exceptions already exist before adding a near-duplicate.

## 8. Configuration via application.yml and profiles

- Config lives in `src/main/resources/application.yml` (or `.properties` — check which the repo uses; don't mix formats), with profile-specific overrides in `application-{profile}.yml` (`application-dev.yml`, `application-prod.yml`, `application-test.yml`).
- Never hardcode environment-specific values (DB URLs, API keys, feature flags) in Java code — bind them via `@ConfigurationProperties` (preferred for grouped settings) or `@Value("${some.property}")` for single values, sourced from the yml files or environment variables.
- Test-specific config typically lives in `src/test/resources/application-test.yml` or `application.yml` under `src/test/resources`, often paired with an `application-test` profile activated via `@ActiveProfiles("test")` on test classes.

## 9. Testing

- **Unit tests** (service/logic layer, no Spring context): JUnit 5 + Mockito.
  ```java
  @ExtendWith(MockitoExtension.class)
  class OrderServiceTest {
      @Mock private OrderRepository orderRepository;
      @InjectMocks private OrderService orderService;

      @Test
      void getOrder_returnsOrder_whenExists() {
          when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder()));
          OrderResponse result = orderService.getOrder(1L);
          assertThat(result.getId()).isEqualTo(1L);
      }
  }
  ```
  Use AssertJ (`assertThat`) if already a dependency; otherwise plain JUnit `assertEquals` matching existing test style.
- **Web layer tests** (controller only, mocked service): `@WebMvcTest(OrderController.class)` + `MockMvc` to test request mapping, status codes, and JSON serialization without loading the full application context.
  ```java
  @WebMvcTest(OrderController.class)
  class OrderControllerTest {
      @Autowired private MockMvc mockMvc;
      @MockBean private OrderService orderService;

      @Test
      void getOrder_returns200() throws Exception {
          mockMvc.perform(get("/api/v1/orders/1"))
                 .andExpect(status().isOk());
      }
  }
  ```
- **Full integration tests**: `@SpringBootTest` loads the entire application context — use for tests that need real bean wiring across layers. Pair with `Testcontainers` (check for `org.testcontainers` in dependencies) when the test needs a real database/message broker rather than an in-memory fake — look for an existing `@Testcontainers` base test class or `@Container` field pattern before writing a new one from scratch.
- Match whichever test types already exist in the module for the layer you're touching — don't add `@SpringBootTest` integration tests for something the repo tests exclusively at the unit level, and vice versa.

## 10. Running builds and tests

Maven:
```bash
mvn clean test          # run the test suite
mvn clean verify         # test + any bound integration-test/checkstyle phases
mvn spring-boot:run       # run the service locally for manual verification
```
Gradle:
```bash
./gradlew test
./gradlew build
./gradlew bootRun
```
- Always run the test suite (`mvn clean test` or `./gradlew test`) after implementing a story before considering it done. If Testcontainers-based integration tests are present, confirm Docker is available in the environment — Testcontainers tests will fail/hang without a running Docker daemon.
- Check for a `checkstyle`/`spotbugs`/`pmd` plugin bound to the build (`grep -i checkstyle pom.xml`) — if present, run `mvn checkstyle:check` or let `mvn verify` catch style violations before finishing.

## 11. Common pitfalls to avoid

- Field injection (`@Autowired` on a field) instead of constructor injection — harder to test, hides required dependencies.
- Leaking JPA entities directly as API responses — couples the DB schema to the public API contract and risks lazy-loading serialization errors.
- Business logic in the controller layer.
- Catching exceptions locally in a controller instead of letting a centralized `@ControllerAdvice` handle them.
- Mixing `javax.*` and `jakarta.*` imports in the same Boot 3.x module (leftover from a Boot 2→3 migration) — always check which namespace the module has standardized on.
- Missing `@Transactional` on service methods that perform multiple related writes, or over-applying `@Transactional` at the controller layer (transactions belong in the service layer).
