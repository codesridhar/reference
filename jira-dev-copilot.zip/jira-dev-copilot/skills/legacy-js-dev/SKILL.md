---
name: legacy-js-dev
description: Reference for stabilizing and patching legacy JavaScript applications built on Backbone, Marionette, jQuery, Underscore/Handlebars templates, and LESS — detection of the actual build/template/framework stack in use, Backbone/Marionette lifecycle conventions, jQuery event delegation idioms, and manual/automated verification steps. Use when working on "Backbone view", "jQuery fix", "Marionette region", "Handlebars template", "LESS stylesheet", "legacy JS bug", "Underscore template", or any task in a repo with jquery/backbone/underscore in package.json.
---

# Legacy JavaScript (Backbone / Marionette / jQuery) Development

Reference knowledge for implementing Jira stories against legacy Backbone-era codebases. Load this after the stack has been identified as legacy JS. Pair with the `legacy-js-developer` agent, which owns the implementation loop — this file is the checklist/knowledge base it should consult.

**The prime directive for this stack: stabilize, don't modernize.** These codebases are almost always in maintenance mode. Do not refactor to ES6 classes, do not introduce a bundler switch, do not rewrite Underscore templates to Handlebars or vice versa, do not swap `var` for `let/const` outside lines you're already touching for the fix. Match the existing style exactly, even if it's dated. Scope creep here creates outsized regression risk in a codebase with weak or no test coverage.

## 1. Detect the actual stack before touching anything

Do not assume — confirm what's really in use, because "legacy JS" covers a wide range of combinations:
- Check `package.json` (or `bower.json` if Bower is in use) dependencies for: `jquery`, `backbone`, `underscore` (or `lodash` used in its place), `backbone.marionette` (or `marionette`), `handlebars`.
- Check for a `Gruntfile.js` or `gulpfile.js` at the root — this tells you how the app is actually built/bundled (concatenation order, template precompilation task, LESS compilation task). Read the relevant task definitions before assuming how your changes will be picked up.
- Check for `bower.json` or a `vendor/`/`lib/` folder of manually-vendored JS — these repos often predate npm-only dependency management; some libraries may not be in `package.json` at all.
- Check for `require.config` or a `main.js`/`app.js` RequireJS config — if AMD modules (`define(...)`, `require(...)`) are used, follow the existing module wrapper pattern exactly; do not convert a file to CommonJS/ESM `import` syntax.
- Determine whether Marionette is actually present (`backbone.marionette` in deps) — if not, this is plain Backbone and you should not introduce Marionette's `ItemView`/`Region`/`Application` abstractions.
- Determine which template engine is actually used by grepping the specific files you're editing, not just the repo overall — some legacy repos have both Underscore and Handlebars present from an incomplete historical migration. Check the view file's `template` property or `render()` method to see which compiler it calls (`_.template(...)` vs `Handlebars.compile(...)`) before writing or editing a template.

## 2. Backbone Model/Collection/View lifecycle

- **Model**: `initialize()` runs on instantiation; use it for setting up listeners (`this.listenTo(this, 'change:status', this.onStatusChange)`), not for logic that belongs in a service/utility. `defaults` for default attribute values, `validate()` for model-level validation triggered on `save()`/`set(..., {validate: true})`.
- **Collection**: `model` property points to the Model class it holds, `url`/`urlRoot` or a custom `sync` for REST endpoint wiring, `comparator` for sort order. Fetch with `collection.fetch({success, error})` (or `.then()` if the repo's Backbone version returns a promise-like from `fetch`/`sync` — check the Backbone version in `package.json`).
- **View**: 
  - `initialize()` — set up the view, bind model/collection listeners (`this.listenTo(this.model, 'change', this.render)`).
  - `render()` — must return `this` (Backbone convention, allows chaining `view.render().el`). Rebuilds `this.$el`'s contents from the template + current model/collection data.
  - `events` hash — declarative delegated event bindings, always prefer this over manual `.on()` binding in `render()`:
    ```js
    events: {
      'click .save-btn': 'onSaveClick',
      'change input[name="email"]': 'onEmailChange',
      'submit form': 'onSubmit'
    }
    ```
  - `remove()` — Backbone's built-in cleanup (unbinds DOM events, stops listening); call it (or ensure the parent region/container calls it) when a view is discarded, to avoid zombie views/listeners. This is the Backbone-era equivalent of the unsubscribe problem in modern frameworks — check that new/replaced views are actually removed, not just detached from the DOM.
- Always call `this.listenTo(...)` (not `model.on(...)` directly) so Backbone can clean up listeners automatically when the view itself is removed via `stopListening()`.

## 3. Marionette-specific patterns (only if Marionette is confirmed present)

- **ItemView / View** (Marionette 2.x calls it `ItemView`, Marionette 3.x+ unified to `View`) — renders a single model/template, has its own `render()` lifecycle triggering `before:render`/`render` events.
- **CollectionView** — renders a collection as a list of child views (one child view per model), define `childView` to specify which view class to use per item.
- **CompositeView** — like CollectionView but with its own template wrapping the children (e.g., a table with a `<thead>` template plus per-row child views) — check for a `childViewContainer` selector indicating where children get appended within the composite's own rendered template.
- **Region** — a placeholder for swapping views in/out of a DOM slot: `myRegion.show(view)` automatically closes/removes whatever view was previously shown there, handling the cleanup Backbone leaves manual. If you're manually calling `.remove()` and `.append()` in application code where a Region already exists, prefer using the Region API instead — check `app.js`/the layout view for defined regions before wiring up views by hand.
- **Application** — the root Marionette object often orchestrating region/module startup (`App.start()`); check its `initialize`/`onStart` for where module-level wiring happens before adding new global initialization.
- Check the Marionette version in `package.json` — 2.x and 3.x+ have meaningfully different APIs (`ItemView` renamed to `View`, `LayoutView` renamed to `View` with regions, `vent`/global event aggregator patterns differ). Match whichever version-specific API the surrounding code already uses.

## 4. Templates — identify which engine before editing

- **Underscore templates** (`_.template`): look for `<% %>` / `<%= %>` / `<%- %>` delimiters in `.html`/`.tpl`/`.underscore` files, or inline template strings. `<%= %>` outputs unescaped, `<%- %>` HTML-escapes — preserve whichever the surrounding template already uses per-value; don't casually switch escaping behavior (XSS-relevant).
- **Handlebars templates** (`Handlebars.compile`): look for `{{ }}` / `{{{ }}}` delimiters (double braces = HTML-escaped, triple = raw). Check for a `helpers/` or `templates/helpers.js` file registering custom helpers (`Handlebars.registerHelper('formatDate', ...)`) before writing inline logic in a template — legacy Handlebars setups often already have a helper for common formatting needs. Partials are registered via `Handlebars.registerPartial('partialName', ...)` and referenced as `{{> partialName}}` — check the build task (Grunt/Gulp) for how `.hbs` files get compiled and registered (often a `grunt-contrib-handlebars` task producing a precompiled template JS bundle).
- Never introduce the other engine into a file that already uses one — identify the file's existing engine first (see section 1) and stay consistent even if the story would be "easier" in the other engine.

## 5. LESS stylesheets

- Variables (`@variable-name: value;`), nesting (`.parent { .child { } }`), and mixins (`.mixin() { }`, invoked as `.mixin();`) — follow the existing variable names for colors/spacing rather than hardcoding new literal values; check for a `variables.less`/`vars.less` partial imported at the top of the stylesheet tree.
- Check the Gruntfile/gulpfile for the LESS compilation task (commonly `grunt-contrib-less` or a `gulp-less` pipe) to understand the entry point file (often `main.less` or `app.less` importing all partials via `@import`) and the output CSS path — editing a partial that isn't `@import`ed anywhere will silently have no effect.
- Match existing nesting depth and mixin usage conventions in the specific file being edited; don't introduce LESS features (e.g., guards, loops) not already used elsewhere in the codebase.

## 6. jQuery DOM manipulation and event delegation

- Use delegated events scoped to the view's own root element rather than binding directly to descendant elements or, worse, `document`:
  ```js
  // Idiomatic Backbone view pattern — declarative, auto-scoped to this.$el
  events: {
    'click .item-row': 'onItemClick'
  }

  // Equivalent manual delegation if binding outside the events hash is unavoidable
  this.$el.on('click', '.item-row', this.onItemClick.bind(this));
  ```
- Always scope jQuery lookups to `this.$el` / `this.$(...)` inside a view (`this.$('.save-btn')`) rather than global `$('.save-btn')`, which risks matching elements from other views/instances on the page.
- Clean up manually-bound (non-events-hash) handlers in an overridden `remove()` if the view binds anything outside the `events` hash (e.g., a global `$(window).on('resize', ...)`) — call `$(window).off('resize', this.onResize)` there, otherwise the handler leaks past the view's lifecycle.

## 7. Testing — check for a runner first, fall back to manual verification steps

- Look for `karma.conf.js` (Karma + Jasmine is the most common legacy Backbone test setup) or `qunit`/`QUnit` referenced in `package.json`/a `test/` folder's HTML runner file. Run whichever is configured:
  ```bash
  # Karma (check package.json scripts for the exact invocation, commonly:)
  npx karma start karma.conf.js --single-run

  # QUnit via a Grunt task, if configured
  grunt qunit
  ```
- If a test runner config exists, write new tests matching its existing spec file conventions (`*.spec.js`/`*_test.js`, wherever the `test/` or `spec/` directory already places them) and run the suite before considering the story done.
- If no automated test infrastructure exists at all (very common in these codebases) — do not introduce a new test framework as part of a bug-fix/feature story; that is a separate, explicitly-scoped initiative. Instead, write explicit manual verification steps as part of the deliverable: concrete, numbered actions plus expected observations, e.g.:
  1. Navigate to `/orders/123`.
  2. Click the "Edit" button in the order header row.
  3. Confirm the form renders with the order's existing `customerName` and `status` pre-filled.
  4. Change `status` to "Shipped" and click "Save".
  5. Confirm the row re-renders showing "Shipped" without a full page reload, and the `PATCH /api/orders/123` network call (check via browser devtools) returns 200.
  6. Refresh the page and confirm the change persisted.
  These steps should be specific enough that anyone (including a non-technical reviewer) can execute them and know pass/fail — this is the substitute for automated coverage in these repos.

## 8. Common pitfalls to avoid

- Rewriting a Backbone View to a modern framework component "while you're in there" — out of scope, high regression risk, not what stabilization work calls for.
- Leaving zombie views: replacing a view's DOM without calling `remove()` on the old one, leaking listeners and delegated events.
- Introducing `let`/`const`/arrow functions/template literals into an ES5-only codebase if the build toolchain (old Grunt/Uglify config) isn't confirmed to transpile them — check for a `.babelrc`/Babel task in the Gruntfile/gulpfile before assuming ES6 syntax will actually run in target browsers.
- Mixing Underscore and Handlebars syntax in one template file.
- Editing a LESS partial that isn't actually `@import`ed into the compiled entry point, resulting in a change that silently never ships.
- Binding jQuery events globally (`$(document).on(...)`, unscoped `$('.selector')`) instead of scoping to `this.$el`, causing handlers to fire for the wrong instance when multiple views of the same type are on the page.
