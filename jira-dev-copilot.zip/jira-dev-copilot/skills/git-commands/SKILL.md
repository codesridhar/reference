---
name: git-commands
description: Provides exact raw git command sequences for branching, committing, and pushing without the gh CLI, plus opening pull requests via the GitHub REST API. Trigger on phrases like "commit this", "push my changes", "create a branch", "open a PR", "make a pull request", "git commands without gh cli", "check in my code", "push to origin", "create a feature branch for JIRA-1234", "commit and push", "raise a PR for this branch".
---

# Git Commands (no gh CLI)

This project has **no `gh` CLI installed**. Never invoke `gh` for any git or GitHub operation, including PR creation, PR listing, or auth. Everything below uses raw `git` and `curl` against the GitHub REST API instead.

## Permission precondition — read this first

This skill does not itself ask the user for permission to push or open a PR. It assumes the permission gate already happened upstream (Phase 9 "check-in" gate of the `sdlc-workflow` skill, or the equivalent gate in the `dev-lead` agent). Before running any command in the "Push" or "Open a pull request" sections below:

- Confirm there is clear evidence in the current conversation that the user explicitly said yes to pushing/checking in this specific change (e.g. an explicit "yes, push it" / "go ahead and commit" reply to a direct question).
- If there is no such evidence — e.g. this skill was invoked standalone, or the only "yes" on record was for something else (implementing the code, running tests) — **refuse to run push or PR commands** and tell the user you need explicit confirmation to check in code first. Local, non-mutating commands (`git status`, `git branch --show-current`, `git diff`, `git add`, local `git commit`) are fine to run without re-asking, since they don't touch remote state, but flag to the user that push/PR still needs their go-ahead.
- Never re-ask the permission question yourself if the calling skill/agent already asked it — just check for the evidence and proceed or refuse accordingly.

## Check current state

```
git status
git branch --show-current
git log --oneline -5
```

Run these first to confirm you're not already mid-work on an unexpected branch, and to see what's staged/unstaged before touching anything.

## Create a feature branch

Branch naming convention: `feature/<JIRA-KEY>-<slug>`, where `<slug>` is a short kebab-case summary of the story (lowercase, hyphens, no special characters).

```
git checkout -b feature/JIRA-1234-add-password-reset-flow
```

If the branch already exists locally (resuming work), switch to it instead:

```
git checkout feature/JIRA-1234-add-password-reset-flow
```

## Check the diff for secrets before committing

Always run this before staging, and again on the staged diff before committing:

```
git diff
git diff --cached
```

Scan the output for anything that looks like a credential, token, API key, password, or connection string. In particular:

- Never commit a `.env` file or any file containing `JIRA_API_TOKEN`, `GITHUB_PAT`, or similar secret values.
- If `.env` is not already in `.gitignore`, add it before staging anything:
  ```
  echo ".env" >> .gitignore
  ```
- If a secret shows up in the diff, unstage the offending file (`git restore --staged <file>`) and remove the secret from the file before proceeding. Do not commit first and "clean up later" — once pushed, a secret is compromised even if a later commit removes it.

## Stage and commit

Commit message convention: `[<JIRA-KEY>] <summary>` — a short, imperative summary of what changed.

```
git add -A
git commit -m "[JIRA-1234] Add password reset flow with email verification"
```

Prefer staging specific paths over `-A` when the working tree has unrelated changes you don't want swept in:

```
git add path/to/file1 path/to/file2
git commit -m "[JIRA-1234] Add password reset flow with email verification"
```

## Push with PAT-based auth (never print the token)

Do not put the PAT directly in the remote URL or in any command that gets echoed/logged — that leaks it into shell history and `git remote -v` output. Use one of these two approaches instead.

### Option A — one-shot credential helper (preferred)

This injects the credentials only for the duration of the push, and never writes them to disk or `git remote -v`:

```
git -c credential.helper='!f() { echo username=$GITHUB_USERNAME; echo password=$GITHUB_PAT; }; f' push -u origin feature/JIRA-1234-add-password-reset-flow
```

`GITHUB_USERNAME` and `GITHUB_PAT` must already be set as environment variables in the shell session — never hardcode them inline in the command. This approach leaves `git remote -v` showing the plain `origin` URL, with no token embedded anywhere.

### Option B — temporarily rewrite the remote URL, then restore it

Use this only if Option A's credential helper isn't viable in the current shell. Always restore the original URL immediately after, in the same sequence, so the token doesn't linger in `git remote -v`:

```
ORIGINAL_URL=$(git remote get-url origin)
git remote set-url origin "https://${GITHUB_USERNAME}:${GITHUB_PAT}@github.com/<owner>/<repo>.git"
git push -u origin feature/JIRA-1234-add-password-reset-flow
git remote set-url origin "$ORIGINAL_URL"
```

Verify the restore worked and no token is present:

```
git remote -v
```

If this output ever shows a token, immediately re-run `git remote set-url origin "$ORIGINAL_URL"` and treat the PAT as potentially exposed (recommend the user rotate it).

### Shell history hygiene

Because both options read `GITHUB_PAT` from an environment variable rather than typing it inline, the token itself never appears as a literal in any command — so it won't land in `.zsh_history`/`.bash_history` even though the commands themselves are logged. Do not construct commands that interpolate the raw token value as a literal string anywhere; always reference it via `$GITHUB_PAT`.

## Open a pull request without gh CLI

### Option A — GitHub REST API via curl

```
curl -s -X POST \
  -H "Authorization: token $GITHUB_PAT" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/{owner}/{repo}/pulls \
  -d '{"title":"[JIRA-1234] Add password reset flow","head":"feature/JIRA-1234-add-password-reset-flow","base":"main","body":"Implements password reset per JIRA-1234. See ticket for acceptance criteria and test results."}'
```

Replace `{owner}` and `{repo}` with the actual GitHub org/user and repository name. Set `head` to the pushed feature branch and `base` to the correct target branch (usually `main`, sometimes `develop` — check the repo convention first). As with push, `$GITHUB_PAT` must come from the environment, never typed literally in the command. Do not echo the curl command with the token substituted — keep it as the `$GITHUB_PAT` reference so nothing sensitive appears in any transcript or log.

Check the response for a `"html_url"` field on success and share that PR link with the user. If the response contains an `"errors"` or `"message"` field indicating failure (e.g. bad credentials, branch not found), report the failure clearly rather than assuming the PR was created.

### Option B — fallback: compare URL (no API call, no token needed)

If PAT-based PR creation isn't available or the user prefers to open the PR manually in the browser, just print the compare URL and let the user take it from there:

```
https://github.com/{owner}/{repo}/compare/feature/JIRA-1234-add-password-reset-flow?expand=1
```

This requires no credentials and is a safe default when there's any doubt about token scope/permissions for PR creation.

## Summary of hard rules

- Never invoke `gh` for anything.
- Never type a PAT or token as a literal value in any command — always reference it via an environment variable (`$GITHUB_PAT`, `$GITHUB_USERNAME`).
- Never commit `.env` or files containing `JIRA_API_TOKEN` / `GITHUB_PAT`; check `git diff`/`git diff --cached` for secrets before every commit.
- Never push or open a PR without clear evidence the user already granted permission for check-in in this conversation; refuse and ask if that evidence is missing.
- After any temporary remote-URL rewrite, always restore the original URL and verify with `git remote -v` that no token remains visible.
