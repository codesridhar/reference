# jira-dev-copilot

**A Claude Code / Cowork plugin that turns a Jira story into reviewed, tested, checked-in code — inside VS Code or IntelliJ — while keeping a human in the loop at every consequential step.**

`jira-dev-copilot` pulls a Jira story, analyzes it, asks clarifying questions when the requirements are ambiguous, routes the work to the right stack-specific developer agent (Angular, React, Java Spring, or legacy jQuery/Backbone/Underscore/Marionette/Handlebars/LESS), implements the change, writes and runs tests, performs an automated code review, and only then asks for your explicit permission before it touches `git` or Jira. A **Dev Lead** agent orchestrates the whole workflow and enforces every permission gate.

---

## What it does

`jira-dev-copilot` runs a 9-phase SDLC workflow for each story:

1. **Pull the Jira story** — fetch the issue (summary, description, acceptance criteria, comments, linked issues) via Atlassian MCP or the Jira REST API.
2. **Analyze** — the Jira Analyst agent breaks the story down into concrete engineering requirements.
3. **Clarify** — if the story is ambiguous or missing information, the plugin asks you clarifying questions before proceeding.
4. **Pick the right stack developer** — the Dev Lead inspects the target repository and routes implementation to the matching specialist: Angular, React, Java Spring Boot, or the legacy jQuery/Backbone/Underscore/Marionette/Handlebars/LESS stack.
5. **Ask permission to execute the plan** — 🔒 **Permission Gate 1**. The Dev Lead presents the implementation plan and stops until you approve it.
6. **Implement** — the selected stack developer agent writes the code.
7. **Write and run tests** — the QA Engineer agent adds/updates tests and runs the suite.
8. **Code review** — the Code Reviewer agent reviews the diff for correctness, style, and leaked secrets.
9. **Ask permission before check-in, then before Jira update** — 🔒 **Permission Gate 2** (git commit/push) and 🔒 **Permission Gate 3** (Jira status/comment update). Nothing is committed or reported back to Jira without your explicit go-ahead.

### The three permission gates

| Gate | When | What's asked |
|---|---|---|
| **1. Execute plan** | After analysis/clarification, before any code is written | "Here's my implementation plan — proceed?" |
| **2. Git check-in** | After implementation, tests, and code review pass | "Here's the diff — commit and push?" |
| **3. Jira update** | After a successful check-in | "Update PROJ-1234 status/comment — proceed?" |

These gates are enforced by the **dev-lead** agent and cannot be skipped by a stack developer, QA, review, or git-ops agent acting alone.

---

## Architecture

### Agents (`agents/`)

| Agent | Role |
|---|---|
| `dev-lead.md` | Orchestrates the full 9-phase workflow; owns and enforces all three permission gates. |
| `jira-analyst.md` | Pulls and analyzes the Jira story; drafts clarifying questions when requirements are ambiguous. |
| `qa-engineer.md` | Writes and runs tests for the implemented change. |
| `code-reviewer.md` | Reviews the diff for correctness, style, and leaked secrets before check-in. |
| `git-ops.md` | Performs raw `git` operations (branch, commit, push, PR) after Gate 2 approval — never uses `gh`. |
| `angular-developer.md` | Implements changes in Angular codebases. |
| `react-developer.md` | Implements changes in React codebases. |
| `java-spring-developer.md` | Implements changes in Java Spring Boot microservices. |
| `legacy-js-developer.md` | Implements changes in legacy jQuery/Backbone/Underscore/Marionette/Handlebars/LESS codebases. |

### Skills (`skills/`)

| Skill | Role |
|---|---|
| `sdlc-workflow/SKILL.md` | Defines the end-to-end 9-phase SDLC process and gate sequencing used by the Dev Lead. |
| `git-commands/SKILL.md` | Raw `git` CLI recipes (branch, commit, push, diff, PR fallback) — explicitly no `gh` CLI. |
| `angular-dev/SKILL.md` | Angular conventions, project structure, and testing patterns. |
| `react-dev/SKILL.md` | React conventions, project structure, and testing patterns. |
| `java-spring-dev/SKILL.md` | Java Spring Boot microservice conventions, project structure, and testing patterns. |
| `legacy-js-dev/SKILL.md` | Conventions for the legacy jQuery/Backbone/Underscore/Marionette/Handlebars/LESS stack. |

---

## Supported stacks

- **Angular**
- **React**
- **Java Spring Boot microservices**
- **Legacy jQuery + Backbone + Underscore + Marionette + Handlebars + LESS**

The Dev Lead auto-detects which stack applies by inspecting the target repository — package manifests (`package.json`, `pom.xml`/`build.gradle`), framework config files (`angular.json`, Spring Boot starters), and legacy stack fingerprints (Backbone/Marionette views, Handlebars templates, LESS stylesheets) — then hands the story off to the matching developer agent from the table above. If the stack can't be determined confidently, the Dev Lead asks you to confirm before proceeding (part of Gate 1).

---

## Install

```bash
npx jira-dev-copilot
```

This one-liner:

- Copies the plugin into `~/.claude/plugins/jira-dev-copilot`, where Claude Code and its IDE integrations auto-discover it.
- Runs an interactive config wizard that collects your Jira and GitHub credentials and writes them to `~/.jira-dev-copilot/.env`.

To reconfigure later (rotate a token, change the Jira base URL, etc.) without reinstalling:

```bash
npx jira-dev-copilot config
```

---

## Configuration

The config wizard (`bin/install.js`) writes the following environment variables to `~/.jira-dev-copilot/.env`:

| Variable | What it is | Where to generate it |
|---|---|---|
| `JIRA_BASE_URL` | Your Jira Cloud site URL, e.g. `https://yourcompany.atlassian.net` | Your Jira admin/site settings |
| `JIRA_EMAIL` | The email address associated with your Jira account | — |
| `JIRA_API_TOKEN` | API token used to authenticate direct Jira REST API v3 calls | `id.atlassian.com/manage-profile/security/api-tokens` |
| `GITHUB_USERNAME` | Your GitHub username, used for git remote auth | — |
| `GITHUB_PAT` | Classic Personal Access Token with `repo` scope, used to authenticate raw `git` operations and any GitHub REST API fallback | `github.com/settings/tokens` (generate classic token, `repo` scope) |

---

## Jira access

`jira-dev-copilot` uses a **dual-mode** approach to talk to Jira:

1. **Preferred:** if Claude's built-in Atlassian MCP connector tools are available in the current session, the `jira-analyst` and `dev-lead` agents use those directly (no extra config needed beyond having the connector enabled).
2. **Fallback:** if the Atlassian MCP connector isn't present, the plugin falls back to direct Jira REST API v3 calls, authenticated with `JIRA_EMAIL` + `JIRA_API_TOKEN` against `JIRA_BASE_URL`.

This means the plugin works whether or not your Claude Code session has the Atlassian connector configured — it degrades gracefully to REST calls using your locally stored token.

---

## GitHub access — no `gh` CLI

`jira-dev-copilot` **never invokes the `gh` CLI**. All git operations are performed with **raw `git` commands** (see `skills/git-commands/SKILL.md`), authenticated using the `GITHUB_PAT` (embedded in the remote URL or via a credential helper, per that skill's recipes).

Pull request creation, when needed, does **not** use `gh pr create`. Instead it:

- Falls back to a **direct GitHub REST API call** (`POST /repos/{owner}/{repo}/pulls`) authenticated with the PAT, or
- If that's unavailable, **prints a compare URL** (`https://github.com/{owner}/{repo}/compare/{branch}?expand=1`) for you to open manually.

All of this only ever runs after Gate 2 (git check-in) approval.

---

## IDE usage

Once installed, the plugin surfaces automatically in **VS Code** and **IntelliJ** through Claude Code's IDE extensions, which auto-discover plugins under `~/.claude/plugins`. No IDE-specific setup is required beyond having the Claude Code IDE extension installed and signed in.

From either IDE's Claude Code panel, just type a natural-language request, for example:

- `work on PROJ-1234`
- `pick up this Jira story`
- `commit and open a PR for this`

The Dev Lead agent takes it from there — pulling the story, analyzing it, and walking through the 9-phase workflow with permission gates as described above.

---

## Optional: self-hosted MCP bridge for OpenShift (OSE)

Most developers don't need this — the built-in Atlassian MCP connector or the local Jira REST API fallback (see **Jira access** above) is enough. Teams that want a **shared, always-on bridge** (e.g. centralized credential management, consistent rate-limit behavior, or a single audit point for Jira/GitHub calls across the team) can deploy the optional self-hosted MCP bridge:

- `deploy/server/` — a Node/Express server that exposes Jira (and related) tools over MCP-over-SSE.
- `deploy/docker/Dockerfile` — a multi-stage build compatible with OpenShift's arbitrary-UID security model.
- `deploy/helm/jira-dev-copilot-mcp/` — a Helm chart provisioning the Deployment, Service, Route, Secret, and autoscaling for the bridge on OpenShift.
- `deploy/pipelines/tekton/` — a Tekton Pipeline that fetches source, builds/pushes the image with `buildah`, and runs `helm upgrade --install` against the target namespace.

Once deployed, point `.mcp.json`'s `jira-dev-copilot-bridge.url` (or the `JIRA_DEV_COPILOT_MCP_URL` env var it reads from) at the bridge's Route, and every developer's session will use the shared server instead of local tokens.

**Deploy via the Tekton pipeline:**

```bash
oc apply -f deploy/pipelines/tekton/task-build.yaml -f deploy/pipelines/tekton/pipeline.yaml
oc create -f deploy/pipelines/tekton/pipelinerun.yaml
```

**Or deploy directly with Helm:**

```bash
helm upgrade --install jira-dev-copilot-mcp deploy/helm/jira-dev-copilot-mcp -n <namespace>
```

---

## Security notes

- Credentials (`JIRA_API_TOKEN`, `GITHUB_PAT`, etc.) are stored locally in `~/.jira-dev-copilot/.env`, which is gitignored and never committed.
- Tokens are never printed to the console or written to logs by any agent or skill.
- The `code-reviewer` agent explicitly scans diffs for leaked secrets (API keys, tokens, credentials) before any check-in is permitted — this check runs before Gate 2.
- For the optional OpenShift deployment, the Helm chart's `Secret` template is a **convenience default for getting started**, not a production secret store. Production deployments should source secrets from a real secret manager (e.g. Vault, Sealed Secrets, or your cluster's external-secrets integration) rather than the chart's built-in Secret.

---

## Repository layout

```
jira-dev-copilot/
├── .claude-plugin/
│   └── plugin.json
├── .mcp.json
├── README.md
├── package.json
├── bin/
│   ├── dev-copilot.js
│   └── install.js
├── config/
│   ├── config.example.json
│   └── .env.example
├── agents/
│   ├── dev-lead.md
│   ├── jira-analyst.md
│   ├── qa-engineer.md
│   ├── code-reviewer.md
│   ├── git-ops.md
│   ├── angular-developer.md
│   ├── react-developer.md
│   ├── java-spring-developer.md
│   └── legacy-js-developer.md
├── skills/
│   ├── sdlc-workflow/SKILL.md
│   ├── git-commands/SKILL.md
│   ├── angular-dev/SKILL.md
│   ├── react-dev/SKILL.md
│   ├── java-spring-dev/SKILL.md
│   └── legacy-js-dev/SKILL.md
└── deploy/
    ├── docker/
    │   └── Dockerfile
    ├── server/
    │   └── ... (MCP-over-SSE bridge)
    ├── helm/
    │   └── jira-dev-copilot-mcp/
    │       └── ... (Deployment, Service, Route, Secret, autoscaling)
    └── pipelines/
        └── tekton/
            └── ... (Pipeline: build with buildah, push, helm upgrade --install)
```
