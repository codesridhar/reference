# Tekton pipeline for jira-dev-copilot-mcp

This directory contains OpenShift Pipelines (Tekton) artifacts to build,
push, and deploy the `jira-dev-copilot-mcp` server (see `deploy/server/`)
to an OpenShift cluster, using the Helm chart in
`deploy/helm/jira-dev-copilot-mcp/`.

Like the server itself, this pipeline is **optional infrastructure** —
only needed if your team wants automated CI/CD for the centrally-hosted
MCP bridge. It is not required to use the `jira-dev-copilot` plugin
locally.

## Prerequisites

- **OpenShift Pipelines operator** installed on the target cluster
  (provides the Tekton `Pipeline`/`Task`/`PipelineRun` CRDs and the
  `git-clone` ClusterTask used by `pipeline.yaml`).
- **`oc` CLI** logged in to the target cluster/project with permission to
  create Tekton resources.
- A **image pull/push secret** (e.g. a `quay.io` or internal OpenShift
  registry credential) linked to the pipeline's ServiceAccount (default:
  `pipeline`), so `buildah push` in `task-build.yaml` can authenticate.
  For example:

  ```bash
  oc create secret docker-registry jira-dev-copilot-mcp-registry-secret \
    --docker-server=quay.io \
    --docker-username=<user> \
    --docker-password=<password> \
    -n <namespace>

  oc secrets link pipeline jira-dev-copilot-mcp-registry-secret --for=pull,push -n <namespace>
  ```

- The pipeline's ServiceAccount also needs permission to run `helm
  upgrade --install` against the target namespace (the `deploy` task in
  `pipeline.yaml` runs Helm directly) — typically the `edit` role on the
  namespace is sufficient.

## Files

| File                  | Purpose                                                                |
|-----------------------|-------------------------------------------------------------------------|
| `task-build.yaml`     | Tekton `Task` that builds `deploy/docker/Dockerfile` (context `deploy/server`) with buildah and pushes the resulting image. |
| `pipeline.yaml`       | Tekton `Pipeline` wiring `fetch-source` (git-clone) → `build-and-push` (the Task above) → `deploy` (helm upgrade --install). |
| `pipelinerun.yaml`    | Example `PipelineRun` that binds concrete params (git repo/revision, image name/tag, namespace) and a PVC-backed workspace, and triggers the pipeline. |

## How to apply

```bash
# 1. Register the Task and Pipeline definitions in your namespace.
oc apply -f deploy/pipelines/tekton/task-build.yaml -f deploy/pipelines/tekton/pipeline.yaml -n <namespace>

# 2. Edit deploy/pipelines/tekton/pipelinerun.yaml to point at your fork /
#    registry / namespace, then trigger a run:
oc create -f deploy/pipelines/tekton/pipelinerun.yaml -n <namespace>

# 3. Watch the run:
tkn pipelinerun logs -f -n <namespace>
# or
oc get pipelinerun -n <namespace> --watch
```

## How this ties to the Helm chart

The `deploy` task in `pipeline.yaml` runs, from the cloned source
workspace:

```bash
helm upgrade --install jira-dev-copilot-mcp \
  ./deploy/helm/jira-dev-copilot-mcp \
  --set image.repository=$(params.image) \
  --set image.tag=$(params.image-tag) \
  -n $(params.namespace)
```

This reuses the same chart documented in `deploy/helm/jira-dev-copilot-mcp/`
— the pipeline only supplies the `image.repository`/`image.tag` values
that the chart's `values.yaml` intentionally leaves blank, so the same
chart can be deployed manually (`helm install ...`) or via this pipeline
with equivalent results.
