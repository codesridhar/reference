# jira-dev-copilot-mcp (server)

A small, self-hosted Model Context Protocol (MCP) server that exposes Jira
+ GitHub helper tools over HTTP/SSE. It's the optional "centrally-hosted
bridge" companion to the `jira-dev-copilot` Claude Code / Cowork plugin.

## Is this required?

**No.** The `jira-dev-copilot` plugin works fully locally without this
service. Its IDE-side agents/skills already fetch Jira data either through
Claude's built-in Atlassian MCP tools, or through a local fallback that
calls the Jira REST API directly using environment variables on the
developer's own machine.

Deploy this server only if your team wants a **shared, always-on, centrally
managed** Jira/GitHub bridge — for example, to avoid every developer having
to configure their own `JIRA_API_TOKEN`, or to centralize credential
rotation and auditing. Once deployed (see `deploy/helm/` and
`deploy/pipelines/tekton/` in this repo for OpenShift deployment
artifacts), every developer's `.mcp.json` can point at the same URL instead
of managing local secrets.

## Required environment variables

| Variable          | Description                                             |
|--------------------|----------------------------------------------------------|
| `JIRA_BASE_URL`    | Base URL of your Jira instance, e.g. `https://your-domain.atlassian.net` |
| `JIRA_EMAIL`       | Email address of the Jira account used for API auth      |
| `JIRA_API_TOKEN`   | Jira API token for that account (Basic Auth, base64-encoded `email:token`) |

Optional:

| Variable | Description                                   | Default |
|----------|------------------------------------------------|---------|
| `PORT`   | Port the HTTP server listens on                 | `8080`  |

These are read from `process.env` at request time — never hardcoded — so
credential rotation doesn't require a code change or rebuild.

## Running locally

```bash
cd deploy/server
npm install
export JIRA_BASE_URL="https://your-domain.atlassian.net"
export JIRA_EMAIL="you@example.com"
export JIRA_API_TOKEN="your-api-token"
npm start
```

The server exposes:

- `GET /healthz` — plain health check (`{"status":"ok"}`), used by
  OpenShift liveness/readiness probes.
- `GET /sse` — opens an MCP SSE stream.
- `POST /messages?sessionId=...` — MCP JSON-RPC message endpoint, paired
  with an open SSE session.

## Tools exposed

- `jira_get_issue` — fetch an issue's summary, description, status, and
  acceptance criteria.
- `jira_add_comment` — add a comment to an issue.
- `jira_transition_issue` — move an issue through workflow transitions by
  human-readable transition name (e.g. "In Progress", "Done").
- `github_compare_url` — pure string helper that builds a GitHub compare
  URL for a branch. No GitHub write operations happen server-side; actual
  git pushes stay local, handled by the plugin's git-ops agent.

## Referencing this server from a developer's `.mcp.json`

Once deployed (e.g. behind an OpenShift Route at
`https://jira-dev-copilot-mcp.apps.your-cluster.example.com`), point your
`.mcp.json` at the `/sse` endpoint:

```json
{
  "mcpServers": {
    "jira-dev-copilot-mcp": {
      "type": "sse",
      "url": "https://jira-dev-copilot-mcp.apps.your-cluster.example.com/sse"
    }
  }
}
```

No local `JIRA_BASE_URL`/`JIRA_EMAIL`/`JIRA_API_TOKEN` are needed on the
developer's machine in this mode — the server holds those credentials
centrally.

## Deployment artifacts

- `deploy/docker/Dockerfile` — container image build.
- `deploy/helm/jira-dev-copilot-mcp/` — Helm chart for OpenShift (Deployment,
  Service, Route, Secret, autoscaling).
- `deploy/pipelines/tekton/` — Tekton Pipeline/Task/PipelineRun to build,
  push, and deploy via the Helm chart.
