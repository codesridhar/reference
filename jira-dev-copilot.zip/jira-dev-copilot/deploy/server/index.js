/**
 * jira-dev-copilot-mcp — self-hosted MCP bridge server
 * ------------------------------------------------------
 * WHAT THIS IS:
 *   A small Express app that exposes a Model Context Protocol (MCP) server
 *   over HTTP + Server-Sent Events (SSE). It wraps the Jira REST API (v3)
 *   and a small GitHub link helper as MCP "tools" so that a team can deploy
 *   ONE centrally-hosted bridge (e.g. to an OpenShift cluster) instead of
 *   every developer needing local JIRA_BASE_URL / JIRA_EMAIL / JIRA_API_TOKEN
 *   environment variables configured on their own machine.
 *
 * WHY THIS IS OPTIONAL:
 *   The jira-dev-copilot plugin works fully locally without this service.
 *   The plugin's IDE-side agents/skills already fall back to calling the
 *   Jira REST API directly using local env vars, or to Claude's built-in
 *   Atlassian MCP tools when available. Deploying this server is only
 *   useful for teams that want a shared, always-on, centrally-managed
 *   bridge referenced from every developer's `.mcp.json` via a single URL
 *   (see deploy/server/README.md and deploy/helm/ for deployment details).
 *
 * NOTE ON DEPENDENCIES:
 *   To keep the dependency footprint minimal, this file intentionally does
 *   NOT depend on zod (or any schema library) for input validation. Tool
 *   parameters are validated by hand with plain JS checks inside each
 *   handler.
 */

const express = require("express");
const cors = require("cors");
const { McpServer } = require("@modelcontextprotocol/sdk/server/mcp.js");
const { SSEServerTransport } = require("@modelcontextprotocol/sdk/server/sse.js");

const PORT = process.env.PORT || 8080;

// -----------------------------------------------------------------------
// Jira REST helpers
// -----------------------------------------------------------------------

/**
 * Reads Jira connection settings from process.env at request time (never
 * hardcoded / never cached at module load), so that a redeploy or secret
 * rotation is picked up without a code change.
 */
function getJiraConfig() {
  const baseUrl = process.env.JIRA_BASE_URL;
  const email = process.env.JIRA_EMAIL;
  const apiToken = process.env.JIRA_API_TOKEN;

  if (!baseUrl || !email || !apiToken) {
    throw new Error(
      "Missing Jira configuration. Please set JIRA_BASE_URL, JIRA_EMAIL, " +
        "and JIRA_API_TOKEN environment variables on the server."
    );
  }

  return { baseUrl: baseUrl.replace(/\/+$/, ""), email, apiToken };
}

function jiraAuthHeader(email, apiToken) {
  const token = Buffer.from(`${email}:${apiToken}`).toString("base64");
  return `Basic ${token}`;
}

async function jiraFetch(path, options = {}) {
  const { baseUrl, email, apiToken } = getJiraConfig();
  const url = `${baseUrl}${path}`;

  const res = await fetch(url, {
    ...options,
    headers: {
      Authorization: jiraAuthHeader(email, apiToken),
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : {};
  } catch (e) {
    body = { raw: text };
  }

  if (!res.ok) {
    const err = new Error(
      `Jira API request failed: ${res.status} ${res.statusText} — ${JSON.stringify(body)}`
    );
    err.status = res.status;
    err.body = body;
    throw err;
  }

  return body;
}

/**
 * Extracts plain text from an Atlassian Document Format (ADF) node tree,
 * used for Jira `description` fields in API v3. Falls back gracefully if
 * the shape isn't what we expect.
 */
function adfToPlainText(adf) {
  if (!adf) return "";
  if (typeof adf === "string") return adf;

  let out = "";
  function walk(node) {
    if (!node) return;
    if (node.type === "text" && typeof node.text === "string") {
      out += node.text;
    }
    if (Array.isArray(node.content)) {
      node.content.forEach(walk);
    }
    if (node.type === "paragraph" || node.type === "hardBreak") {
      out += "\n";
    }
  }
  walk(adf);
  return out.trim();
}

// -----------------------------------------------------------------------
// MCP server + tool registration
// -----------------------------------------------------------------------

function buildMcpServer() {
  const server = new McpServer({
    name: "jira-dev-copilot-mcp",
    version: "0.1.0",
  });

  // ---- jira_get_issue -----------------------------------------------
  server.tool(
    "jira_get_issue",
    "Fetch a Jira issue by key and return its summary, description, status, " +
      "and acceptance criteria (if present as a custom field) as plain text.",
    {
      issueKey: {
        type: "string",
        description: "The Jira issue key, e.g. 'PROJ-123'.",
      },
    },
    async (params) => {
      const issueKey = params && params.issueKey;
      if (!issueKey || typeof issueKey !== "string") {
        throw new Error("Missing or invalid required parameter: issueKey (string)");
      }

      const issue = await jiraFetch(
        `/rest/api/3/issue/${encodeURIComponent(issueKey)}`,
        { method: "GET" }
      );

      const fields = issue.fields || {};
      const summary = fields.summary || "(no summary)";
      const status = (fields.status && fields.status.name) || "(unknown status)";
      const description = adfToPlainText(fields.description) || "(no description)";

      // Acceptance criteria commonly lives in a custom field; there is no
      // universal field id across Jira instances, so we scan for a field
      // whose name looks like "Acceptance Criteria" if the field metadata
      // is present, otherwise we note that none was found.
      let acceptanceCriteria = "(none found)";
      for (const [key, value] of Object.entries(fields)) {
        if (key.toLowerCase().includes("customfield") && value) {
          // Heuristic only — real field id should be configured per Jira
          // instance if this matters. We just surface anything plausible.
          continue;
        }
      }
      if (fields.acceptanceCriteria) {
        acceptanceCriteria = adfToPlainText(fields.acceptanceCriteria);
      }

      const text = [
        `Issue: ${issueKey}`,
        `Summary: ${summary}`,
        `Status: ${status}`,
        `Description: ${description}`,
        `Acceptance Criteria: ${acceptanceCriteria}`,
      ].join("\n");

      return {
        content: [{ type: "text", text }],
      };
    }
  );

  // ---- jira_add_comment ----------------------------------------------
  server.tool(
    "jira_add_comment",
    "Add a plain-text comment to a Jira issue.",
    {
      issueKey: {
        type: "string",
        description: "The Jira issue key, e.g. 'PROJ-123'.",
      },
      body: {
        type: "string",
        description: "The comment text to add.",
      },
    },
    async (params) => {
      const issueKey = params && params.issueKey;
      const body = params && params.body;

      if (!issueKey || typeof issueKey !== "string") {
        throw new Error("Missing or invalid required parameter: issueKey (string)");
      }
      if (!body || typeof body !== "string") {
        throw new Error("Missing or invalid required parameter: body (string)");
      }

      const payload = {
        body: {
          type: "doc",
          version: 1,
          content: [
            {
              type: "paragraph",
              content: [{ type: "text", text: body }],
            },
          ],
        },
      };

      const result = await jiraFetch(
        `/rest/api/3/issue/${encodeURIComponent(issueKey)}/comment`,
        { method: "POST", body: JSON.stringify(payload) }
      );

      return {
        content: [
          {
            type: "text",
            text: `Comment added to ${issueKey} (comment id: ${result.id || "unknown"}).`,
          },
        ],
      };
    }
  );

  // ---- jira_transition_issue ------------------------------------------
  server.tool(
    "jira_transition_issue",
    "Transition a Jira issue to a new status by matching a human-readable " +
      "transition name (e.g. 'In Progress', 'Done').",
    {
      issueKey: {
        type: "string",
        description: "The Jira issue key, e.g. 'PROJ-123'.",
      },
      transitionName: {
        type: "string",
        description: "The name of the transition to apply, e.g. 'In Progress'.",
      },
    },
    async (params) => {
      const issueKey = params && params.issueKey;
      const transitionName = params && params.transitionName;

      if (!issueKey || typeof issueKey !== "string") {
        throw new Error("Missing or invalid required parameter: issueKey (string)");
      }
      if (!transitionName || typeof transitionName !== "string") {
        throw new Error("Missing or invalid required parameter: transitionName (string)");
      }

      const transitionsResp = await jiraFetch(
        `/rest/api/3/issue/${encodeURIComponent(issueKey)}/transitions`,
        { method: "GET" }
      );

      const transitions = transitionsResp.transitions || [];
      const match = transitions.find(
        (t) => t.name && t.name.toLowerCase() === transitionName.toLowerCase()
      );

      if (!match) {
        const available = transitions.map((t) => t.name).join(", ") || "(none)";
        throw new Error(
          `No transition named '${transitionName}' found for ${issueKey}. ` +
            `Available transitions: ${available}`
        );
      }

      await jiraFetch(`/rest/api/3/issue/${encodeURIComponent(issueKey)}/transitions`, {
        method: "POST",
        body: JSON.stringify({ transition: { id: match.id } }),
      });

      return {
        content: [
          {
            type: "text",
            text: `Issue ${issueKey} transitioned via '${match.name}' (id: ${match.id}).`,
          },
        ],
      };
    }
  );

  // ---- github_compare_url ----------------------------------------------
  server.tool(
    "github_compare_url",
    "Build a GitHub compare URL for a branch (pure string helper — no " +
      "GitHub API calls or write operations are performed server-side; " +
      "actual git pushes stay local, handled by the plugin's git-ops agent).",
    {
      owner: {
        type: "string",
        description: "GitHub repository owner/org, e.g. 'my-org'.",
      },
      repo: {
        type: "string",
        description: "GitHub repository name, e.g. 'my-repo'.",
      },
      branch: {
        type: "string",
        description: "Branch name to compare, e.g. 'feature/PROJ-123-fix'.",
      },
    },
    async (params) => {
      const owner = params && params.owner;
      const repo = params && params.repo;
      const branch = params && params.branch;

      if (!owner || typeof owner !== "string") {
        throw new Error("Missing or invalid required parameter: owner (string)");
      }
      if (!repo || typeof repo !== "string") {
        throw new Error("Missing or invalid required parameter: repo (string)");
      }
      if (!branch || typeof branch !== "string") {
        throw new Error("Missing or invalid required parameter: branch (string)");
      }

      const url = `https://github.com/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/compare/${encodeURIComponent(branch)}?expand=1`;

      return {
        content: [{ type: "text", text: url }],
      };
    }
  );

  return server;
}

// -----------------------------------------------------------------------
// Express app: HTTP + SSE transport wiring
// -----------------------------------------------------------------------

const app = express();
app.use(cors());
app.use(express.json());

// Liveness/readiness probe target for OpenShift.
app.get("/healthz", (req, res) => {
  res.status(200).json({ status: "ok" });
});

// Map of active SSE transports keyed by session id, so that POST /messages
// can be routed to the right open SSE connection.
const activeTransports = new Map();

// GET /sse — client opens an SSE stream; we create a transport, connect
// the MCP server to it, and keep it registered for the lifetime of the
// connection.
app.get("/sse", async (req, res) => {
  const transport = new SSEServerTransport("/messages", res);
  activeTransports.set(transport.sessionId, transport);

  res.on("close", () => {
    activeTransports.delete(transport.sessionId);
  });

  const server = buildMcpServer();
  await server.connect(transport);
});

// POST /messages — client posts JSON-RPC messages; route to the matching
// SSE transport by sessionId query param (per MCP SDK SSE transport spec).
app.post("/messages", async (req, res) => {
  const sessionId = req.query.sessionId;
  const transport = activeTransports.get(sessionId);

  if (!transport) {
    res.status(400).json({ error: "No active SSE session for the given sessionId." });
    return;
  }

  await transport.handlePostMessage(req, res, req.body);
});

app.listen(PORT, () => {
  console.log(`jira-dev-copilot-mcp listening on port ${PORT}`);
  console.log(`  SSE endpoint:      GET  /sse`);
  console.log(`  Messages endpoint: POST /messages`);
  console.log(`  Health endpoint:   GET  /healthz`);
});
