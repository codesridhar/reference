---
name: software-requirements-review
description: Read and analyze software requirements documents, explain requirements in plain language with relatable examples, identify gaps and ambiguities, and provide clear next steps and a conclusion. Use for reviewing an SRD, SRS, PRD, or supplied software requirement text.
---

# Software Requirements Review

Turn a software requirements document into a detailed, accessible review that helps stakeholders understand the intended behavior and resolve missing decisions.

## Read and establish scope

- Read the supplied document, including relevant tables, diagrams, appendices, and linked material that is accessible. If no document or requirement text is supplied, ask for it before analyzing.
- State the document title and version when available, the product purpose, intended users, and scope. If only an excerpt is available or some content cannot be read, identify the coverage limit.
- Preserve existing requirement IDs. For unnumbered requirements, assign review labels and make clear that these labels were added for this analysis.
- Distinguish explicit requirements from interpretations, assumptions, and suggested additions. Do not invent business rules or silently resolve contradictions.

## Explain the requirements in detail

Group related requirements by feature or user journey while retaining traceability to the document. For each requirement, or tightly related group:

1. **Explain it simply:** Describe what the system must do and for whom. Define technical terms on first use.
2. **Explain why and when it matters:** Connect it to a practical user need or business outcome. Label inferred benefits as interpretations.
3. **Give a relatable example:** Use a realistic everyday scenario that illustrates the requirement. Keep invented names, numbers, and thresholds clearly illustrative rather than treating them as specifications.
4. **Show the steps:** Use numbered steps for the user action and system response. Include alternate and failure paths when relevant, separating documented behavior from unanswered questions.
5. **Clarify completion:** Summarize the stated acceptance criteria. If they are absent or not testable, flag the gap and offer proposed criteria for confirmation without inventing approved thresholds.

Use enough detail to explain conditions, inputs, outputs, permissions, and dependencies where they affect the requirement. Avoid repeating the same explanation across related requirements.

## Analyze and highlight gaps

Check the document against its own stated scope. Look for missing or conflicting actors, permissions, business rules, data definitions, workflow transitions, edge cases, error handling, integrations, and measurable acceptance criteria. Assess quality requirements such as performance, accessibility, security, privacy, reliability, and recovery when relevant to the product.

- Distinguish **missing information**, **ambiguity**, **contradiction**, and **untestable wording**. Keep optional improvements separate from gaps that prevent the stated requirement from being understood or implemented.
- Cite a requirement ID, section, or page for each finding; never fabricate a source locator. For a missing item, identify the relevant feature and say it is not specified in the reviewed material.
- Explain the practical consequence and give a concrete clarification question or proposed resolution. Mark proposed resolutions as suggestions requiring a stakeholder decision.
- Prioritize findings by impact: **High** for issues that block core behavior or introduce substantial risk; **Medium** for issues likely to cause inconsistent implementation or rework; **Low** for limited-impact clarity issues. Explain the priority briefly.
- Do not claim an omitted detail is absent everywhere when only part of the document was available. If no material gaps are found, say so and describe the review limits rather than manufacturing findings.

Use a compact gap table when it improves readability:

| Reference | Gap and type | Priority and impact | Question or suggested resolution |
| --- | --- | --- | --- |

## Present the review

Default to this order, adapting depth to document length and the user's requested format:

1. **Simple overview:** What is being built, who needs it, and what problem it solves.
2. **Detailed requirement explanations:** Plain-language descriptions, relatable examples, and numbered workflow steps.
3. **Gaps and clarification questions:** Prioritized findings with source references and actionable questions.
4. **Recommended next steps:** A short numbered sequence for resolving the most important decisions and making requirements ready for implementation and testing. Suggest responsible roles only when helpful; do not assign commitments to named people.
5. **Conclusion:** Summarize what is clear, what remains unresolved, and whether the reviewed requirements appear ready for implementation. Qualify that judgment when coverage is incomplete.

Use short paragraphs and bullets for key rules and takeaways. Use numbered lists for sequences. Keep the explanation understandable to nontechnical readers while preserving the original requirement's meaning. Provide the review in chat unless the user requests a saved deliverable. Analysis does not authorize changing the source requirements or implementing the software.
